using UnityEngine;

public class Goomba : MonoBehaviour
{
    public Sprite flatSprite;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && collision.gameObject.TryGetComponent(out Player player))
        {
            if (player.starpower) {
                Hit();
            } else if (collision.transform.DotTest(transform, Vector2.down)) {
                Flatten();
            } else {
                player.Hit();
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Shell")) {
            Hit();
        }
    }

    public void Flatten()
    {
        GetComponent<Collider2D>().enabled = false;
        GetComponent<EntityMovement>().enabled = false;
        GetComponent<AnimatedSprite>().enabled = false;
        GetComponent<SpriteRenderer>().sprite = flatSprite;

        RealmRaiders.UI.CombatFeedbackManager.Instance?.ShowPopup(transform.position, "💥 STOMP! +100", Color.yellow);
        RealmRaiders.UI.CombatFeedbackManager.Instance?.RegisterKill("Goomba", transform.position);

        RealmRaiders.Quests.QuestManager.Instance?.AddProgress("daily_kill", 1);
        RealmRaiders.Achievements.AchievementManager.Instance?.ReportProgress("breakthrough", 50);

        Destroy(gameObject, 0.5f);
    }

    public void Hit()
    {
        GetComponent<AnimatedSprite>().enabled = false;
        GetComponent<DeathAnimation>().enabled = true;

        RealmRaiders.UI.CombatFeedbackManager.Instance?.ShowPopup(transform.position, "⚔️ SLASH! +100", Color.cyan);
        RealmRaiders.UI.CombatFeedbackManager.Instance?.RegisterKill("Goomba", transform.position);

        RealmRaiders.Quests.QuestManager.Instance?.AddProgress("daily_kill", 1);
        RealmRaiders.Achievements.AchievementManager.Instance?.ReportProgress("breakthrough", 50);

        Destroy(gameObject, 3f);
    }

}
