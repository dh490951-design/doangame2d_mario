using UnityEngine;
using UnityEngine.SceneManagement;

[DefaultExecutionOrder(-1)]
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public int world { get; private set; } = 1;
    public int stage { get; private set; } = 1;
    public int lives { get; private set; } = 3;
    public int coins { get; set; } = 0;
    public float stagePlayTimer { get; private set; } = 0f;

    private void Update()
    {
        if (SceneManager.GetActiveScene().name != "MainMenu" && !isGameOver && Time.timeScale > 0f)
        {
            stagePlayTimer += Time.deltaTime;
        }
    }

    private void Awake()
    {
        if (Instance != null) {
            DestroyImmediate(gameObject);
        } else {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            SceneManager.sceneLoaded += OnSceneLoaded;
        }
    }

    private void OnDestroy()
    {
        if (Instance == this) {
            SceneManager.sceneLoaded -= OnSceneLoaded;
            Instance = null;
        }
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name != "MainMenu")
        {
            // Reset coin counter and refuel full hearts when entering another stage / level
            coins = 0;
            stagePlayTimer = 0f;
            RealmRaiders.Data.SaveSystem.ResetCoins();
            Player.lastCheckpointPosition = Vector3.zero;

            var data = RealmRaiders.Data.SaveSystem.LoadData();
            lives = data != null ? (data.difficulty switch
            {
                0 => 5,
                2 => 1,
                _ => 3
            }) : 3;

            string[] parts = scene.name.Split('-');
            if (parts.Length == 2 && int.TryParse(parts[0], out int w) && int.TryParse(parts[1], out int s))
            {
                this.world = w;
                this.stage = s;
            }
        }
    }

    private void Start()
    {
        Application.targetFrameRate = 60;
        var data = RealmRaiders.Data.SaveSystem.LoadData();
        if (data != null)
        {
            coins = data.coins;
            lives = data.difficulty switch
            {
                0 => 5,
                2 => 1,
                _ => 3
            };
        }

        string currentScene = SceneManager.GetActiveScene().name;
        if (currentScene != "MainMenu")
        {
            string[] parts = currentScene.Split('-');
            if (parts.Length == 2 && int.TryParse(parts[0], out int w) && int.TryParse(parts[1], out int s))
            {
                world = w;
                stage = s;
            }
        }
    }

    public void NewGame()
    {
        var data = RealmRaiders.Data.SaveSystem.LoadData();
        lives = data != null ? (data.difficulty switch
        {
            0 => 5, // Dễ: 5 mạng
            2 => 1, // Khó: 1 mạng
            _ => 3  // Trung bình: 3 mạng
        }) : 3;

        coins = 0;
        RealmRaiders.Data.SaveSystem.ResetCoins();

        LoadLevel(1, 1);
    }

    public bool isGameOver { get; private set; } = false;

    public void GameOver()
    {
        isGameOver = true;
    }

    public void RetryCurrentLevel()
    {
        isGameOver = false;
        var data = RealmRaiders.Data.SaveSystem.LoadData();
        lives = data != null ? (data.difficulty switch
        {
            0 => 5,
            2 => 1,
            _ => 3
        }) : 3;

        coins = 0;
        stagePlayTimer = 0f;
        RealmRaiders.Data.SaveSystem.ResetCoins();
        Player.lastCheckpointPosition = Vector3.zero;

        LoadLevel(world, stage);
    }

    public void LoadLevel(int world, int stage)
    {
        this.world = world;
        this.stage = stage;

        // Reset coin counter and refuel full hearts when moving to another level / stage
        coins = 0;
        stagePlayTimer = 0f;
        RealmRaiders.Data.SaveSystem.ResetCoins();
        Player.lastCheckpointPosition = Vector3.zero;

        var data = RealmRaiders.Data.SaveSystem.LoadData();
        lives = data != null ? (data.difficulty switch
        {
            0 => 5,
            2 => 1,
            _ => 3
        }) : 3;

        SceneManager.LoadScene($"{world}-{stage}");
    }

    public void RespawnPlayerAtCheckpoint(Player player, float delay = 1.0f, bool fromPit = false)
    {
        StartCoroutine(RespawnRoutine(player, delay, fromPit));
    }

    private System.Collections.IEnumerator RespawnRoutine(Player player, float delay, bool fromPit)
    {
        yield return new WaitForSeconds(delay);

        lives--;
        if (lives > 0)
        {
            if (player != null)
            {
                player.RespawnAtCheckpoint(fromPit);
            }
            else
            {
                LoadLevel(world, stage);
            }
        }
        else
        {
            GameOver();
        }
    }

    public void NextLevel()
    {
        LoadLevel(world, stage + 1);
    }

    public void ResetLevel(float delay)
    {
        CancelInvoke(nameof(ResetLevel));
        Invoke(nameof(ResetLevel), delay);
    }

    public void ResetLevel()
    {
        lives--;

        if (lives > 0) {
            LoadLevel(world, stage);
        } else {
            GameOver();
        }
    }

    public void AddCoin(int amount = 1)
    {
        RealmRaiders.Data.SaveSystem.AddCoins(amount);
        coins = RealmRaiders.Data.SaveSystem.Current.coins;

        var p = GameObject.FindGameObjectWithTag("Player");
        if (p != null)
        {
            RealmRaiders.UI.CombatFeedbackManager.Instance?.ShowPopup(p.transform.position, $"+{amount} 🪙", new Color(1f, 0.85f, 0.2f), 0.75f);
        }

        RealmRaiders.Quests.QuestManager.Instance?.AddProgress("daily_coin", amount);
        RealmRaiders.Audio.AudioManager.Instance?.PlayCoin();

        // Bonus life every 100 total coins
        if (coins > 0 && coins % 100 == 0)
        {
            AddLife();
        }
    }

    public void SetLives(int count)
    {
        lives = count;
    }

    public void AddLife()
    {
        lives++;
    }

}
