using UnityEngine;

[RequireComponent(typeof(BoxCollider2D))]
public class DeathBarrier : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player") || other.GetComponentInParent<Player>() != null)
        {
            var player = other.GetComponent<Player>() ?? other.GetComponentInParent<Player>();
            if (player != null)
            {
                player.OnFallInPit();
            }
        }
        else
        {
            Destroy(other.gameObject);
        }
    }
}
