using UnityEngine;

namespace RealmRaiders.Environment
{
    [RequireComponent(typeof(BoxCollider2D))]
    public class Quicksand : MonoBehaviour
    {
        [SerializeField] private float sinkSpeed = 1.2f;
        [SerializeField] private float speedDampFactor = 0.5f;

        private SpriteRenderer spriteRenderer;

        private void Start()
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
            if (spriteRenderer == null)
            {
                spriteRenderer = gameObject.AddComponent<SpriteRenderer>();
                spriteRenderer.sprite = Resources.Load<Sprite>("Coin");
                spriteRenderer.color = new Color(0.88f, 0.68f, 0.32f, 0.88f);
                spriteRenderer.sortingOrder = 4;
            }
        }

        private void Update()
        {
            // Subtle bubbling animation
            if (spriteRenderer != null)
            {
                float a = 0.8f + Mathf.Sin(Time.time * 4f) * 0.12f;
                spriteRenderer.color = new Color(0.88f, 0.68f, 0.32f, a);
            }
        }

        private void OnTriggerStay2D(Collider2D other)
        {
            if (other.CompareTag("Player") || other.GetComponentInParent<Player>() != null)
            {
                var rb = other.GetComponent<Rigidbody2D>() ?? other.GetComponentInParent<Rigidbody2D>();
                if (rb != null)
                {
                    // Drag downwards and slow horizontal move
                    rb.velocity = new Vector2(rb.velocity.x * speedDampFactor, Mathf.Clamp(rb.velocity.y, -sinkSpeed, 4f));
                }
            }
        }
    }
}
