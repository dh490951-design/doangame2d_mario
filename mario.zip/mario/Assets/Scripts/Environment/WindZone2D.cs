using UnityEngine;

namespace RealmRaiders.Environment
{
    [RequireComponent(typeof(Collider2D))]
    public class WindZone2D : MonoBehaviour
    {
        // Atmospheric wind zone for World 4 stormy aesthetic
    }
}
