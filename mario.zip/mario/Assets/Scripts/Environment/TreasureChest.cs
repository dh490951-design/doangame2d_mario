using UnityEngine;

namespace RealmRaiders.Environment
{
    public class TreasureChest : MonoBehaviour
    {
        private bool isOpened = false;

        private void Start()
        {
            var sr = GetComponent<SpriteRenderer>();
            if (sr == null)
            {
                sr = gameObject.AddComponent<SpriteRenderer>();
                sr.sprite = Resources.Load<Sprite>("Coin");
                sr.color = new Color(1f, 0.82f, 0.15f); // Bright Gold
                sr.sortingOrder = 6;
                transform.localScale = new Vector3(1.4f, 1.1f, 1f);
            }

            var col = GetComponent<BoxCollider2D>();
            if (col == null)
            {
                col = gameObject.AddComponent<BoxCollider2D>();
                col.size = Vector2.one;
            }
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if (isOpened) return;

            if (collision.gameObject.CompareTag("Player") || collision.gameObject.GetComponentInParent<Player>() != null)
            {
                OpenChest();
            }
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (isOpened) return;

            if (other.CompareTag("Player") || other.GetComponentInParent<Player>() != null)
            {
                OpenChest();
            }
        }

        public void OpenChest()
        {
            if (isOpened) return;
            isOpened = true;

            // Audio & Screen Shake
            Audio.AudioManager.Instance?.PlayCoin();
            SideScrollingCamera.TriggerShake(0.18f, 0.2f);

            // Reward
            int rewardCoins = 50;
            int rewardGems = 5;

            GameManager.Instance?.AddCoin(rewardCoins);
            Data.SaveSystem.Current.gems += rewardGems;
            Data.SaveSystem.SaveData();

            // Floating notification
            UI.CombatFeedbackManager.Instance?.ShowPopup(transform.position + Vector3.up * 0.8f, $"💎 RƯƠNG BÍ MẬT! +{rewardCoins} Xu, +{rewardGems} Ngọc", new Color(1f, 0.9f, 0.2f), 1.8f);

            // Visual Open state (dim and shrink slightly)
            var sr = GetComponent<SpriteRenderer>();
            if (sr != null) sr.color = new Color(0.6f, 0.6f, 0.6f, 0.7f);

            Destroy(gameObject, 0.8f);
        }
    }
}
