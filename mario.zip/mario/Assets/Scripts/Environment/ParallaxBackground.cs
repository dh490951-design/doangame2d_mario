using UnityEngine;

namespace RealmRaiders.Environment
{
    public class ParallaxBackground : MonoBehaviour
    {
        [System.Serializable]
        public class ParallaxLayer
        {
            public Transform transform;
            [Range(0f, 1f)] public float parallaxFactorX = 0.5f;
            [Range(0f, 1f)] public float parallaxFactorY = 0.1f;
        }

        [SerializeField] private ParallaxLayer[] layers;

        private Transform cameraTransform;
        private Vector3 lastCameraPosition;

        private void Start()
        {
            if (Camera.main != null)
            {
                cameraTransform = Camera.main.transform;
                lastCameraPosition = cameraTransform.position;
            }
        }

        private void LateUpdate()
        {
            if (cameraTransform == null) return;

            Vector3 deltaMovement = cameraTransform.position - lastCameraPosition;

            foreach (var layer in layers)
            {
                if (layer.transform != null)
                {
                    Vector3 newPos = layer.transform.position;
                    newPos.x += deltaMovement.x * layer.parallaxFactorX;
                    newPos.y += deltaMovement.y * layer.parallaxFactorY;
                    layer.transform.position = newPos;
                }
            }

            lastCameraPosition = cameraTransform.position;
        }
    }
}
