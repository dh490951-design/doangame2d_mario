using System.Collections;
using UnityEngine;

namespace RealmRaiders.Environment
{
    [RequireComponent(typeof(Collider2D))]
    public class SpringPad : MonoBehaviour
    {
        [SerializeField] private float bounceVelocity = 18f;
        [SerializeField] private AudioClip bounceSFX;

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if (collision.gameObject.CompareTag("Player"))
            {
                var rb = collision.gameObject.GetComponent<Rigidbody2D>();
                if (rb != null)
                {
                    rb.velocity = new Vector2(rb.velocity.x, bounceVelocity);
                    StartCoroutine(AnimateBounce());

                    if (bounceSFX != null)
                    {
                        AudioSource.PlayClipAtPoint(bounceSFX, transform.position);
                    }
                }
            }
        }

        private IEnumerator AnimateBounce()
        {
            Vector3 originalScale = transform.localScale;
            transform.localScale = new Vector3(originalScale.x * 1.3f, originalScale.y * 0.6f, originalScale.z);
            yield return new WaitForSeconds(0.1f);
            transform.localScale = new Vector3(originalScale.x * 0.9f, originalScale.y * 1.4f, originalScale.z);
            yield return new WaitForSeconds(0.1f);
            transform.localScale = originalScale;
        }
    }
}
