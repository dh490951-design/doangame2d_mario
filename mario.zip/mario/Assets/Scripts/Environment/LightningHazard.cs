using System.Collections;
using UnityEngine;

namespace RealmRaiders.Environment
{
    public class LightningHazard : MonoBehaviour
    {
        [Header("Timing")]
        [SerializeField] private float strikeInterval = 5f;
        [SerializeField] private float telegraphDuration = 1.2f;
        [SerializeField] private float strikeRadius = 1.8f;

        private GameObject telegraphMarker;
        private GameObject lightningBolt;

        private void Start()
        {
            CreateVisuals();
            StartCoroutine(LightningCycleRoutine());
        }

        private void CreateVisuals()
        {
            // 1. Telegraph circle on ground
            telegraphMarker = new GameObject("Telegraph_Ring");
            telegraphMarker.transform.parent = transform;
            telegraphMarker.transform.localPosition = Vector3.zero;
            telegraphMarker.transform.localScale = new Vector3(2.5f, 0.4f, 1f);

            var srWarn = telegraphMarker.AddComponent<SpriteRenderer>();
            srWarn.sprite = Resources.Load<Sprite>("Coin");
            srWarn.color = new Color(0.9f, 0.2f, 0.9f, 0.6f);
            srWarn.sortingOrder = 5;
            telegraphMarker.SetActive(false);

            // 2. Vertical Lightning Bolt
            lightningBolt = new GameObject("Lightning_Bolt");
            lightningBolt.transform.parent = transform;
            lightningBolt.transform.localPosition = new Vector3(0f, 5f, 0f);
            lightningBolt.transform.localScale = new Vector3(0.6f, 11f, 1f);

            var srBolt = lightningBolt.AddComponent<SpriteRenderer>();
            srBolt.sprite = Resources.Load<Sprite>("Coin");
            srBolt.color = new Color(0.4f, 0.95f, 1f, 0.95f);
            srBolt.sortingOrder = 14;
            lightningBolt.SetActive(false);
        }

        private IEnumerator LightningCycleRoutine()
        {
            // Random initial offset to stagger lightning strikes across the stage
            yield return new WaitForSeconds(Random.Range(0.5f, strikeInterval));

            while (true)
            {
                // Telegraph Warning
                if (telegraphMarker != null) telegraphMarker.SetActive(true);

                float elapsed = 0f;
                var srWarn = telegraphMarker?.GetComponent<SpriteRenderer>();
                while (elapsed < telegraphDuration)
                {
                    if (srWarn != null)
                    {
                        float alpha = 0.3f + Mathf.PingPong(elapsed * 6f, 0.6f);
                        srWarn.color = new Color(1f, 0.2f, 0.8f, alpha);
                    }
                    elapsed += Time.deltaTime;
                    yield return null;
                }

                if (telegraphMarker != null) telegraphMarker.SetActive(false);

                // Strike Bolt!
                if (lightningBolt != null) lightningBolt.SetActive(true);
                Audio.AudioManager.Instance?.PlayExplosion();
                SideScrollingCamera.TriggerShake(0.18f, 0.22f);

                CheckDamage();

                yield return new WaitForSeconds(0.22f);
                if (lightningBolt != null) lightningBolt.SetActive(false);

                yield return new WaitForSeconds(strikeInterval - telegraphDuration);
            }
        }

        private void CheckDamage()
        {
            Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, strikeRadius);
            foreach (var hit in hits)
            {
                if (hit.CompareTag("Player") || hit.GetComponentInParent<Player>() != null)
                {
                    var player = hit.GetComponent<Player>() ?? hit.GetComponentInParent<Player>();
                    if (player != null) player.Hit();
                }
            }
        }
    }
}
