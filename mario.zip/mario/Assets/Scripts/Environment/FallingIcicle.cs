using System.Collections;
using UnityEngine;

namespace RealmRaiders.Environment
{
    [RequireComponent(typeof(Rigidbody2D), typeof(Collider2D))]
    public class FallingIcicle : MonoBehaviour
    {
        private Rigidbody2D rb;
        private SpriteRenderer spriteRenderer;
        private bool isFalling = false;
        private Vector3 initialPos;
        private Transform playerTransform;

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            rb.isKinematic = true;
            initialPos = transform.position;

            spriteRenderer = GetComponent<SpriteRenderer>();
            if (spriteRenderer == null)
            {
                spriteRenderer = gameObject.AddComponent<SpriteRenderer>();
                spriteRenderer.sprite = Resources.Load<Sprite>("Coin");
                spriteRenderer.color = new Color(0.65f, 0.92f, 1f, 0.95f);
                spriteRenderer.sortingOrder = 6;
                transform.localScale = new Vector3(0.7f, 1.8f, 1f); // Sharp elongated icicle shape
            }
        }

        private void Start()
        {
            var p = GameObject.FindGameObjectWithTag("Player");
            if (p != null) playerTransform = p.transform;
        }

        private void Update()
        {
            if (isFalling) return;

            if (playerTransform == null)
            {
                var p = GameObject.FindGameObjectWithTag("Player");
                if (p != null) playerTransform = p.transform;
                if (playerTransform == null) return;
            }

            // Trigger when player is right underneath
            float dx = Mathf.Abs(playerTransform.position.x - transform.position.x);
            float dy = transform.position.y - playerTransform.position.y;

            if (dx < 1.35f && dy > 0f && dy < 8.5f)
            {
                StartCoroutine(TriggerFallRoutine());
            }
        }

        private IEnumerator TriggerFallRoutine()
        {
            isFalling = true;
            float elapsed = 0f;
            float shakeDuration = 0.4f;

            // Shaking warning
            while (elapsed < shakeDuration)
            {
                float offsetX = Mathf.Sin(elapsed * 45f) * 0.1f;
                transform.position = initialPos + new Vector3(offsetX, 0f, 0f);
                elapsed += Time.deltaTime;
                yield return null;
            }

            // Drop fast
            rb.isKinematic = false;
            rb.gravityScale = 3.5f;
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if (!isFalling) return;

            if (collision.gameObject.CompareTag("Player") || collision.gameObject.GetComponentInParent<Player>() != null)
            {
                var player = collision.gameObject.GetComponent<Player>() ?? collision.gameObject.GetComponentInParent<Player>();
                if (player != null)
                {
                    player.Hit();
                }
            }

            Audio.AudioManager.Instance?.PlayHit();
            Destroy(gameObject, 0.05f);
        }
    }
}
