using UnityEngine;
using UnityEngine.SceneManagement;

namespace RealmRaiders.Environment
{
    public class LevelCoinSpawner : MonoBehaviour
    {
        public static LevelCoinSpawner Instance { get; private set; }

        [SerializeField] private Sprite coinSprite;

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
                SceneManager.sceneLoaded += OnSceneLoaded;
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        private void Start()
        {
            TrySpawnCoinsInCurrentScene();
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            TrySpawnCoinsInCurrentScene();
        }

        public void TrySpawnCoinsInCurrentScene()
        {
            string sceneName = SceneManager.GetActiveScene().name;
            if (sceneName == "MainMenu") return;

            // Load coin sprite from Resources
            if (coinSprite == null)
            {
                coinSprite = Resources.Load<Sprite>("Coin");
            }

            // Spawn trails of coins along the path
            GameObject parent = new GameObject("[Level_Floating_Coins]");

            // Pattern of coin clusters along the run
            float[] clusterX = { 12f, 18f, 28f, 35f, 48f, 58f, 72f, 85f, 98f, 112f, 126f, 142f, 158f, 172f, 185f };

            foreach (float baseX in clusterX)
            {
                // Create an arc of 3-5 coins
                for (int i = 0; i < 4; i++)
                {
                    float x = baseX + i * 1.0f;
                    float y = 1.8f + Mathf.Sin(i / 3.0f * Mathf.PI) * 1.5f;

                    CreateCoin(parent.transform, new Vector3(x, y, 0f));
                }
            }

            Debug.Log($"<color=yellow>[CoinSpawner]</color> Spawned floating coin trails throughout {sceneName}!");
        }

        private void CreateCoin(Transform parent, Vector3 position)
        {
            GameObject coin = new GameObject("Floating_Coin");
            coin.transform.parent = parent;
            coin.transform.position = position;

            var sr = coin.AddComponent<SpriteRenderer>();
            sr.sprite = coinSprite;
            sr.sortingOrder = 5;

            var col = coin.AddComponent<CircleCollider2D>();
            col.isTrigger = true;
            col.radius = 0.5f;

            coin.AddComponent<CoinItem>();
        }
    }

    public class CoinBobber : MonoBehaviour
    {
        private float startY;
        private float randomOffset;

        private void Start()
        {
            startY = transform.position.y;
            randomOffset = Random.Range(0f, 10f);
        }

        private void Update()
        {
            float newY = startY + Mathf.Sin(Time.time * 3.5f + randomOffset) * 0.15f;
            transform.position = new Vector3(transform.position.x, newY, transform.position.z);
        }
    }
}
