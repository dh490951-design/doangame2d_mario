using UnityEngine;

namespace RealmRaiders.Environment
{
    public class CoinItem : MonoBehaviour
    {
        private Transform playerTransform;
        private bool collected = false;
        private Vector3 startPos;
        private float floatOffset;

        private void Start()
        {
            startPos = transform.position;
            floatOffset = Random.Range(0f, 10f);
            FindPlayer();
        }

        private void FindPlayer()
        {
            var p = GameObject.FindGameObjectWithTag("Player");
            if (p != null) playerTransform = p.transform;
        }

        private void Update()
        {
            if (collected) return;

            if (playerTransform == null)
            {
                FindPlayer();
                if (playerTransform == null) return;
            }

            float dist = Vector2.Distance(transform.position, playerTransform.position);

            // 1. Magnet attraction: If player has Magnet buff active, fly towards player
            if (Player.hasMagnetActive && dist < 10f)
            {
                transform.position = Vector3.MoveTowards(transform.position, playerTransform.position, 14f * Time.deltaTime);
            }
            else
            {
                // Gentle floating bob
                float newY = startPos.y + Mathf.Sin(Time.time * 4f + floatOffset) * 0.12f;
                transform.position = new Vector3(startPos.x, newY, startPos.z);
            }

            // 2. Proximity pickup check (Guaranteed pickup - never fails)
            if (dist < 1.15f)
            {
                Collect();
            }
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (collected) return;
            if (other.CompareTag("Player"))
            {
                Collect();
            }
        }

        private void Collect()
        {
            if (collected) return;
            collected = true;

            // Add coin directly to GameManager
            GameManager.Instance?.AddCoin(1);

            // Audio & particle feedback
            Audio.AudioManager.Instance?.PlayCoin();

            // Destroy coin
            Destroy(gameObject);
        }
    }
}
