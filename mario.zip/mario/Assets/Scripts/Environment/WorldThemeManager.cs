using UnityEngine;
using UnityEngine.SceneManagement;
using RealmRaiders.Audio;

namespace RealmRaiders.Environment
{
    public class WorldThemeManager : MonoBehaviour
    {
        public static WorldThemeManager Instance { get; private set; }

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
                SceneManager.sceneLoaded += OnSceneLoaded;
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        private void Start()
        {
            ApplyThemeForCurrentScene();
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            ApplyThemeForCurrentScene();
        }

        public void ApplyThemeForCurrentScene()
        {
            string sceneName = SceneManager.GetActiveScene().name;
            int worldIndex = 1;

            if (sceneName.StartsWith("2-")) worldIndex = 2;
            else if (sceneName.StartsWith("3-")) worldIndex = 3;
            else if (sceneName.StartsWith("4-")) worldIndex = 4;
            else if (sceneName == "MainMenu") worldIndex = 0;

            ApplyTheme(worldIndex);
        }

        public void ApplyTheme(int worldIndex)
        {
            Camera cam = Camera.main;

            Color skyColor;
            Color groundColor;
            Color brickColor;
            Color hillsColor;
            Color bushesColor;
            Color cloudsColor;
            Color pipesColor;
            Color castleColor;
            string themeName;

            switch (worldIndex)
            {
                case 2: // Sa Mạc Cát Cháy (Scorching Desert - Warm Sandstone & Bronze Dunes)
                    skyColor = new Color(0.95f, 0.70f, 0.35f);       // Warm golden amber sunset
                    groundColor = new Color(1.0f, 0.85f, 0.40f);     // Bright golden sand terrain
                    brickColor = new Color(0.95f, 0.75f, 0.38f);      // Sun-baked sandstone blocks
                    hillsColor = new Color(0.92f, 0.68f, 0.32f);      // Giant golden sand dunes
                    bushesColor = new Color(0.80f, 0.62f, 0.30f);     // Dried desert shrubs / tumbleweed
                    cloudsColor = new Color(1.0f, 0.92f, 0.75f, 0.85f); // Desert heat haze clouds
                    pipesColor = new Color(0.88f, 0.68f, 0.22f);      // Ancient sun-baked bronze pipes
                    castleColor = new Color(0.98f, 0.80f, 0.48f);     // Sandstone fortress
                    themeName = "Sa Mạc Cát Cháy (Scorching Desert)";
                    break;

                case 3: // Núi Tuyết Băng Giá (Frozen Peaks - Glacial Ice & Snow Wonderland)
                    skyColor = new Color(0.38f, 0.60f, 0.82f);       // Cold crisp arctic icy blue
                    groundColor = new Color(0.40f, 0.85f, 1.0f);     // Glacial ice crystal terrain
                    brickColor = new Color(0.55f, 0.90f, 1.0f);      // Frosted ice bricks
                    hillsColor = new Color(0.82f, 0.95f, 1.0f);      // Snow-capped glacial mountain peaks
                    bushesColor = new Color(0.65f, 0.90f, 0.98f);     // Frosted snow-covered pine shrubs
                    cloudsColor = new Color(0.92f, 0.96f, 1.0f, 0.95f); // Crisp winter snow clouds
                    pipesColor = new Color(0.15f, 0.85f, 0.95f);      // Frostbite cyan-ice pipes
                    castleColor = new Color(0.70f, 0.90f, 1.0f);      // Frozen crystal ice palace
                    themeName = "Đỉnh Núi Băng Tuyết (Frozen Peaks)";
                    break;

                case 4: // Vực Thẳm Bão Táp (Tempest Abyss - Dark Volcanic Nether Realm)
                    skyColor = new Color(0.10f, 0.08f, 0.18f);       // Dark stormy midnight purple
                    groundColor = new Color(0.45f, 0.32f, 0.55f);     // Dark volcanic basalt / obsidian brick
                    brickColor = new Color(0.55f, 0.38f, 0.65f);      // Corrupted nether bricks
                    hillsColor = new Color(0.25f, 0.18f, 0.35f);      // Sinister dark spires
                    bushesColor = new Color(0.35f, 0.22f, 0.42f);     // Cursed thorny brambles
                    cloudsColor = new Color(0.28f, 0.22f, 0.38f, 0.90f); // Thunderous ominous storm clouds
                    pipesColor = new Color(0.50f, 0.25f, 0.55f);      // Forged dark volcanic iron pipes
                    castleColor = new Color(0.55f, 0.35f, 0.65f);     // Dark Dragon Overlord citadel
                    themeName = "Vực Thẳm Bão Táp (Tempest Abyss)";
                    break;

                case 0: // Main Menu
                    skyColor = new Color(0.25f, 0.45f, 0.75f);
                    groundColor = Color.white;
                    brickColor = Color.white;
                    hillsColor = new Color(0.20f, 0.85f, 0.30f);
                    bushesColor = new Color(0.30f, 0.90f, 0.40f);
                    cloudsColor = Color.white;
                    pipesColor = new Color(0.15f, 0.85f, 0.25f);
                    castleColor = Color.white;
                    themeName = "Main Menu";
                    break;

                case 1: // Mặt Trời (Sun Kingdom - Classic Mario Lush Greenery)
                default:
                    skyColor = new Color(0.36f, 0.58f, 0.98f);       // Classic sunny sky blue
                    groundColor = Color.white;                        // Classic brick red/orange
                    brickColor = Color.white;
                    hillsColor = new Color(0.20f, 0.85f, 0.30f);      // Lush emerald green hills
                    bushesColor = new Color(0.30f, 0.90f, 0.40f);     // Vibrant green bushes
                    cloudsColor = new Color(1f, 1f, 1f, 0.95f);       // Crisp white clouds
                    pipesColor = new Color(0.15f, 0.85f, 0.25f);      // Iconic green pipes
                    castleColor = new Color(1f, 0.95f, 0.9f);         // Classic brick castle
                    themeName = "Vương Quốc Mặt Trời (Sun Kingdom)";
                    break;
            }

            // 1. Change Camera background
            if (cam != null)
            {
                cam.clearFlags = CameraClearFlags.SolidColor;
                cam.backgroundColor = skyColor;
            }

            // 2. Tint scenery & environment elements to create unique visual themes per world
            if (worldIndex != 0)
            {
                var renderers = FindObjectsOfType<SpriteRenderer>();
                foreach (var sr in renderers)
                {
                    if (sr == null) continue;
                    if (sr.CompareTag("Player") || sr.GetComponentInParent<Player>() != null) continue;
                    if (sr.gameObject.layer == LayerMask.NameToLayer("Enemy")) continue;
                    if (sr.gameObject.layer == LayerMask.NameToLayer("PowerUp")) continue;
                    if (sr.gameObject.name.Contains("Coin") || sr.gameObject.name.Contains("Gem")) continue;

                    string name = sr.gameObject.name.ToLower();
                    string parentName = sr.transform.parent != null ? sr.transform.parent.name.ToLower() : "";
                    string combined = name + " " + parentName;

                    if (combined.Contains("hill"))
                    {
                        sr.color = hillsColor;
                    }
                    else if (combined.Contains("bush"))
                    {
                        sr.color = bushesColor;
                    }
                    else if (combined.Contains("cloud"))
                    {
                        sr.color = cloudsColor;
                    }
                    else if (combined.Contains("pipe"))
                    {
                        sr.color = pipesColor;
                    }
                    else if (combined.Contains("castle"))
                    {
                        sr.color = castleColor;
                    }
                    else if (combined.Contains("ground"))
                    {
                        sr.color = groundColor;
                    }
                    else if (combined.Contains("brick") || combined.Contains("block") || combined.Contains("hard") || combined.Contains("mystery") || combined.Contains("empty"))
                    {
                        sr.color = brickColor;
                    }
                    else if (sr.gameObject.layer == LayerMask.NameToLayer("Default"))
                    {
                        sr.color = groundColor;
                    }
                }
            }

            // 3. Play World BGM
            if (worldIndex >= 1 && worldIndex <= 4)
            {
                AudioManager.Instance?.PlayWorldBGM(worldIndex);
            }

            Debug.Log($"<color=cyan>[WorldTheme]</color> Activated Theme: <b>{themeName}</b>");
        }
    }
}
