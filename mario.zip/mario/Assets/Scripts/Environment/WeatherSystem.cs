using UnityEngine;
using UnityEngine.SceneManagement;

namespace RealmRaiders.Environment
{
    public class WeatherSystem : MonoBehaviour
    {
        public static WeatherSystem Instance { get; private set; }

        private struct Particle
        {
            public Vector2 pos;
            public float speed;
            public float size;
            public float swayOffset;
        }

        private Particle[] snowParticles;
        private Particle[] rainParticles;
        private Particle[] sandParticles;

        private float lightningTimer = 0f;
        private float lightningFlashAlpha = 0f;

        private Texture2D whitePixel;

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
                InitParticles();
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void InitParticles()
        {
            whitePixel = new Texture2D(1, 1);
            whitePixel.SetPixel(0, 0, Color.white);
            whitePixel.Apply();

            // 60 Snowflakes
            snowParticles = new Particle[60];
            for (int i = 0; i < snowParticles.Length; i++)
            {
                snowParticles[i] = new Particle
                {
                    pos = new Vector2(Random.Range(0, Screen.width), Random.Range(0, Screen.height)),
                    speed = Random.Range(40f, 90f),
                    size = Random.Range(3f, 7f),
                    swayOffset = Random.Range(0f, 100f)
                };
            }

            // 80 Rain streaks
            rainParticles = new Particle[80];
            for (int i = 0; i < rainParticles.Length; i++)
            {
                rainParticles[i] = new Particle
                {
                    pos = new Vector2(Random.Range(0, Screen.width), Random.Range(0, Screen.height)),
                    speed = Random.Range(400f, 700f),
                    size = Random.Range(10f, 22f),
                    swayOffset = 0f
                };
            }

            // 40 Sand grains
            sandParticles = new Particle[40];
            for (int i = 0; i < sandParticles.Length; i++)
            {
                sandParticles[i] = new Particle
                {
                    pos = new Vector2(Random.Range(0, Screen.width), Random.Range(0, Screen.height)),
                    speed = Random.Range(150f, 320f),
                    size = Random.Range(2f, 5f),
                    swayOffset = Random.Range(0f, 50f)
                };
            }
        }

        private void Update()
        {
            string scene = SceneManager.GetActiveScene().name;
            float dt = Time.unscaledDeltaTime;

            // Snow update (World 3)
            if (scene.StartsWith("3-"))
            {
                for (int i = 0; i < snowParticles.Length; i++)
                {
                    snowParticles[i].pos.y += snowParticles[i].speed * dt;
                    snowParticles[i].pos.x += Mathf.Sin(Time.time * 2f + snowParticles[i].swayOffset) * 20f * dt;

                    if (snowParticles[i].pos.y > Screen.height)
                    {
                        snowParticles[i].pos.y = -10f;
                        snowParticles[i].pos.x = Random.Range(0, Screen.width);
                    }
                }
            }

            // Rain & Thunder update (World 4)
            if (scene.StartsWith("4-"))
            {
                for (int i = 0; i < rainParticles.Length; i++)
                {
                    rainParticles[i].pos.y += rainParticles[i].speed * dt;
                    rainParticles[i].pos.x -= (rainParticles[i].speed * 0.25f) * dt; // Slanted rain

                    if (rainParticles[i].pos.y > Screen.height)
                    {
                        rainParticles[i].pos.y = -20f;
                        rainParticles[i].pos.x = Random.Range(0, Screen.width + 200);
                    }
                }

                // Thunder periodic flash
                lightningTimer += dt;
                if (lightningTimer > Random.Range(4f, 7f))
                {
                    lightningTimer = 0f;
                    lightningFlashAlpha = 0.55f;
                }
                if (lightningFlashAlpha > 0f)
                {
                    lightningFlashAlpha = Mathf.Max(0f, lightningFlashAlpha - dt * 2.5f);
                }
            }

            // Sand update (World 2)
            if (scene.StartsWith("2-"))
            {
                for (int i = 0; i < sandParticles.Length; i++)
                {
                    sandParticles[i].pos.x += sandParticles[i].speed * dt;
                    sandParticles[i].pos.y += Mathf.Sin(Time.time * 3f + sandParticles[i].swayOffset) * 15f * dt;

                    if (sandParticles[i].pos.x > Screen.width)
                    {
                        sandParticles[i].pos.x = -10f;
                        sandParticles[i].pos.y = Random.Range(0, Screen.height);
                    }
                }
            }
        }

        private void OnGUI()
        {
            string scene = SceneManager.GetActiveScene().name;

            // World 1: Sun orb & Golden Sunbeams
            if (scene.StartsWith("1-"))
            {
                DrawSunOverlay();
            }
            // World 2: Sandstorm
            else if (scene.StartsWith("2-"))
            {
                DrawSandstormOverlay();
            }
            // World 3: Snowfall (Tuyết rơi)
            else if (scene.StartsWith("3-"))
            {
                DrawSnowfallOverlay();
            }
            // World 4: Rain & Lightning (Mưa & Sấm Sét)
            else if (scene.StartsWith("4-"))
            {
                DrawStormOverlay();
            }
        }

        private void DrawSunOverlay()
        {
            // Warm ambient golden sun rays (subtle, non-obstructive)
            GUI.color = new Color(1f, 0.95f, 0.6f, 0.05f);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), whitePixel);
            GUI.color = Color.white;
        }

        private void DrawSandstormOverlay()
        {
            GUI.color = new Color(0.95f, 0.75f, 0.35f, 0.7f);
            for (int i = 0; i < sandParticles.Length; i++)
            {
                GUI.DrawTexture(new Rect(sandParticles[i].pos.x, sandParticles[i].pos.y, sandParticles[i].size * 1.5f, sandParticles[i].size), whitePixel);
            }

            // Warm sand haze
            GUI.color = new Color(0.9f, 0.65f, 0.25f, 0.08f);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), whitePixel);
            GUI.color = Color.white;
        }

        private void DrawSnowfallOverlay()
        {
            GUI.color = new Color(0.95f, 0.98f, 1.0f, 0.85f);
            for (int i = 0; i < snowParticles.Length; i++)
            {
                float sz = snowParticles[i].size;
                GUI.DrawTexture(new Rect(snowParticles[i].pos.x, snowParticles[i].pos.y, sz, sz), whitePixel);
            }

            // Cool frost ambient
            GUI.color = new Color(0.6f, 0.85f, 1.0f, 0.06f);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), whitePixel);
            GUI.color = Color.white;
        }

        private void DrawStormOverlay()
        {
            // Rain streaks
            GUI.color = new Color(0.75f, 0.85f, 1.0f, 0.6f);
            for (int i = 0; i < rainParticles.Length; i++)
            {
                GUI.DrawTexture(new Rect(rainParticles[i].pos.x, rainParticles[i].pos.y, 2f, rainParticles[i].size), whitePixel);
            }

            // Lightning Flash
            if (lightningFlashAlpha > 0.01f)
            {
                GUI.color = new Color(0.95f, 0.95f, 1.0f, lightningFlashAlpha);
                GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), whitePixel);
            }

            // Dark vignette
            GUI.color = new Color(0.08f, 0.05f, 0.15f, 0.12f);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), whitePixel);
            GUI.color = Color.white;
        }
    }
}
