using UnityEngine;
using UnityEngine.SceneManagement;
using RealmRaiders.Boss;

namespace RealmRaiders.Environment
{
    public class WorldLayoutBuilder : MonoBehaviour
    {
        public static WorldLayoutBuilder Instance { get; private set; }

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
                SceneManager.sceneLoaded += OnSceneLoaded;
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        private void Start()
        {
            BuildLayoutForScene(SceneManager.GetActiveScene().name);
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            BuildLayoutForScene(scene.name);
        }

        private void BuildLayoutForScene(string sceneName)
        {
            if (sceneName == "MainMenu") return;

            GameObject container = new GameObject($"[World_Custom_Obstacles_{sceneName}]");

            // Secret Treasure Chest in every world
            float chestX = 76f;
            float chestY = 5.2f;
            if (sceneName.StartsWith("2-")) { chestX = 94f; chestY = 5.8f; }
            else if (sceneName.StartsWith("3-")) { chestX = 132f; chestY = 6.2f; }
            else if (sceneName.StartsWith("4-")) { chestX = 152f; chestY = 5.5f; }

            GameObject chest = new GameObject("Secret_Treasure_Chest");
            chest.transform.parent = container.transform;
            chest.transform.position = new Vector3(chestX, chestY, 0f);
            chest.AddComponent<TreasureChest>();

            // WORLD 2: SA MẠC (Desert) - Spawns Quicksand, Sand Pyramids, Spring Pads
            if (sceneName.StartsWith("2-"))
            {
                // Quicksand pits
                float[] sandX = { 28f, 62f, 105f, 140f };
                foreach (float x in sandX)
                {
                    GameObject qs = new GameObject("Quicksand_Pit");
                    qs.transform.parent = container.transform;
                    qs.transform.position = new Vector3(x, 0.2f, 0f);
                    qs.transform.localScale = new Vector3(4.5f, 1.2f, 1f);

                    var col = qs.AddComponent<BoxCollider2D>();
                    col.isTrigger = true;
                    col.size = Vector2.one;

                    qs.AddComponent<Quicksand>();
                }

                // Spring pads (bệ phóng cát)
                float[] desertSprings = { 42f, 88f, 132f };
                foreach (float x in desertSprings)
                {
                    GameObject sp = new GameObject("Desert_SpringPad");
                    sp.transform.parent = container.transform;
                    sp.transform.position = new Vector3(x, 1f, 0f);
                    sp.transform.localScale = new Vector3(1.4f, 0.6f, 1f);

                    var sr = sp.AddComponent<SpriteRenderer>();
                    sr.sprite = Resources.Load<Sprite>("Coin");
                    sr.color = new Color(1f, 0.45f, 0.15f);
                    sr.sortingOrder = 5;

                    var col = sp.AddComponent<BoxCollider2D>();
                    col.size = Vector2.one;

                    sp.AddComponent<SpringPad>();
                }

                Debug.Log("<color=yellow>[WorldBuilder]</color> Built Desert Quicksand and Spring Pads layout for World 2!");
            }
            // WORLD 3: BĂNG TUYẾT (Snow) - Spawns Falling Icicles and Icy Ground
            else if (sceneName.StartsWith("3-"))
            {
                // Ceiling Falling Icicles
                float[] icicleX = { 16f, 32f, 48f, 66f, 85f, 102f, 122f, 145f, 168f };
                foreach (float x in icicleX)
                {
                    GameObject icicle = new GameObject("Falling_Icicle");
                    icicle.transform.parent = container.transform;
                    icicle.transform.position = new Vector3(x, 7.5f, 0f);

                    var col = icicle.AddComponent<BoxCollider2D>();
                    col.size = new Vector2(0.8f, 1.8f);

                    icicle.AddComponent<FallingIcicle>();
                }

                // Icy Spring Pads
                float[] snowSprings = { 54f, 115f };
                foreach (float x in snowSprings)
                {
                    GameObject sp = new GameObject("Snow_SpringPad");
                    sp.transform.parent = container.transform;
                    sp.transform.position = new Vector3(x, 1f, 0f);
                    sp.transform.localScale = new Vector3(1.4f, 0.6f, 1f);

                    var sr = sp.AddComponent<SpriteRenderer>();
                    sr.sprite = Resources.Load<Sprite>("Coin");
                    sr.color = new Color(0.2f, 0.85f, 1f);
                    sr.sortingOrder = 5;

                    var col = sp.AddComponent<BoxCollider2D>();
                    col.size = Vector2.one;

                    sp.AddComponent<SpringPad>();
                }

                Debug.Log("<color=cyan>[WorldBuilder]</color> Built Frozen Peaks Falling Icicles and Spring Pads for World 3!");
            }
            // WORLD 4: BÃO TÁP (Storm) - Spawns Lightning Strike Hazards & Boss Arena
            else if (sceneName.StartsWith("4-"))
            {
                // Lightning hazard strike zones
                float[] stormX = { 25f, 55f, 90f, 125f, 160f };
                foreach (float x in stormX)
                {
                    GameObject lh = new GameObject("Lightning_Hazard_Zone");
                    lh.transform.parent = container.transform;
                    lh.transform.position = new Vector3(x, 1.5f, 0f);
                    lh.layer = LayerMask.NameToLayer("Ignore Raycast");
                    lh.AddComponent<LightningHazard>();
                }

                // Wind Zone
                GameObject wind = new GameObject("Storm_WindZone");
                wind.transform.parent = container.transform;
                wind.transform.position = new Vector3(80f, 3f, 0f);
                wind.layer = LayerMask.NameToLayer("Ignore Raycast");
                var colWind = wind.AddComponent<BoxCollider2D>();
                colWind.isTrigger = true;
                colWind.size = new Vector2(100f, 10f);
                wind.AddComponent<WindZone2D>();

                // Boss Dragon Entity
                GameObject bossObj = new GameObject("Boss_Infernal_Dragon");
                bossObj.transform.parent = container.transform;
                bossObj.transform.position = new Vector3(192f, 2.5f, 0f);
                bossObj.transform.localScale = new Vector3(2.5f, 2.5f, 1f);

                var sr = bossObj.AddComponent<SpriteRenderer>();
                sr.sprite = Resources.Load<Sprite>("Coin");
                sr.color = new Color(0.95f, 0.2f, 0.25f);
                sr.sortingOrder = 9;

                var rb = bossObj.AddComponent<Rigidbody2D>();
                rb.isKinematic = true;

                var col = bossObj.AddComponent<BoxCollider2D>();
                col.size = new Vector2(1.2f, 1.2f);
                bossObj.tag = "Enemy";

                var bossCtrl = bossObj.AddComponent<BossController>();
                bossObj.SetActive(false);

                // Boss Arena Trigger
                GameObject arena = new GameObject("Boss_Arena_Trigger");
                arena.transform.parent = container.transform;
                arena.transform.position = new Vector3(178f, 2f, 0f);
                var arenaCol = arena.AddComponent<BoxCollider2D>();
                arenaCol.isTrigger = true;
                arenaCol.size = new Vector2(4f, 12f);
                var bossArena = arena.AddComponent<BossArena>();
                bossArena.bossInstance = bossCtrl;
                bossArena.arenaMinX = 175f;
                bossArena.arenaMaxX = 205f;

                Debug.Log("<color=magenta>[WorldBuilder]</color> Built Tempest Abyss Lightning and Boss Dragon Arena for World 4!");
            }
        }
    }
}
