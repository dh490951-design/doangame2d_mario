using System.Collections;
using UnityEngine;

public class BlockHit : MonoBehaviour
{
    public GameObject item;
    public Sprite emptyBlock;
    public int maxHits = -1;
    private bool animating;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (!animating && maxHits != 0 && collision.gameObject.CompareTag("Player"))
        {
            if (collision.transform.DotTest(transform, Vector2.up)) {
                Hit();
            }
        }
    }

    private void Hit()
    {
        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();
        spriteRenderer.enabled = true; // show if hidden

        maxHits--;

        if (maxHits == 0) {
            spriteRenderer.sprite = emptyBlock;
        }

        // Mystery block drops: 35% chance to drop Magnet or Shield, otherwise standard item/coin
        float roll = Random.value;
        if (roll < 0.35f) {
            SpawnSpecialItem(roll < 0.18f ? RealmRaiders.PowerUps.SpecialPowerUpType.Magnet : RealmRaiders.PowerUps.SpecialPowerUpType.Shield);
        } else if (item != null) {
            Instantiate(item, transform.position, Quaternion.identity);
        } else {
            GameManager.Instance?.AddCoin(1);
        }

        StartCoroutine(Animate());
    }

    private void SpawnSpecialItem(RealmRaiders.PowerUps.SpecialPowerUpType type)
    {
        GameObject obj = new GameObject(type == RealmRaiders.PowerUps.SpecialPowerUpType.Magnet ? "PowerUp_Magnet" : "PowerUp_Shield");
        obj.transform.position = transform.position;

        var sr = obj.AddComponent<SpriteRenderer>();
        string spriteName = type == RealmRaiders.PowerUps.SpecialPowerUpType.Magnet ? "Magnet" : "Shield";
        Sprite loadedSprite = Resources.Load<Sprite>(spriteName);
        if (loadedSprite != null)
        {
            sr.sprite = loadedSprite;
            sr.color = Color.white;
        }
        else
        {
            var baseSprite = GetComponent<SpriteRenderer>()?.sprite;
            sr.sprite = baseSprite;
            sr.color = type == RealmRaiders.PowerUps.SpecialPowerUpType.Magnet ? new Color(0.2f, 0.7f, 1f) : new Color(0.9f, 0.9f, 0.2f);
        }
        sr.sortingOrder = 6;

        var col = obj.AddComponent<CircleCollider2D>();
        col.isTrigger = true;
        col.radius = 0.5f;

        var powerUp = obj.AddComponent<RealmRaiders.PowerUps.SpecialPowerUpItem>();
        powerUp.type = type;
    }

    private IEnumerator Animate()
    {
        animating = true;

        Vector3 restingPosition = transform.localPosition;
        Vector3 animatedPosition = restingPosition + Vector3.up * 0.5f;

        yield return Move(restingPosition, animatedPosition);
        yield return Move(animatedPosition, restingPosition);

        animating = false;
    }

    private IEnumerator Move(Vector3 from, Vector3 to)
    {
        float elapsed = 0f;
        float duration = 0.125f;

        while (elapsed < duration)
        {
            float t = elapsed / duration;

            transform.localPosition = Vector3.Lerp(from, to, t);
            elapsed += Time.deltaTime;

            yield return null;
        }

        transform.localPosition = to;
    }

}
