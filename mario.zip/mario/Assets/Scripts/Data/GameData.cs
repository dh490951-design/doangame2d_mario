using System;
using System.Collections.Generic;
using UnityEngine;

namespace RealmRaiders.Data
{
    [Serializable]
    public class SkillData
    {
        public string skillId;
        public int level = 1;
        public bool isUnlocked = false;
    }

    [Serializable]
    public class QuestProgress
    {
        public string questId;
        public int currentAmount;
        public int targetAmount;
        public bool isClaimed;
    }

    [Serializable]
    public class GameData
    {
        // Currencies & Lives
        public int coins = 0;
        public int gems = 0;
        public int lives = 3;
        public int currentScore = 0;

        // Player Upgrades
        public int healthLevel = 1;
        public int speedLevel = 1;
        public int attackLevel = 1;
        public bool hasDoubleJump = false;

        // Customization & Difficulty
        public int characterSkinColor = 0; // 0: Classic, 1: Sun Gold, 2: Desert Bronze, 3: Frost Ice, 4: Storm Violet, 5: Emerald
        public int difficulty = 1; // 0: Easy (5 lives), 1: Normal (3 lives), 2: Hard (1 life)

        // World & Level Progression (World 1..4, Level 1..10)
        public int unlockedWorld = 1;
        public int unlockedLevel = 1;
        public int currentWorld = 1;
        public int currentLevel = 1;

        // Skills
        public List<SkillData> skills = new();

        // Achievements
        public List<string> unlockedAchievements = new();

        // Quests
        public string lastDailyResetDate = "";
        public List<QuestProgress> dailyQuests = new();
        public List<QuestProgress> storyQuests = new();

        // Audio Settings
        public float musicVolume = 0.8f;
        public float sfxVolume = 1.0f;

        // Speedrun / Fastest Stage Completion Records (Seconds, 0 = no record)
        public float bestTimeWorld1 = 0f;
        public float bestTimeWorld2 = 0f;
        public float bestTimeWorld3 = 0f;
        public float bestTimeWorld4 = 0f;

        public float GetBestTime(int world) => world switch
        {
            1 => bestTimeWorld1,
            2 => bestTimeWorld2,
            3 => bestTimeWorld3,
            4 => bestTimeWorld4,
            _ => 0f
        };

        public void SetBestTime(int world, float time)
        {
            switch (world)
            {
                case 1: bestTimeWorld1 = time; break;
                case 2: bestTimeWorld2 = time; break;
                case 3: bestTimeWorld3 = time; break;
                case 4: bestTimeWorld4 = time; break;
            }
        }
    }

    public static class SaveSystem
    {
        private const string SAVE_KEY = "RealmRaiders_SaveProfile";
        private static GameData cachedData;

        public static GameData Current
        {
            get
            {
                if (cachedData == null)
                {
                    LoadFromStorage();
                }
                return cachedData;
            }
        }

        public static GameData LoadData()
        {
            return Current;
        }

        private static void LoadFromStorage()
        {
            if (!PlayerPrefs.HasKey(SAVE_KEY))
            {
                cachedData = CreateDefaultData();
                SaveData();
                return;
            }

            string json = PlayerPrefs.GetString(SAVE_KEY);
            try
            {
                cachedData = JsonUtility.FromJson<GameData>(json) ?? CreateDefaultData();
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[SaveSystem] Failed to parse save data: {ex.Message}. Resetting to default.");
                cachedData = CreateDefaultData();
                SaveData();
            }
        }

        public static void SaveData(GameData data = null)
        {
            if (data != null && data != cachedData)
            {
                cachedData = data;
            }
            if (cachedData == null) cachedData = CreateDefaultData();

            if (GameManager.Instance != null)
            {
                GameManager.Instance.coins = cachedData.coins;
            }

            string json = JsonUtility.ToJson(cachedData, true);
            PlayerPrefs.SetString(SAVE_KEY, json);
            PlayerPrefs.Save();
        }

        public static void AddCoins(int amount)
        {
            Current.coins += amount;
            SaveData();
            Debug.Log($"<color=yellow>[SaveSystem]</color> +{amount} Coins! Total coins now: {Current.coins}");
        }

        public static void ResetCoins()
        {
            Current.coins = 0;
            if (GameManager.Instance != null) GameManager.Instance.coins = 0;
            SaveData();
            Debug.Log("<color=yellow>[SaveSystem]</color> Coins reset to 0!");
        }

        public static void ClearSave()
        {
            cachedData = null;
            PlayerPrefs.DeleteKey(SAVE_KEY);
            PlayerPrefs.Save();
        }

        private static GameData CreateDefaultData()
        {
            var data = new GameData();
            data.coins = 0; // Fresh start with 0 coins
            data.skills.Add(new SkillData { skillId = "dash", level = 1, isUnlocked = false });
            data.skills.Add(new SkillData { skillId = "freeze", level = 1, isUnlocked = false });
            data.skills.Add(new SkillData { skillId = "lightning", level = 1, isUnlocked = false });
            data.skills.Add(new SkillData { skillId = "hurricane", level = 1, isUnlocked = false });
            return data;
        }
    }
}
