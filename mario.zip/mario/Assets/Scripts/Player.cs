using System.Collections;
using UnityEngine;

public class Player : MonoBehaviour
{
    public CapsuleCollider2D capsuleCollider { get; private set; }
    public PlayerMovement movement { get; private set; }
    public DeathAnimation deathAnimation { get; private set; }
    public RealmRaiders.Skills.SkillSystem skillSystem { get; private set; }

    public PlayerSpriteRenderer smallRenderer;
    public PlayerSpriteRenderer bigRenderer;
    private PlayerSpriteRenderer activeRenderer;

    public bool big => bigRenderer.enabled;
    public bool dead => deathAnimation.enabled;
    public bool starpower { get; set; }

    public static bool hasMagnetActive { get; set; } = false;
    public static float magnetTimer { get; set; } = 0f;
    public static bool hasShieldActive { get; set; } = false;
    public static Vector3 lastCheckpointPosition { get; set; } = Vector3.zero;

    private void Update()
    {
        if (hasMagnetActive)
        {
            magnetTimer -= Time.deltaTime;
            if (magnetTimer <= 0f)
            {
                hasMagnetActive = false;
            }
        }

        // Checkpoint update: Save checkpoint when grounded on safe surface ground (y >= 0.5f)
        if (movement != null && movement.grounded && !dead && transform.position.y >= 0.5f)
        {
            if (lastCheckpointPosition == Vector3.zero || transform.position.x > lastCheckpointPosition.x + 6f)
            {
                lastCheckpointPosition = transform.position;
            }
        }
    }

    public void ActivateMagnet(float duration = 15f)
    {
        hasMagnetActive = true;
        magnetTimer = duration;
        RealmRaiders.Audio.AudioManager.Instance?.PlaySkill();
        Debug.Log($"<color=yellow>[Magnet]</color> Coin Magnet activated for {duration} seconds!");
    }

    public void ActivateShield()
    {
        hasShieldActive = true;
        RealmRaiders.Audio.AudioManager.Instance?.PlaySkill();
        Debug.Log("<color=cyan>[Shield]</color> Protective Energy Shield activated!");
    }

    private IEnumerator ShieldBreakAnimation()
    {
        // Flash invincibility
        starpower = true;
        yield return new WaitForSeconds(1.5f);
        starpower = false;
    }

    private void Awake()
    {
        hasShieldActive = false;
        hasMagnetActive = false;
        magnetTimer = 0f;

        capsuleCollider = GetComponent<CapsuleCollider2D>();
        movement = GetComponent<PlayerMovement>();
        deathAnimation = GetComponent<DeathAnimation>();
        skillSystem = GetComponent<RealmRaiders.Skills.SkillSystem>() ?? gameObject.AddComponent<RealmRaiders.Skills.SkillSystem>();
        if (GetComponent<RealmRaiders.Skills.MeleeSlash>() == null)
        {
            gameObject.AddComponent<RealmRaiders.Skills.MeleeSlash>();
        }
        if (GetComponent<RealmRaiders.PowerUps.EnergyShieldVisual>() == null)
        {
            gameObject.AddComponent<RealmRaiders.PowerUps.EnergyShieldVisual>();
        }
        activeRenderer = smallRenderer;

        if (SideScrollingCamera.Instance != null)
        {
            SideScrollingCamera.Instance.trackedObject = transform;
        }
    }

    private void Start()
    {
        if (SideScrollingCamera.Instance != null)
        {
            SideScrollingCamera.Instance.trackedObject = transform;
        }

        if (lastCheckpointPosition != Vector3.zero)
        {
            Vector3 spawn = lastCheckpointPosition;
            if (spawn.y < 0.5f) spawn.y = 1.0f;
            spawn.y += 0.2f;
            transform.position = spawn;
            if (SideScrollingCamera.Instance != null)
            {
                SideScrollingCamera.Instance.SetUnderground(false);
                float minCamX = SideScrollingCamera.Instance.MinCameraX;
                SideScrollingCamera.Instance.transform.position = new Vector3(Mathf.Max(minCamX, spawn.x), SideScrollingCamera.Instance.height, SideScrollingCamera.Instance.transform.position.z);
            }
        }
        else
        {
            lastCheckpointPosition = transform.position;
        }

        ApplySkinColor();
    }

    public void ApplySkinColor()
    {
        var data = RealmRaiders.Data.SaveSystem.LoadData();
        Color tint = data.characterSkinColor switch
        {
            1 => new Color(1f, 0.85f, 0.2f),   // Sun Gold
            2 => new Color(0.9f, 0.6f, 0.4f),   // Desert Bronze
            3 => new Color(0.4f, 0.9f, 1f),     // Frost Ice Cyan
            4 => new Color(0.75f, 0.45f, 0.95f),// Storm Violet
            5 => new Color(0.3f, 0.95f, 0.45f), // Emerald Green
            _ => Color.white                    // Classic Mario
        };

        if (smallRenderer != null)
        {
            var sr = smallRenderer.GetComponent<SpriteRenderer>();
            if (sr != null) sr.color = tint;
        }
        if (bigRenderer != null)
        {
            var sr = bigRenderer.GetComponent<SpriteRenderer>();
            if (sr != null) sr.color = tint;
        }
    }

    public void Hit()
    {
        if (!dead && !starpower)
        {
            if (hasShieldActive)
            {
                hasShieldActive = false;
                SideScrollingCamera.TriggerShake(0.22f, 0.28f);
                RealmRaiders.Audio.AudioManager.Instance?.PlayExplosion();
                RealmRaiders.UI.CombatFeedbackManager.Instance?.ShowPopup(transform.position + Vector3.up * 1f, "🛡️ KHIÊN HẤP THỤ!", Color.cyan, 1.2f);
                StartCoroutine(ShieldBreakAnimation());
                return;
            }

            SideScrollingCamera.TriggerShake(0.2f, 0.25f);
            RealmRaiders.Audio.AudioManager.Instance?.PlayHit();

            if (big) {
                Shrink();
            } else {
                Death();
            }
        }
    }

    public void Death()
    {
        smallRenderer.enabled = false;
        bigRenderer.enabled = false;
        deathAnimation.enabled = true;

        hasShieldActive = false;
        hasMagnetActive = false;

        if (GameManager.Instance != null)
        {
            GameManager.Instance.RespawnPlayerAtCheckpoint(this, 1.4f);
        }
    }

    public void OnFallInPit()
    {
        hasShieldActive = false;
        hasMagnetActive = false;
        RealmRaiders.Audio.AudioManager.Instance?.PlayHit();
        gameObject.SetActive(false);

        if (GameManager.Instance != null)
        {
            GameManager.Instance.RespawnPlayerAtCheckpoint(this, 0.9f, true);
        }
    }

    private Vector3 FindSafeGround(float targetX, float defaultY = 1.0f)
    {
        for (int step = 0; step < 6; step++)
        {
            float testX = Mathf.Max(0f, targetX - step * 1.0f);
            RaycastHit2D[] hits = Physics2D.RaycastAll(new Vector2(testX, 6f), Vector2.down, 12f);
            foreach (var hit in hits)
            {
                // Must be solid non-trigger ground at surface level (y >= 0.2f)
                if (hit.collider != null && !hit.collider.isTrigger && hit.point.y >= 0.2f)
                {
                    return new Vector3(testX, hit.point.y + 0.1f, 0f);
                }
            }
        }
        return new Vector3(Mathf.Max(0f, targetX), Mathf.Max(1.0f, defaultY), 0f);
    }

    public void RespawnAtCheckpoint(bool fromPit = false)
    {
        gameObject.SetActive(true);

        if (deathAnimation != null)
        {
            deathAnimation.enabled = false;
        }

        if (TryGetComponent(out Rigidbody2D rb))
        {
            rb.isKinematic = false;
            rb.velocity = Vector2.zero;
            rb.angularVelocity = 0f;
        }

        if (movement != null)
        {
            movement.enabled = true;
            movement.ResetVelocity();
        }

        if (capsuleCollider != null)
        {
            capsuleCollider.enabled = true;
        }

        smallRenderer.enabled = true;
        bigRenderer.enabled = false;
        activeRenderer = smallRenderer;

        Vector3 basePos = lastCheckpointPosition != Vector3.zero ? lastCheckpointPosition : new Vector3(0f, 1f, 0f);
        if (basePos.y < 0.5f) basePos.y = 1.0f;

        Vector3 spawnPos;
        if (fromPit)
        {
            // Spawn 5 units behind checkpoint so player is well clear of the pit
            float targetX = Mathf.Max(0f, basePos.x - 5.0f);
            spawnPos = FindSafeGround(targetX, basePos.y);
            lastCheckpointPosition = spawnPos;
        }
        else
        {
            spawnPos = basePos;
        }

        spawnPos.y += 0.25f;
        transform.position = spawnPos;

        if (SideScrollingCamera.Instance != null)
        {
            SideScrollingCamera.Instance.trackedObject = transform;
            SideScrollingCamera.Instance.SetUnderground(false);
            float minCamX = SideScrollingCamera.Instance.MinCameraX;
            SideScrollingCamera.Instance.transform.position = new Vector3(
                Mathf.Max(minCamX, spawnPos.x), 
                SideScrollingCamera.Instance.height, 
                SideScrollingCamera.Instance.transform.position.z
            );
        }

        // Deduct gold coins for checkpoint respawn (10 coins per respawn)
        int coinCost = 10;
        int currentCoins = RealmRaiders.Data.SaveSystem.Current.coins;
        int deductAmount = Mathf.Min(currentCoins, coinCost);
        if (deductAmount > 0)
        {
            RealmRaiders.Data.SaveSystem.AddCoins(-deductAmount);
            if (GameManager.Instance != null)
            {
                GameManager.Instance.coins = RealmRaiders.Data.SaveSystem.Current.coins;
            }
        }

        StartCoroutine(RespawnInvincibilityRoutine());

        RealmRaiders.Audio.AudioManager.Instance?.PlayCoin();
        if (deductAmount > 0)
        {
            RealmRaiders.UI.CombatFeedbackManager.Instance?.ShowPopup(spawnPos + Vector3.up * 1f, $"🔄 HỒI SINH! (-{deductAmount} 🪙)", new Color(1f, 0.85f, 0.2f), 2.2f);
        }
        else
        {
            RealmRaiders.UI.CombatFeedbackManager.Instance?.ShowPopup(spawnPos + Vector3.up * 1f, "🔄 HỒI SINH CHECKPOINT! (0 🪙)", Color.yellow, 2.0f);
        }
    }

    private IEnumerator RespawnInvincibilityRoutine()
    {
        starpower = true;
        float elapsed = 0f;
        float duration = 2.5f;

        while (elapsed < duration)
        {
            if (activeRenderer != null)
            {
                var sr = activeRenderer.GetComponent<SpriteRenderer>();
                if (sr != null)
                {
                    float a = Mathf.PingPong(elapsed * 8f, 1f) > 0.5f ? 0.25f : 1f;
                    sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, a);
                }
            }
            elapsed += Time.deltaTime;
            yield return null;
        }

        ApplySkinColor();
        starpower = false;
    }

    public void Grow()
    {
        smallRenderer.enabled = false;
        bigRenderer.enabled = true;
        activeRenderer = bigRenderer;

        capsuleCollider.size = new Vector2(1f, 2f);
        capsuleCollider.offset = new Vector2(0f, 0.5f);

        StartCoroutine(ScaleAnimation());
        ApplySkinColor();
    }

    public void Shrink()
    {
        smallRenderer.enabled = true;
        bigRenderer.enabled = false;
        activeRenderer = smallRenderer;

        capsuleCollider.size = new Vector2(1f, 1f);
        capsuleCollider.offset = new Vector2(0f, 0f);

        StartCoroutine(ShrinkInvulnerabilityRoutine());
        ApplySkinColor();
    }

    private IEnumerator ShrinkInvulnerabilityRoutine()
    {
        starpower = true;
        yield return ScaleAnimation();
        // Brief grace period flashing after shrink
        float elapsed = 0f;
        while (elapsed < 1.0f)
        {
            elapsed += Time.deltaTime;
            smallRenderer.enabled = (Time.frameCount % 4 < 2);
            yield return null;
        }
        smallRenderer.enabled = true;
        starpower = false;
    }

    private IEnumerator ScaleAnimation()
    {
        float elapsed = 0f;
        float duration = 0.5f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;

            if (Time.frameCount % 4 == 0)
            {
                smallRenderer.enabled = !smallRenderer.enabled;
                bigRenderer.enabled = !smallRenderer.enabled;
            }

            yield return null;
        }

        smallRenderer.enabled = false;
        bigRenderer.enabled = false;
        activeRenderer.enabled = true;
    }

    public void Starpower()
    {
        StartCoroutine(StarpowerAnimation());
    }

    private IEnumerator StarpowerAnimation()
    {
        starpower = true;

        float elapsed = 0f;
        float duration = 10f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;

            if (Time.frameCount % 4 == 0) {
                activeRenderer.spriteRenderer.color = Random.ColorHSV(0f, 1f, 1f, 1f, 1f, 1f);
            }

            yield return null;
        }

        activeRenderer.spriteRenderer.color = Color.white;
        starpower = false;
    }

}
