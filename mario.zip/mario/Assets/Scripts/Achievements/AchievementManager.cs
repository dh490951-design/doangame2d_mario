using System;
using System.Collections.Generic;
using UnityEngine;
using RealmRaiders.Data;

namespace RealmRaiders.Achievements
{
    [Serializable]
    public class AchievementItem
    {
        public string id;
        public string titleKey;
        public string descriptionKey;
        public int rewardGems;
        public int currentCount;
        public int goalCount;
        public bool isUnlocked;
    }

    public class AchievementManager : MonoBehaviour
    {
        public static AchievementManager Instance { get; private set; }

        public static event Action OnAchievementsChanged;

        [SerializeField] private List<AchievementItem> achievements = new()
        {
            new AchievementItem { id = "breakthrough", titleKey = "achieve_breakthrough", rewardGems = 10, goalCount = 2500 },
            new AchievementItem { id = "immortal", titleKey = "achieve_immortal", rewardGems = 15, goalCount = 1000 },
            new AchievementItem { id = "freezing", titleKey = "achieve_frost_master", rewardGems = 10, goalCount = 1000 },
            new AchievementItem { id = "bolt", titleKey = "achieve_thunder_god", rewardGems = 10, goalCount = 1000 }
        };

        private GameData gameData => SaveSystem.Current;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            SyncAchievementsWithSave();
        }

        private void SyncAchievementsWithSave()
        {
            foreach (var a in achievements)
            {
                if (gameData.unlockedAchievements.Contains(a.id))
                {
                    a.isUnlocked = true;
                    a.currentCount = a.goalCount;
                }
            }
        }

        public void ReportProgress(string achievementId, int amount)
        {
            var item = achievements.Find(a => a.id == achievementId);
            if (item != null && !item.isUnlocked)
            {
                item.currentCount += amount;
                if (item.currentCount >= item.goalCount)
                {
                    item.isUnlocked = true;
                    if (!gameData.unlockedAchievements.Contains(item.id))
                    {
                        gameData.unlockedAchievements.Add(item.id);
                        gameData.gems += item.rewardGems;
                        SaveSystem.SaveData(gameData);
                    }
                }
                OnAchievementsChanged?.Invoke();
            }
        }
    }
}
