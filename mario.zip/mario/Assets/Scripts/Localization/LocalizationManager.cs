using System;
using System.Collections.Generic;
using UnityEngine;

namespace RealmRaiders.Localization
{
    public enum Language
    {
        Vietnamese,
        English
    }

    public class LocalizationManager : MonoBehaviour
    {
        public static LocalizationManager Instance { get; private set; }

        public static event Action OnLanguageChanged;

        [SerializeField] private Language currentLanguage = Language.Vietnamese;
        public Language CurrentLanguage => currentLanguage;

        private readonly Dictionary<string, (string vi, string en)> localizedStrings = new()
        {
            // Main Menu
            { "menu_play", ("Chơi Tiếp", "Resume Game") },
            { "menu_newgame", ("Trò Chơi Mới", "Start New Game") },
            { "menu_tutorial", ("Hướng Dẫn", "Tutorial") },
            { "menu_options", ("Cài Đặt", "Options") },
            { "menu_quit", ("Thoát", "Quit Game") },
            { "menu_language", ("Ngôn Ngữ", "Language") },
            { "menu_sound", ("Âm Thanh", "Sound") },
            { "menu_music", ("Nhạc Nền", "Music") },

            // Worlds
            { "world_1_name", ("Thế Giới Mặt Trời", "Sun Kingdom") },
            { "world_1_desc", ("Vùng đồng cỏ xanh ngát rực rỡ nắng ấm.", "Lush green plains bathed in warm golden light.") },
            { "world_2_name", ("Sa Mạc Cát Cháy", "Scorching Desert") },
            { "world_2_desc", ("Cồn cát vô tận, bão cát dữ dội và lăng mộ cổ.", "Endless dunes, violent sandstorms and ancient ruins.") },
            { "world_3_name", ("Đỉnh Núi Băng Tuyết", "Frozen Peaks") },
            { "world_3_desc", ("Vương quốc băng giá lạnh thấu xương, trơn trượt.", "Sub-zero blizzard realm of sheer ice and sharp spikes.") },
            { "world_4_name", ("Vực Thẳm Bão Táp", "Tempest Abyss") },
            { "world_4_desc", ("Mưa bão xé toạc bầu trời, sấm sét giáng xuống liên tục.", "Raging hurricane, electrified skies and colossal airships.") },

            // HUD & Stats
            { "hud_coins", ("Xu", "Coins") },
            { "hud_gems", ("Kim Cương", "Gems") },
            { "hud_lives", ("Mạng", "Lives") },
            { "hud_score", ("Điểm", "Score") },
            { "hud_boss_hp", ("Trùm Cuối", "Boss HP") },

            // Skills
            { "skill_dash", ("Lướt Tốc Biến", "Assassin Dash") },
            { "skill_dash_desc", ("Lướt nhanh né tránh đòn đánh và phản kích.", "Quickly dash forward, evading enemy collisions.") },
            { "skill_freeze", ("Băng Đông Cứng", "Freezing Burst") },
            { "skill_freeze_desc", ("Bắn luồng khí hàn đóng băng kẻ thù trong 3 giây.", "Fires a frost surge freezing enemies in ice.") },
            { "skill_lightning", ("Thiên Lôi Giáng", "Lightning Bolt") },
            { "skill_lightning_desc", ("Gọi sấm sét giáng thẳng xuống mục tiêu trước mặt.", "Summons lightning strikes to obliterate foes.") },
            { "skill_hurricane", ("Cơn Cuồng Phong", "Hurricane Gust") },
            { "skill_hurricane_desc", ("Tạo lốc xoáy hất văng quái vật trên đường đi.", "Conjures a swirling tornado clearing obstacles.") },

            // Shop
            { "shop_title", ("Cửa Hàng", "Shop") },
            { "shop_super_offer", ("Ưu Đãi Đặc Biệt", "Super Offer") },
            { "shop_buy", ("Mua", "Buy") },
            { "shop_upgrade_hp", ("Nâng Cấp Máu", "Upgrade Health") },
            { "shop_upgrade_speed", ("Tốc Độ Di Chuyển", "Move Speed") },
            { "shop_upgrade_atk", ("Lực Tấn Công", "Attack Power") },
            { "shop_chest_small", ("Rương Gỗ", "Fistful of Chest") },
            { "shop_chest_gold", ("Rương Hoàng Gia", "Golden Treasure") },

            // Quests
            { "quest_daily_title", ("Nhiệm Vụ Hàng Ngày", "Daily Quests") },
            { "quest_story_title", ("Nhiệm Vụ Cốt Truyện", "Story Quests") },
            { "quest_collect_coins", ("Thu thập 50 đồng xu", "Collect 50 coins") },
            { "quest_kill_enemies", ("Tiêu diệt 10 quái vật", "Defeat 10 enemies") },
            { "quest_finish_stage", ("Vượt màn không mất mạng", "Complete a stage without taking hit") },

            // Achievements
            { "achieve_breakthrough", ("Đột Phá Giới Hạn", "Breakthrough") },
            { "achieve_immortal", ("Bất Tử Bất Diệt", "Immortal Champion") },
            { "achieve_frost_master", ("Bậc Thầy Băng Tuyết", "Frost Sorcerer") },
            { "achieve_thunder_god", ("Sấm Truyền Thần Lực", "Thunder Striker") }
        };

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
                LoadSavedLanguage();
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void LoadSavedLanguage()
        {
            int langIndex = PlayerPrefs.GetInt("GameLanguage", (int)Language.Vietnamese);
            currentLanguage = (Language)langIndex;
        }

        public void SetLanguage(Language newLang)
        {
            currentLanguage = newLang;
            PlayerPrefs.SetInt("GameLanguage", (int)newLang);
            PlayerPrefs.Save();
            OnLanguageChanged?.Invoke();
        }

        public void ToggleLanguage()
        {
            SetLanguage(currentLanguage == Language.Vietnamese ? Language.English : Language.Vietnamese);
        }

        public string Get(string key)
        {
            if (localizedStrings.TryGetValue(key, out var pair))
            {
                return currentLanguage == Language.Vietnamese ? pair.vi : pair.en;
            }
            return key;
        }
    }
}
