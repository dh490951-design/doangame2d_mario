using UnityEngine;
using UnityEngine.UI;

namespace RealmRaiders.Localization
{
    [RequireComponent(typeof(Text))]
    public class LocalizedText : MonoBehaviour
    {
        [SerializeField] private string translationKey;
        private Text textComponent;

        private void Awake()
        {
            textComponent = GetComponent<Text>();
        }

        private void OnEnable()
        {
            LocalizationManager.OnLanguageChanged += RefreshText;
            RefreshText();
        }

        private void OnDisable()
        {
            LocalizationManager.OnLanguageChanged -= RefreshText;
        }

        public void SetKey(string key)
        {
            translationKey = key;
            RefreshText();
        }

        public void RefreshText()
        {
            if (LocalizationManager.Instance != null && textComponent != null && !string.IsNullOrEmpty(translationKey))
            {
                textComponent.text = LocalizationManager.Instance.Get(translationKey);
            }
        }
    }
}
