using System;
using UnityEngine;
using RealmRaiders.Data;

namespace RealmRaiders.Shop
{
    public class ShopManager : MonoBehaviour
    {
        public static ShopManager Instance { get; private set; }

        public static event Action OnShopUpdated;

        private GameData currentData => SaveSystem.Current;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);
        }

        public int GetCoins() => currentData.coins;
        public int GetGems() => currentData.gems;

        public void AddCoins(int amount)
        {
            currentData.coins += amount;
            SaveSystem.SaveData(currentData);
            OnShopUpdated?.Invoke();
        }

        public void AddGems(int amount)
        {
            currentData.gems += amount;
            SaveSystem.SaveData(currentData);
            OnShopUpdated?.Invoke();
        }

        public bool PurchaseSkill(string skillId, int costCoins)
        {
            if (currentData.coins >= costCoins)
            {
                var s = currentData.skills.Find(x => x.skillId == skillId);
                if (s == null)
                {
                    s = new SkillData { skillId = skillId, level = 1, isUnlocked = true };
                    currentData.skills.Add(s);
                }
                else
                {
                    s.isUnlocked = true;
                    s.level++;
                }

                currentData.coins -= costCoins;
                SaveSystem.SaveData(currentData);
                OnShopUpdated?.Invoke();
                return true;
            }
            return false;
        }

        public bool PurchaseDoubleJump(int costCoins)
        {
            if (currentData.coins >= costCoins && !currentData.hasDoubleJump)
            {
                currentData.coins -= costCoins;
                currentData.hasDoubleJump = true;
                SaveSystem.SaveData(currentData);
                OnShopUpdated?.Invoke();
                return true;
            }
            return false;
        }

        public bool PurchaseUpgradeHealth(int costCoins)
        {
            if (currentData.coins >= costCoins)
            {
                currentData.coins -= costCoins;
                currentData.healthLevel++;
                SaveSystem.SaveData(currentData);
                OnShopUpdated?.Invoke();
                return true;
            }
            return false;
        }

        public bool PurchaseUpgradeSpeed(int costCoins)
        {
            if (currentData.coins >= costCoins)
            {
                currentData.coins -= costCoins;
                currentData.speedLevel++;
                SaveSystem.SaveData(currentData);
                OnShopUpdated?.Invoke();
                return true;
            }
            return false;
        }

        public bool PurchaseChest(int costGems, out int coinsReward, out int gemsReward)
        {
            coinsReward = 0;
            gemsReward = 0;

            if (currentData.gems >= costGems)
            {
                currentData.gems -= costGems;
                coinsReward = UnityEngine.Random.Range(200, 800);
                gemsReward = UnityEngine.Random.Range(5, 20);

                currentData.coins += coinsReward;
                currentData.gems += gemsReward;

                SaveSystem.SaveData(currentData);
                OnShopUpdated?.Invoke();
                return true;
            }
            return false;
        }
    }
}
