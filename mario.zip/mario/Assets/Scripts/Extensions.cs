using UnityEngine;

public static class Extensions
{
    private static LayerMask layerMask = LayerMask.GetMask("Default");

    // Checks if the rigidbody is colliding with an object in a given direction.
    // For example, if you want to check if the player is touching the ground,
    // you can pass Vector2.down. If you want to check if the player is running
    // into a wall, you can pass Vector2.right or Vector2.left.
    public static bool Raycast(this Rigidbody2D rigidbody, Vector2 direction)
    {
        if (rigidbody.isKinematic || direction.sqrMagnitude < 0.0001f) {
            return false;
        }

        Vector2 edge = rigidbody.ClosestPoint(rigidbody.position + direction.normalized);
        float radius = (edge - rigidbody.position).magnitude / 2f;
        if (radius <= 0.01f) radius = 0.25f;
        float distance = radius + 0.1f;

        Vector2 point = rigidbody.position + (direction.normalized * distance);
        Collider2D[] colliders = Physics2D.OverlapCircleAll(point, radius, layerMask);
        foreach (var col in colliders)
        {
            if (col != null && !col.isTrigger && col.attachedRigidbody != rigidbody)
            {
                return true;
            }
        }
        return false;
    }

    // Checks if the transform is facing another transform in a given direction.
    // For example, if you want to check if the player stomps on an enemy, you
    // would pass the player transform, the enemy transform, and Vector2.down.
    public static bool DotTest(this Transform transform, Transform other, Vector2 testDirection)
    {
        Vector2 direction = other.position - transform.position;
        return Vector2.Dot(direction.normalized, testDirection) > 0.25f;
    }

    public static bool IsEnemy(this GameObject go)
    {
        if (go == null) return false;
        int enemyLayer = LayerMask.NameToLayer("Enemy");
        if (enemyLayer != -1 && go.layer == enemyLayer) return true;
        if (go.GetComponent<Goomba>() != null || go.GetComponent<Koopa>() != null || go.GetComponent<RealmRaiders.Boss.BossController>() != null) return true;
        if (go.GetComponent<EntityMovement>() != null) return true;
        return false;
    }

    public static bool IsEnemy(this Collider2D col)
    {
        if (col == null) return false;
        return col.gameObject.IsEnemy();
    }

}
