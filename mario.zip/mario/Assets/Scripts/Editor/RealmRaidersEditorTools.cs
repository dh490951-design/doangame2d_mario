using UnityEditor;
using UnityEngine;
using RealmRaiders.Data;
using RealmRaiders.UI;

namespace RealmRaiders.Editor
{
    public static class RealmRaidersEditorTools
    {
        [MenuItem("Tools/Realm Raiders/Data/Give Max Coins & Gems")]
        public static void GiveMaxCurrencies()
        {
            var data = SaveSystem.LoadData();
            data.coins += 9999;
            data.gems += 999;
            SaveSystem.SaveData(data);
            Debug.Log("<color=yellow>[Realm Raiders]</color> Added 9,999 Coins and 999 Gems to save profile!");
        }

        [MenuItem("Tools/Realm Raiders/Data/Unlock All 4 Worlds")]
        public static void UnlockAllWorlds()
        {
            var data = SaveSystem.LoadData();
            data.unlockedWorld = 4;
            data.unlockedLevel = 4;
            SaveSystem.SaveData(data);
            Debug.Log("<color=green>[Realm Raiders]</color> All 4 Worlds & Levels unlocked!");
        }

        [MenuItem("Tools/Realm Raiders/Data/Clear Save Profile")]
        public static void ClearSaveProfile()
        {
            SaveSystem.ClearSave();
            Debug.Log("<color=red>[Realm Raiders]</color> Save profile wiped clean!");
        }

        [MenuItem("Tools/Realm Raiders/Setup/Create Realm Raiders HUD Canvas")]
        public static void CreateHUDCanvas()
        {
            var existingHUD = Object.FindObjectOfType<GameHUD>();
            if (existingHUD != null)
            {
                Selection.activeGameObject = existingHUD.gameObject;
                Debug.Log("[Realm Raiders] GameHUD already exists in scene.");
                return;
            }

            GameObject canvasObj = new GameObject("RealmRaiders_HUD_Canvas", typeof(Canvas), typeof(UnityEngine.UI.CanvasScaler), typeof(UnityEngine.UI.GraphicRaycaster), typeof(GameHUD));
            Canvas canvas = canvasObj.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;

            Undo.RegisterCreatedObjectUndo(canvasObj, "Create Realm Raiders HUD Canvas");
            Selection.activeGameObject = canvasObj;
            Debug.Log("<color=cyan>[Realm Raiders]</color> HUD Canvas created with GameHUD script!");
        }
    }
}
