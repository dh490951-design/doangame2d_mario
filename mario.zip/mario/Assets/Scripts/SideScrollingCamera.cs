using UnityEngine;

[RequireComponent(typeof(Camera))]
public class SideScrollingCamera : MonoBehaviour
{
    public static SideScrollingCamera Instance { get; private set; }

    public Transform trackedObject;
    public float height = 6.5f;
    public float undergroundHeight = -9.5f;
    public float undergroundThreshold = 0f;

    public bool isUnderground { get; private set; } = false;

    public bool isLocked = false;
    public float lockedMinX;
    public float lockedMaxX;

    public float minLevelX = 0f;

    private Camera cam;
    private float shakeTimer = 0f;
    private float shakeIntensity = 0.15f;

    public float CameraHalfWidth
    {
        get
        {
            if (cam == null) cam = GetComponent<Camera>();
            return cam != null ? cam.orthographicSize * cam.aspect : 10f;
        }
    }

    public float MinCameraX => isUnderground ? 0f : (minLevelX + CameraHalfWidth);

    private void Awake()
    {
        Instance = this;
        cam = GetComponent<Camera>();
        FindTrackedObject();
    }

    private void Start()
    {
        FindTrackedObject();
    }

    public void FindTrackedObject()
    {
        if (trackedObject == null)
        {
            var playerObj = GameObject.FindWithTag("Player");
            if (playerObj == null)
            {
                var player = FindObjectOfType<Player>();
                if (player != null) playerObj = player.gameObject;
            }
            if (playerObj != null)
            {
                trackedObject = playerObj.transform;
            }
        }
    }

    private void LateUpdate()
    {
        if (trackedObject == null)
        {
            FindTrackedObject();
            if (trackedObject == null) return;
        }

        Vector3 cameraPosition = transform.position;
        float minX = MinCameraX;

        if (!isLocked || lockedMaxX <= lockedMinX)
        {
            // Follow player freely both left and right, clamped so the camera view stays inside level bounds
            cameraPosition.x = Mathf.Max(minX, trackedObject.position.x);
        }
        else
        {
            cameraPosition.x = Mathf.Clamp(trackedObject.position.x, Mathf.Max(minX, lockedMinX), lockedMaxX);
        }

        // Keep camera Y strictly aligned with zone (surface vs underground pipe)
        cameraPosition.y = isUnderground ? undergroundHeight : height;

        // Apply screen shake
        if (shakeTimer > 0f)
        {
            Vector2 offset = Random.insideUnitCircle * shakeIntensity;
            cameraPosition.x += offset.x;
            cameraPosition.y += offset.y;
            shakeTimer -= Time.deltaTime;
        }

        transform.position = cameraPosition;
    }

    public void Shake(float duration = 0.15f, float intensity = 0.16f)
    {
        shakeTimer = duration;
        shakeIntensity = intensity;
    }

    public static void TriggerShake(float duration = 0.15f, float intensity = 0.16f)
    {
        Instance?.Shake(duration, intensity);
    }

    public void LockCamera(float minX, float maxX)
    {
        isLocked = true;
        lockedMinX = minX;
        lockedMaxX = maxX;
    }

    public void UnlockCamera()
    {
        isLocked = false;
    }

    public void SetUnderground(bool underground)
    {
        isUnderground = underground;
        Vector3 cameraPosition = transform.position;
        cameraPosition.y = isUnderground ? undergroundHeight : height;
        transform.position = cameraPosition;
    }
}
