using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public enum Type
    {
        Coin,
        ExtraLife,
        MagicMushroom,
        Starpower,
    }

    public Type type;

    private Transform playerTransform;
    private bool collected = false;

    private void Start()
    {
        if (type == Type.Coin)
        {
            FindPlayer();
        }
    }

    private void FindPlayer()
    {
        var p = GameObject.FindGameObjectWithTag("Player");
        if (p != null) playerTransform = p.transform;
    }

    private void Update()
    {
        if (collected || type != Type.Coin) return;

        if (playerTransform == null)
        {
            FindPlayer();
            if (playerTransform == null) return;
        }

        float dist = Vector2.Distance(transform.position, playerTransform.position);

        // 1. Magnet attractor when magnet buff is active
        if (Player.hasMagnetActive && dist < 10f)
        {
            transform.position = Vector3.MoveTowards(transform.position, playerTransform.position, 14f * Time.deltaTime);
        }

        // 2. Guaranteed proximity pickup (never miss a coin)
        if (dist < 1.25f)
        {
            Collect(playerTransform.GetComponent<Player>());
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (collected) return;

        if (other.CompareTag("Player") || other.GetComponentInParent<Player>() != null) {
            Collect(other.GetComponentInParent<Player>());
        }
    }

    private void Collect(Player player)
    {
        if (collected) return;
        collected = true;

        switch (type)
        {
            case Type.Coin:
                if (GameManager.Instance != null) {
                    GameManager.Instance.AddCoin(1);
                } else {
                    RealmRaiders.Data.SaveSystem.AddCoins(1);
                    RealmRaiders.Audio.AudioManager.Instance?.PlayCoin();
                }
                break;

            case Type.ExtraLife:
                GameManager.Instance?.AddLife();
                break;

            case Type.MagicMushroom:
                if (player != null) player.Grow();
                break;

            case Type.Starpower:
                if (player != null) player.Starpower();
                break;
        }

        Destroy(gameObject);
    }
}
