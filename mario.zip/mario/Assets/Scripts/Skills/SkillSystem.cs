using System;
using System.Collections;
using UnityEngine;

namespace RealmRaiders.Skills
{
    public enum SkillType
    {
        Dash,
        Freezing,
        Lightning,
        Hurricane
    }

    public class SkillSystem : MonoBehaviour
    {
        public static SkillSystem Instance { get; private set; }

        [Header("Cooldowns (seconds)")]
        [SerializeField] private float dashCooldown = 3f;
        [SerializeField] private float freezingCooldown = 8f;
        [SerializeField] private float lightningCooldown = 6f;
        [SerializeField] private float hurricaneCooldown = 12f;

        [Header("Skill Effects")]
        [SerializeField] private GameObject freezeEffectPrefab;
        [SerializeField] private GameObject lightningEffectPrefab;
        [SerializeField] private GameObject hurricaneEffectPrefab;

        private float lastDashTime = -99f;
        private float lastFreezeTime = -99f;
        private float lastLightningTime = -99f;
        private float lastHurricaneTime = -99f;

        private Rigidbody2D rb;
        private PlayerMovement playerMovement;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            rb = GetComponent<Rigidbody2D>();
            playerMovement = GetComponent<PlayerMovement>();
        }

        private void Update()
        {
            // Keybinds for testing / PC controls
            if (Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.K))
            {
                TryCastSkill(SkillType.Dash);
            }
            if (Input.GetKeyDown(KeyCode.J))
            {
                TryCastSkill(SkillType.Freezing);
            }
            if (Input.GetKeyDown(KeyCode.L))
            {
                TryCastSkill(SkillType.Lightning);
            }
            if (Input.GetKeyDown(KeyCode.U))
            {
                TryCastSkill(SkillType.Hurricane);
            }
        }

        public bool IsSkillUnlocked(SkillType skill)
        {
            var data = RealmRaiders.Data.SaveSystem.LoadData();
            if (data == null) return false;

            string id = skill switch
            {
                SkillType.Dash => "dash",
                SkillType.Freezing => "freeze",
                SkillType.Lightning => "lightning",
                SkillType.Hurricane => "hurricane",
                _ => "dash"
            };

            var s = data.skills.Find(x => x.skillId == id);
            return s != null && s.isUnlocked;
        }

        public bool TryCastSkill(SkillType skill)
        {
            if (!IsSkillUnlocked(skill))
            {
                Debug.Log($"[SkillSystem] Skill {skill} is locked! Purchase it in Shop for Coins.");
                return false;
            }

            switch (skill)
            {
                case SkillType.Dash:
                    if (Time.time - lastDashTime >= dashCooldown)
                    {
                        StartCoroutine(PerformDashRoutine());
                        lastDashTime = Time.time;
                        RealmRaiders.Audio.AudioManager.Instance?.PlayDash();
                        return true;
                    }
                    break;

                case SkillType.Freezing:
                    if (Time.time - lastFreezeTime >= freezingCooldown)
                    {
                        CastFreezing();
                        lastFreezeTime = Time.time;
                        RealmRaiders.Audio.AudioManager.Instance?.PlaySkill();
                        return true;
                    }
                    break;

                case SkillType.Lightning:
                    if (Time.time - lastLightningTime >= lightningCooldown)
                    {
                        CastLightning();
                        lastLightningTime = Time.time;
                        RealmRaiders.Audio.AudioManager.Instance?.PlayExplosion();
                        return true;
                    }
                    break;

                case SkillType.Hurricane:
                    if (Time.time - lastHurricaneTime >= hurricaneCooldown)
                    {
                        CastHurricane();
                        lastHurricaneTime = Time.time;
                        RealmRaiders.Audio.AudioManager.Instance?.PlayDash();
                        return true;
                    }
                    break;
            }
            return false;
        }

        private IEnumerator PerformDashRoutine()
        {
            float direction = transform.eulerAngles.y == 0 ? 1f : -1f;
            if (rb != null)
            {
                var player = GetComponent<Player>();
                if (player != null) player.starpower = true;

                float dashSpeed = 16f;
                float dashDuration = 0.22f;
                float elapsed = 0f;

                while (elapsed < dashDuration)
                {
                    rb.velocity = new Vector2(direction * dashSpeed, 0f);

                    // Ghost afterimage
                    if (Time.frameCount % 3 == 0)
                    {
                        var srMario = GetComponentInChildren<SpriteRenderer>();
                        if (srMario != null && srMario.sprite != null)
                        {
                            UI.CombatFeedbackManager.Instance?.SpawnDashGhost(transform.position, srMario.sprite, direction < 0, new Color(0.2f, 0.85f, 1f, 0.65f));
                        }
                    }

                    // Damage enemies dashed through
                    Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, 1.2f);
                    foreach (var h in hits)
                    {
                        if (h.gameObject != gameObject && h.IsEnemy())
                        {
                            var g = h.GetComponent<Goomba>();
                            if (g != null) g.Hit();
                            var k = h.GetComponent<Koopa>();
                            if (k != null) k.Hit();
                            var b = h.GetComponent<RealmRaiders.Boss.BossController>();
                            if (b != null) b.TakeDamage(20);
                        }
                    }

                    elapsed += Time.deltaTime;
                    yield return null;
                }

                if (player != null) player.starpower = false;
            }
        }

        private void CastFreezing()
        {
            Debug.Log("[SkillSystem] Freezing Burst activated! Freezing nearby enemies.");
            Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, 7f);
            foreach (var hit in hits)
            {
                if (hit.IsEnemy())
                {
                    var anim = hit.GetComponent<AnimatedSprite>();
                    if (anim != null) anim.enabled = false;

                    var b = hit.GetComponent<RealmRaiders.Boss.BossController>();
                    if (b != null) b.TakeDamage(30);

                    StartCoroutine(UnfreezeEnemyRoutine(hit.gameObject, 3.5f));
                }
            }
        }

        private IEnumerator UnfreezeEnemyRoutine(GameObject enemy, float delay)
        {
            yield return new WaitForSeconds(delay);
            if (enemy != null)
            {
                var anim = enemy.GetComponent<AnimatedSprite>();
                if (anim != null) anim.enabled = true;
            }
        }

        private void CastLightning()
        {
            Debug.Log("[SkillSystem] Lightning Bolt strike summoned!");
            Vector2 origin = transform.position;
            Vector2 dir = transform.eulerAngles.y == 0 ? Vector2.right : Vector2.left;

            RaycastHit2D[] hits = Physics2D.CircleCastAll(origin, 1.5f, dir, 12f);
            foreach (var hit in hits)
            {
                if (hit.collider != null && hit.collider.gameObject != gameObject)
                {
                    var goomba = hit.collider.GetComponent<Goomba>();
                    if (goomba != null) goomba.Hit();
                    var koopa = hit.collider.GetComponent<Koopa>();
                    if (koopa != null) koopa.Hit();
                    var boss = hit.collider.GetComponent<RealmRaiders.Boss.BossController>();
                    if (boss != null) boss.TakeDamage(50);
                }
            }
        }

        private void CastHurricane()
        {
            Debug.Log("[SkillSystem] Hurricane summoned! Cleansing screen.");
            Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, 8f);
            foreach (var hit in hits)
            {
                if (hit.IsEnemy())
                {
                    var rbEnemy = hit.GetComponent<Rigidbody2D>();
                    if (rbEnemy != null)
                    {
                        rbEnemy.velocity = new Vector2(UnityEngine.Random.Range(-5f, 5f), 12f);
                    }
                    var boss = hit.GetComponent<RealmRaiders.Boss.BossController>();
                    if (boss != null) boss.TakeDamage(40);
                }
            }
        }
    }
}
