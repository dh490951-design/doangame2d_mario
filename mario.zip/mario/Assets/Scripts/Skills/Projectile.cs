using UnityEngine;
using RealmRaiders.Boss;

namespace RealmRaiders.Skills
{
    [RequireComponent(typeof(Rigidbody2D), typeof(Collider2D))]
    public class Projectile : MonoBehaviour
    {
        [Header("Projectile Settings")]
        [SerializeField] private bool isPlayerProjectile = true;
        [SerializeField] private int damage = 20;
        [SerializeField] private float lifetime = 5f;
        [SerializeField] private bool bounceOnGround = true;
        [SerializeField] private float bounceForce = 4.5f;

        [Header("FX on Impact")]
        [SerializeField] private GameObject impactEffectPrefab;

        private Rigidbody2D rb;

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            Destroy(gameObject, lifetime);
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if (bounceOnGround && collision.contacts.Length > 0 && collision.contacts[0].normal.y > 0.5f)
            {
                rb.velocity = new Vector2(rb.velocity.x, bounceForce);
                return;
            }

            HandleHit(collision.gameObject);
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            HandleHit(other.gameObject);
        }

        private void HandleHit(GameObject hitObj)
        {
            if (isPlayerProjectile)
            {
                if (hitObj.IsEnemy())
                {
                    var goomba = hitObj.GetComponent<Goomba>();
                    if (goomba != null) goomba.Hit();

                    var koopa = hitObj.GetComponent<Koopa>();
                    if (koopa != null) koopa.Hit();

                    var boss = hitObj.GetComponent<BossController>();
                    if (boss != null) boss.TakeDamage(damage);

                    Explode();
                }
            }
            else
            {
                // Boss or enemy projectile hitting player
                if (hitObj.CompareTag("Player"))
                {
                    var player = hitObj.GetComponent<Player>();
                    if (player != null) player.Hit();
                    Explode();
                }
            }
        }

        private void Explode()
        {
            if (impactEffectPrefab != null)
            {
                Instantiate(impactEffectPrefab, transform.position, Quaternion.identity);
            }
            Destroy(gameObject);
        }
    }
}
