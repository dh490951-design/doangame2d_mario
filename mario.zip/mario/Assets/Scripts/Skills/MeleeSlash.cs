using System.Collections;
using UnityEngine;
using RealmRaiders.Boss;

namespace RealmRaiders.Skills
{
    public class MeleeSlash : MonoBehaviour
    {
        public static MeleeSlash Instance { get; private set; }

        [Header("Slash Settings")]
        [SerializeField] private float slashCooldown = 0.3f;
        [SerializeField] private float slashRange = 1.8f;
        [SerializeField] private int slashDamage = 25;

        private float lastSlashTime = -99f;
        private Texture2D slashTexture;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            slashTexture = new Texture2D(1, 1);
            slashTexture.SetPixel(0, 0, Color.cyan);
            slashTexture.Apply();
        }

        private void Update()
        {
            // Trigger with F or Left Mouse Button
            if (Input.GetKeyDown(KeyCode.F) || Input.GetMouseButtonDown(0))
            {
                PerformSlash();
            }
        }

        public bool PerformSlash()
        {
            if (Time.time - lastSlashTime < slashCooldown) return false;
            lastSlashTime = Time.time;

            // Audio
            Audio.AudioManager.Instance?.PlaySlash();

            // Determine direction based on local scale or facing
            float facing = transform.localScale.x > 0 ? 1f : -1f;
            if (TryGetComponent<PlayerMovement>(out var pm))
            {
                facing = transform.eulerAngles.y == 0 ? 1f : -1f;
            }

            Vector2 slashOrigin = (Vector2)transform.position + new Vector2(facing * 0.8f, 0.4f);

            // Visual Slash Arc Effect
            StartCoroutine(SlashEffectRoutine(slashOrigin, facing));
            UI.CombatFeedbackManager.Instance?.ShowPopup(slashOrigin, "⚔️", new Color(0.2f, 0.95f, 1f), 0.35f);

            // Hit detection
            Collider2D[] hits = Physics2D.OverlapCircleAll(slashOrigin, slashRange);
            foreach (var hit in hits)
            {
                if (hit.IsEnemy())
                {
                    SideScrollingCamera.TriggerShake(0.12f, 0.15f);
                    var goomba = hit.GetComponent<Goomba>();
                    if (goomba != null) goomba.Hit();

                    var koopa = hit.GetComponent<Koopa>();
                    if (koopa != null) koopa.Hit();

                    var boss = hit.GetComponent<BossController>();
                    if (boss != null) boss.TakeDamage(slashDamage);

                    Debug.Log("<color=cyan>[Slash]</color> Melee hit landed on enemy!");
                }

                var chest = hit.GetComponent<RealmRaiders.Environment.TreasureChest>();
                if (chest != null)
                {
                    chest.OpenChest();
                }
            }

            return true;
        }

        private IEnumerator SlashEffectRoutine(Vector2 origin, float direction)
        {
            GameObject slashObj = new GameObject("Slash_VFX");
            slashObj.transform.position = origin;
            slashObj.transform.localScale = new Vector3(direction * 1.5f, 1.2f, 1f);

            var sr = slashObj.AddComponent<SpriteRenderer>();
            sr.sprite = Resources.Load<Sprite>("Coin"); // Use shiny asset or white
            sr.color = new Color(0.2f, 0.95f, 1f, 0.9f);
            sr.sortingOrder = 15;

            float elapsed = 0f;
            float duration = 0.15f;

            while (elapsed < duration)
            {
                float t = elapsed / duration;
                slashObj.transform.localScale = new Vector3(direction * Mathf.Lerp(0.8f, 2.2f, t), Mathf.Lerp(0.5f, 1.6f, t), 1f);
                sr.color = new Color(0.2f, 0.95f, 1f, 1f - t);
                elapsed += Time.deltaTime;
                yield return null;
            }

            Destroy(slashObj);
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(transform.position + Vector3.right * 1.0f, slashRange);
        }
    }
}
