using UnityEngine;
using UnityEngine.UI;
using RealmRaiders.Achievements;
using RealmRaiders.Data;
using RealmRaiders.Audio;

namespace RealmRaiders.UI
{
    public class AchievementUIController : MonoBehaviour
    {
        [System.Serializable]
        public class AchievementSlot
        {
            public string achievementId;
            public Text nameText;
            public Text rewardGemsText;
            public Image starIcon;
            public GameObject checkmarkObj;
        }

        [SerializeField] private AchievementSlot[] slots;

        private void OnEnable()
        {
            AchievementManager.OnAchievementsChanged += RefreshSlots;
            RefreshSlots();
        }

        private void OnDisable()
        {
            AchievementManager.OnAchievementsChanged -= RefreshSlots;
        }

        public void RefreshSlots()
        {
            var data = SaveSystem.LoadData();

            foreach (var slot in slots)
            {
                bool isUnlocked = data.unlockedAchievements.Contains(slot.achievementId);
                if (slot.checkmarkObj != null)
                {
                    slot.checkmarkObj.SetActive(isUnlocked);
                }
                if (slot.starIcon != null)
                {
                    slot.starIcon.color = isUnlocked ? Color.yellow : Color.gray;
                }
            }
        }
    }
}
