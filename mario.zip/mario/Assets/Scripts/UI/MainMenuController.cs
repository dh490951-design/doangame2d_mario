using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using RealmRaiders.Localization;
using RealmRaiders.Data;

namespace RealmRaiders.UI
{
    public class MainMenuController : MonoBehaviour
    {
        [Header("UI Panels")]
        [SerializeField] private GameObject mainPanel;
        [SerializeField] private GameObject optionsPanel;
        [SerializeField] private GameObject worldMapPanel;

        [Header("Language Buttons")]
        [SerializeField] private Text languageDisplayTxt;

        private void Start()
        {
            UpdateLanguageDisplay();
        }

        public void OnResumeClicked()
        {
            var data = SaveSystem.LoadData();
            // Load world map or last level
            if (worldMapPanel != null)
            {
                worldMapPanel.SetActive(true);
                mainPanel.SetActive(false);
            }
            else
            {
                SceneManager.LoadScene("1-1");
            }
        }

        public void OnNewGameClicked()
        {
            SaveSystem.ClearSave();
            SceneManager.LoadScene("1-1");
        }

        public void OnOptionsClicked()
        {
            if (optionsPanel != null)
            {
                optionsPanel.SetActive(true);
            }
        }

        public void OnCloseOptionsClicked()
        {
            if (optionsPanel != null)
            {
                optionsPanel.SetActive(false);
            }
        }

        public void OnToggleLanguageClicked()
        {
            if (LocalizationManager.Instance != null)
            {
                LocalizationManager.Instance.ToggleLanguage();
                UpdateLanguageDisplay();
            }
        }

        private void UpdateLanguageDisplay()
        {
            if (languageDisplayTxt != null && LocalizationManager.Instance != null)
            {
                languageDisplayTxt.text = LocalizationManager.Instance.CurrentLanguage == Language.Vietnamese
                    ? "Tiếng Việt"
                    : "English";
            }
        }

        public void OnQuitClicked()
        {
            Debug.Log("[MainMenu] Exiting Application.");
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }
    }
}
