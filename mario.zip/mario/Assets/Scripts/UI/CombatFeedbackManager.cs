using System.Collections.Generic;
using UnityEngine;

namespace RealmRaiders.UI
{
    public class CombatFeedbackManager : MonoBehaviour
    {
        public static CombatFeedbackManager Instance { get; private set; }

        private struct FloatingText
        {
            public Vector3 worldPos;
            public string text;
            public Color color;
            public float timeRemaining;
            public float totalDuration;
            public float riseSpeed;
        }

        private List<FloatingText> activeTexts = new();
        private Camera mainCam;

        // Combo Tracker
        public int currentCombo { get; private set; } = 0;
        private float comboTimer = 0f;
        private const float COMBO_TIMEOUT = 3.5f;

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void Update()
        {
            mainCam = Camera.main;

            // Update floating texts
            for (int i = activeTexts.Count - 1; i >= 0; i--)
            {
                var ft = activeTexts[i];
                ft.timeRemaining -= Time.deltaTime;
                ft.worldPos += Vector3.up * (ft.riseSpeed * Time.deltaTime);

                if (ft.timeRemaining <= 0f)
                {
                    activeTexts.RemoveAt(i);
                }
                else
                {
                    activeTexts[i] = ft;
                }
            }

            // Update combo timer
            if (currentCombo > 0)
            {
                comboTimer -= Time.deltaTime;
                if (comboTimer <= 0f)
                {
                    currentCombo = 0;
                }
            }
        }

        public void ShowPopup(Vector3 worldPos, string text, Color color, float duration = 0.9f)
        {
            // Limit max simultaneous popups to prevent screen clutter
            if (activeTexts.Count > 15) activeTexts.RemoveAt(0);

            activeTexts.Add(new FloatingText
            {
                worldPos = worldPos + new Vector3(Random.Range(-0.3f, 0.3f), Random.Range(0.2f, 0.5f), 0f),
                text = text,
                color = color,
                timeRemaining = duration,
                totalDuration = duration,
                riseSpeed = 1.4f
            });
        }

        public void RegisterKill(string enemyName, Vector3 worldPos)
        {
            currentCombo++;
            comboTimer = COMBO_TIMEOUT;

            string comboMsg = "";
            if (currentCombo == 2)
            {
                comboMsg = "🔥 2x COMBO! (+50 Score)";
                Data.SaveSystem.Current.currentScore += 50;
            }
            else if (currentCombo == 3)
            {
                comboMsg = "🔥 3x COMBO! (+100 Score)";
                Data.SaveSystem.Current.currentScore += 100;
            }
            else if (currentCombo == 5)
            {
                comboMsg = "⚡ 5x MEGA COMBO! (+10 Xu)";
                GameManager.Instance?.AddCoin(10);
                Audio.AudioManager.Instance?.PlayCoin();
            }
            else if (currentCombo >= 10 && currentCombo % 5 == 0)
            {
                comboMsg = $"💥 {currentCombo}x UNSTOPPABLE! (+25 Xu & +2 Ngọc)";
                GameManager.Instance?.AddCoin(25);
                Data.SaveSystem.Current.gems += 2;
                Data.SaveSystem.SaveData();
                Audio.AudioManager.Instance?.PlayCoin();
            }

            if (!string.IsNullOrEmpty(comboMsg))
            {
                ShowPopup(worldPos + Vector3.up * 0.8f, comboMsg, new Color(1f, 0.85f, 0.2f), 1.2f);
            }
        }

        public void SpawnDashGhost(Vector3 position, Sprite sprite, bool flipX, Color color)
        {
            GameObject ghost = new GameObject("Dash_Ghost");
            ghost.transform.position = position;
            ghost.transform.eulerAngles = flipX ? new Vector3(0f, 180f, 0f) : Vector3.zero;

            var sr = ghost.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            sr.color = color;
            sr.sortingOrder = 3;

            StartCoroutine(FadeAndDestroyRoutine(ghost, sr, 0.25f));
        }

        private System.Collections.IEnumerator FadeAndDestroyRoutine(GameObject obj, SpriteRenderer sr, float duration)
        {
            float elapsed = 0f;
            Color initialColor = sr.color;

            while (elapsed < duration)
            {
                if (sr == null) yield break;
                float t = elapsed / duration;
                sr.color = new Color(initialColor.r, initialColor.g, initialColor.b, (1f - t) * initialColor.a);
                elapsed += Time.deltaTime;
                yield return null;
            }

            if (obj != null) Destroy(obj);
        }

        private void OnGUI()
        {
            if (mainCam == null) mainCam = Camera.main;
            if (mainCam == null) return;

            // 1. Render Floating Texts
            for (int i = 0; i < activeTexts.Count; i++)
            {
                var ft = activeTexts[i];
                Vector3 screenPos = mainCam.WorldToScreenPoint(ft.worldPos);

                // Ignore if behind camera
                if (screenPos.z < 0f) continue;

                float alpha = Mathf.Clamp01(ft.timeRemaining / (ft.totalDuration * 0.6f));
                Color textColor = new Color(ft.color.r, ft.color.g, ft.color.b, alpha);

                float guiY = Screen.height - screenPos.y;
                float w = 240f;
                float h = 30f;
                Rect r = new Rect(screenPos.x - w * 0.5f, guiY - h * 0.5f, w, h);

                GUIStyle style = new GUIStyle(GUI.skin.label)
                {
                    fontSize = 15,
                    fontStyle = FontStyle.Bold,
                    alignment = TextAnchor.MiddleCenter
                };

                // Shadow
                style.normal.textColor = new Color(0f, 0f, 0f, alpha * 0.85f);
                GUI.Label(new Rect(r.x + 1, r.y + 1, r.width, r.height), ft.text, style);

                // Main Text
                style.normal.textColor = textColor;
                GUI.Label(r, ft.text, style);
            }

            // 2. Render Active Combo Counter (Top Left)
            if (currentCombo >= 2)
            {
                Rect comboRect = new Rect(20, 65, 200, 32);
                GUIStyle comboStyle = new GUIStyle(GUI.skin.label)
                {
                    fontSize = 17,
                    fontStyle = FontStyle.Bold
                };

                comboStyle.normal.textColor = Color.black;
                GUI.Label(new Rect(comboRect.x + 1, comboRect.y + 1, comboRect.width, comboRect.height), $"🔥 COMBO: x{currentCombo}", comboStyle);

                comboStyle.normal.textColor = new Color(1f, 0.7f, 0.1f);
                GUI.Label(comboRect, $"🔥 COMBO: x{currentCombo}", comboStyle);
            }
        }
    }
}
