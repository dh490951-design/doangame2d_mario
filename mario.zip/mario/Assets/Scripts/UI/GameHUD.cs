using UnityEngine;
using UnityEngine.UI;
using RealmRaiders.Data;
using RealmRaiders.Skills;
using RealmRaiders.Boss;

namespace RealmRaiders.UI
{
    public class GameHUD : MonoBehaviour
    {
        public static GameHUD Instance { get; private set; }

        [Header("Counters")]
        [SerializeField] private Text coinsText;
        [SerializeField] private Text gemsText;
        [SerializeField] private Text livesText;
        [SerializeField] private Text scoreText;

        [Header("Skill Key Prompts")]
        [SerializeField] private Image dashSkillIcon;
        [SerializeField] private Image freezeSkillIcon;
        [SerializeField] private Image lightningSkillIcon;
        [SerializeField] private Image hurricaneSkillIcon;

        [Header("Boss Bar")]
        [SerializeField] private GameObject bossBarContainer;
        [SerializeField] private Slider bossHpSlider;
        [SerializeField] private Text bossTitleText;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);
        }

        private void Start()
        {
            UpdateStatsDisplay();
            if (bossBarContainer != null) bossBarContainer.SetActive(false);

            BossController.OnBossDefeated += HandleBossDefeated;
        }

        private void OnDestroy()
        {
            BossController.OnBossDefeated -= HandleBossDefeated;
        }

        private void Update()
        {
            UpdateStatsDisplay();
        }

        public void UpdateStatsDisplay()
        {
            var data = SaveSystem.Current;
            int currentCoins = GameManager.Instance != null ? Mathf.Max(data.coins, GameManager.Instance.coins) : data.coins;
            if (coinsText != null) coinsText.text = $"x{currentCoins:00}";
            if (gemsText != null) gemsText.text = $"x{data.gems:00}";
            if (livesText != null) livesText.text = $"x{GameManager.Instance?.lives ?? 3}";
            if (scoreText != null) scoreText.text = $"{data.currentScore:000000}";
        }

        public void SetupBossBar(string name, int maxHp)
        {
            if (bossBarContainer != null)
            {
                bossBarContainer.SetActive(true);
                if (bossTitleText != null) bossTitleText.text = name;
                if (bossHpSlider != null)
                {
                    bossHpSlider.maxValue = maxHp;
                    bossHpSlider.value = maxHp;
                }
            }
        }

        public void UpdateBossHp(int currentHp)
        {
            if (bossHpSlider != null) bossHpSlider.value = currentHp;
        }

        private void HandleBossDefeated(BossController boss)
        {
            if (bossBarContainer != null) bossBarContainer.SetActive(false);
            var data = SaveSystem.LoadData();
            data.gems += 50;
            SaveSystem.SaveData(data);
            UpdateStatsDisplay();
        }
    }
}
