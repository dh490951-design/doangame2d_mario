using UnityEngine;
using UnityEngine.UI;
using RealmRaiders.Quests;
using RealmRaiders.Data;
using RealmRaiders.Localization;
using RealmRaiders.Audio;

namespace RealmRaiders.UI
{
    public class QuestUIController : MonoBehaviour
    {
        [System.Serializable]
        public class QuestCard
        {
            public string questId;
            public Text titleText;
            public Slider progressSlider;
            public Text progressText;
            public Button claimButton;
            public GameObject completedIcon;
        }

        [SerializeField] private QuestCard[] questCards;

        private void OnEnable()
        {
            QuestManager.OnQuestsUpdated += RefreshCards;
            RefreshCards();
        }

        private void OnDisable()
        {
            QuestManager.OnQuestsUpdated -= RefreshCards;
        }

        public void RefreshCards()
        {
            var data = SaveSystem.LoadData();

            foreach (var card in questCards)
            {
                var q = data.dailyQuests.Find(x => x.questId == card.questId) ??
                        data.storyQuests.Find(x => x.questId == card.questId);

                if (q != null)
                {
                    if (card.progressSlider != null)
                    {
                        card.progressSlider.maxValue = q.targetAmount;
                        card.progressSlider.value = q.currentAmount;
                    }
                    if (card.progressText != null)
                    {
                        card.progressText.text = $"{q.currentAmount}/{q.targetAmount}";
                    }
                    if (card.claimButton != null)
                    {
                        card.claimButton.interactable = (q.currentAmount >= q.targetAmount && !q.isClaimed);
                    }
                    if (card.completedIcon != null)
                    {
                        card.completedIcon.SetActive(q.isClaimed);
                    }
                }
            }
        }

        public void ClaimReward(string questId)
        {
            if (QuestManager.Instance.ClaimReward(questId))
            {
                AudioManager.Instance?.PlayCoin();
                RefreshCards();
            }
        }
    }
}
