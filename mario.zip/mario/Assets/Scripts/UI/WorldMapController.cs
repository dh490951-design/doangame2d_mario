using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using RealmRaiders.Data;

namespace RealmRaiders.UI
{
    public class WorldMapController : MonoBehaviour
    {
        [System.Serializable]
        public class WorldNode
        {
            public int worldIndex;
            public string sceneName;
            public Button selectButton;
            public GameObject lockIcon;
        }

        [SerializeField] private WorldNode[] worlds;

        private void Start()
        {
            RefreshWorldMap();
        }

        public void RefreshWorldMap()
        {
            var data = SaveSystem.LoadData();
            foreach (var node in worlds)
            {
                bool isUnlocked = node.worldIndex <= data.unlockedWorld;
                if (node.selectButton != null)
                {
                    node.selectButton.interactable = isUnlocked;
                }
                if (node.lockIcon != null)
                {
                    node.lockIcon.SetActive(!isUnlocked);
                }
            }
        }

        public void SelectWorld(int worldIndex)
        {
            var data = SaveSystem.LoadData();
            if (worldIndex <= data.unlockedWorld)
            {
                data.currentWorld = worldIndex;
                SaveSystem.SaveData(data);

                // Load corresponding scene
                string sceneName = worldIndex switch
                {
                    1 => "1-1",
                    2 => "2-1",
                    3 => "3-1",
                    4 => "4-1",
                    _ => "1-1"
                };

                SceneManager.LoadScene(sceneName);
            }
        }
    }
}
