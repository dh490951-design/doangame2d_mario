using UnityEngine;
using UnityEngine.SceneManagement;
using RealmRaiders.Localization;
using RealmRaiders.Data;
using RealmRaiders.Shop;
using RealmRaiders.Quests;
using RealmRaiders.Achievements;
using RealmRaiders.Audio;
using RealmRaiders.Skills;

namespace RealmRaiders.UI
{
    public class MasterMenuOverlay : MonoBehaviour
    {
        public static MasterMenuOverlay Instance { get; private set; }

        private bool isPaused = false;
        private bool isVictory = false;
        private bool isStageClear = false;
        private int clearWorld = 1;
        private int clearCoins = 0;
        private int clearGems = 0;
        private int clearNextWorld = 1;

        private int currentTab = 0; // 0: Main/Pause, 1: World Select, 2: Shop & Skills, 3: Difficulty, 4: Quests, 5: Achievements

        public void ShowVictoryPopup()
        {
            isVictory = true;
        }

        private float clearTimeSpent = 0f;
        private bool clearIsNewRecord = false;
        private Vector2 menuScrollPos = Vector2.zero;

        public void ShowStageClear(int world, int bonusCoins, int bonusGems, int nextWorld, float timeSpent = 0f, bool isNewRecord = false)
        {
            isStageClear = true;
            clearWorld = world;
            clearCoins = bonusCoins;
            clearGems = bonusGems;
            clearNextWorld = nextWorld;
            clearTimeSpent = timeSpent;
            clearIsNewRecord = isNewRecord;
        }

        private Texture2D whiteBoxTex;
        private Texture2D coinTex;
        private Texture2D gemTex;
        private Texture2D heartTex;

        private void EnsureTextures()
        {
            if (whiteBoxTex == null)
            {
                whiteBoxTex = new Texture2D(1, 1);
                whiteBoxTex.SetPixel(0, 0, Color.white);
                whiteBoxTex.Apply();
            }

            if (coinTex == null)
            {
                coinTex = Resources.Load<Texture2D>("Coin") ?? (Resources.Load<Sprite>("Coin")?.texture) ?? CreateProceduralCoinTex();
            }

            if (gemTex == null)
            {
                gemTex = Resources.Load<Texture2D>("Gem") ?? (Resources.Load<Sprite>("Gem")?.texture) ?? CreateProceduralGemTex();
            }

            if (heartTex == null)
            {
                heartTex = Resources.Load<Texture2D>("Heart") ?? (Resources.Load<Sprite>("Heart")?.texture) ?? CreateProceduralHeartTex();
            }
        }

        private Texture2D CreateProceduralCoinTex()
        {
            int s = 16;
            Texture2D tex = new Texture2D(s, s, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            Color gold = new Color(1f, 0.84f, 0.0f);
            Color darkGold = new Color(0.85f, 0.60f, 0.0f);
            Color shine = new Color(1f, 1f, 0.6f);
            float center = (s - 1) * 0.5f;

            for (int y = 0; y < s; y++)
            {
                for (int x = 0; x < s; x++)
                {
                    float d = Vector2.Distance(new Vector2(x, y), new Vector2(center, center));
                    if (d > center) tex.SetPixel(x, y, Color.clear);
                    else if (d > center - 1.5f) tex.SetPixel(x, y, darkGold);
                    else if (x < 6 && y > 8) tex.SetPixel(x, y, shine);
                    else tex.SetPixel(x, y, gold);
                }
            }
            tex.Apply();
            return tex;
        }

        private Texture2D CreateProceduralGemTex()
        {
            int s = 16;
            Texture2D tex = new Texture2D(s, s, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            Color cyan = new Color(0.2f, 0.9f, 1f);
            Color darkBlue = new Color(0.0f, 0.5f, 0.8f);
            Color white = Color.white;

            for (int y = 0; y < s; y++)
            {
                for (int x = 0; x < s; x++)
                {
                    float manhattan = Mathf.Abs(x - 7.5f) + Mathf.Abs(y - 7.5f);
                    if (manhattan > 7f) tex.SetPixel(x, y, Color.clear);
                    else if (manhattan > 5.5f) tex.SetPixel(x, y, darkBlue);
                    else if (x <= 7 && y >= 8) tex.SetPixel(x, y, white);
                    else tex.SetPixel(x, y, cyan);
                }
            }
            tex.Apply();
            return tex;
        }

        private Texture2D CreateProceduralHeartTex()
        {
            int s = 16;
            Texture2D tex = new Texture2D(s, s, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            Color red = new Color(1f, 0.18f, 0.28f);
            Color dark = new Color(0.6f, 0.05f, 0.15f);
            Color shine = new Color(1f, 0.85f, 0.9f);

            for (int y = 0; y < s; y++)
            {
                for (int x = 0; x < s; x++)
                {
                    float nx = (x - 7.5f) / 7.5f;
                    float ny = (y - 7.5f) / 7.5f;
                    float heart = (nx * nx + ny * ny - 0.7f);
                    heart = heart * heart * heart - nx * nx * ny * ny * ny;
                    if (heart > 0.05f) tex.SetPixel(x, y, Color.clear);
                    else if (heart > -0.05f) tex.SetPixel(x, y, dark);
                    else if (nx < -0.2f && ny > 0.2f) tex.SetPixel(x, y, shine);
                    else tex.SetPixel(x, y, red);
                }
            }
            tex.Apply();
            return tex;
        }

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
                SceneManager.sceneLoaded += OnSceneLoaded;

                whiteBoxTex = new Texture2D(1, 1);
                whiteBoxTex.SetPixel(0, 0, Color.white);
                whiteBoxTex.Apply();
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            if (scene.name == "MainMenu")
            {
                isPaused = true;
                FreezeEntities();
            }
            else
            {
                isPaused = false;
                Time.timeScale = 1f;
            }
        }

        private void FreezeEntities()
        {
            var enemies = FindObjectsOfType<EntityMovement>();
            foreach (var e in enemies) e.enabled = false;

            var playerMove = FindObjectOfType<PlayerMovement>();
            if (playerMove != null) playerMove.enabled = false;
        }

        private void Update()
        {
            string activeScene = SceneManager.GetActiveScene().name;
            if (activeScene == "MainMenu")
            {
                FreezeEntities();
                return;
            }

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                isPaused = !isPaused;
                Time.timeScale = isPaused ? 0f : 1f;
                currentTab = 0;
            }
        }

        private void OnGUI()
        {
            bool isVi = LocalizationManager.Instance?.CurrentLanguage == Language.Vietnamese;

            // Check if Victory
            if (isVictory)
            {
                RenderVictoryGUI(isVi);
                return;
            }

            // Check if Stage Cleared
            if (isStageClear)
            {
                RenderStageClearGUI(isVi);
                return;
            }

            // Check if Game Over
            if (GameManager.Instance != null && GameManager.Instance.isGameOver)
            {
                RenderGameOverGUI(isVi);
                return;
            }

            string sceneName = SceneManager.GetActiveScene().name;
            bool isMainMenuScene = sceneName == "MainMenu";

            // If in level and not paused, render in-game HUD only (clean screen, controls via keyboard)
            if (!isMainMenuScene && !isPaused)
            {
                RenderInGameHUD(isVi);
                return;
            }

            // Otherwise, render full menu / pause menu
            RenderMenuGUI(isMainMenuScene, isVi);
        }

        private void RenderInGameHUD(bool isVi)
        {
            int currentCoins = SaveSystem.Current.coins;
            if (GameManager.Instance != null)
            {
                currentCoins = Mathf.Max(currentCoins, GameManager.Instance.coins);
                GameManager.Instance.coins = currentCoins;
            }
            int currentLives = GameManager.Instance != null ? GameManager.Instance.lives : 3;
            int currentGems = SaveSystem.Current.gems;

            // Centered sleek floating capsule bar showing ONLY: Heart, Coin, Gem (with real graphics)
            float barW = 340f;
            float barH = 46f;
            Rect barRect = new Rect((Screen.width - barW) * 0.5f, 22f, barW, barH);

            EnsureTextures();

            // Dark glass background
            GUI.color = new Color(0.06f, 0.08f, 0.14f, 0.90f);
            GUI.DrawTexture(barRect, whiteBoxTex);

            // Glowing border
            GUI.color = new Color(0.0f, 0.85f, 1.0f, 0.7f);
            GUI.DrawTexture(new Rect(barRect.x, barRect.y, barRect.width, 2), whiteBoxTex);
            GUI.DrawTexture(new Rect(barRect.x, barRect.y + barRect.height - 2, barRect.width, 2), whiteBoxTex);
            GUI.color = Color.white;

            GUI.skin.label.fontSize = 18;

            // ❤️ TIM / MẠNG (Hình ảnh trái tim pixel art)
            if (heartTex != null)
            {
                GUI.DrawTexture(new Rect(barRect.x + 14, barRect.y + 11, 24, 24), heartTex, ScaleMode.ScaleToFit);
            }
            GUI.Label(new Rect(barRect.x + 42, barRect.y + 9, 60, 28), $"<color=#FF4466><b>{currentLives}</b></color>");

            // 🪙 XU VÀNG (Hình ảnh đồng xu pixel art)
            if (coinTex != null)
            {
                GUI.DrawTexture(new Rect(barRect.x + 112, barRect.y + 11, 24, 24), coinTex, ScaleMode.ScaleToFit);
            }
            GUI.Label(new Rect(barRect.x + 140, barRect.y + 9, 75, 28), $"<color=#FFD700><b>{currentCoins}</b></color>");

            // 💎 NGỌC (Hình ảnh kim cương pixel art)
            if (gemTex != null)
            {
                GUI.DrawTexture(new Rect(barRect.x + 224, barRect.y + 11, 24, 24), gemTex, ScaleMode.ScaleToFit);
            }
            GUI.Label(new Rect(barRect.x + 252, barRect.y + 9, 75, 28), $"<color=#00FFFF><b>{currentGems}</b></color>");

            // Active Buff Indicators (Khiên & Nam Châm)
            if (Player.hasShieldActive || Player.hasMagnetActive)
            {
                string buffText = "";
                if (Player.hasShieldActive) buffText += "<color=#00FFFF>[🛡️ KHIÊN]</color> ";
                if (Player.hasMagnetActive) buffText += $"<color=#FFD700>[🧲 HÚT XU {Player.magnetTimer:0}s]</color>";

                GUI.skin.label.fontSize = 14;
                GUI.Label(new Rect((Screen.width - 260) * 0.5f, barRect.y + barH + 4, 260, 24), buffText, GetCenterLabelStyle());
            }

            // Boss Health Bar (World 4)
            var boss = RealmRaiders.Boss.BossController.Instance;
            if (boss != null && boss.gameObject.activeInHierarchy && boss.CurrentHealth > 0)
            {
                float bW = 340f;
                float bH = 22f;
                Rect bRect = new Rect((Screen.width - bW) * 0.5f, barRect.y + barH + 6, bW, bH);

                GUI.color = new Color(0.12f, 0.05f, 0.08f, 0.92f);
                GUI.DrawTexture(bRect, whiteBoxTex);

                float pct = Mathf.Clamp01((float)boss.CurrentHealth / boss.MaxHealth);
                GUI.color = Color.Lerp(Color.red, new Color(1f, 0.2f, 0.2f), pct);
                GUI.DrawTexture(new Rect(bRect.x + 2, bRect.y + 2, (bRect.width - 4) * pct, bRect.height - 4), whiteBoxTex);

                GUI.color = new Color(1f, 0.8f, 0.2f, 0.9f);
                GUI.DrawTexture(new Rect(bRect.x, bRect.y, bRect.width, 1), whiteBoxTex);
                GUI.DrawTexture(new Rect(bRect.x, bRect.y + bRect.height - 1, bRect.width, 1), whiteBoxTex);
                GUI.color = Color.white;

                GUI.skin.label.fontSize = 12;
                GUI.Label(bRect, $"<b>🐉 {boss.BossName}: {boss.CurrentHealth} / {boss.MaxHealth} HP</b>", GetCenterLabelStyle());
            }

            // Mini Level Progress Track (Top Right)
            var playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null)
            {
                float prog = Mathf.Clamp01(playerObj.transform.position.x / 200f);
                float progW = 110f;
                float progH = 6f;
                float progX = Screen.width - 195f;
                float progY = 41f;

                GUI.color = new Color(0.08f, 0.12f, 0.22f, 0.85f);
                GUI.DrawTexture(new Rect(progX, progY, progW, progH), whiteBoxTex);

                GUI.color = new Color(0.0f, 0.88f, 1.0f, 0.95f);
                GUI.DrawTexture(new Rect(progX, progY, progW * prog, progH), whiteBoxTex);

                GUI.color = Color.white;
                GUI.skin.label.fontSize = 11;
                GUI.Label(new Rect(progX + progW + 2, progY - 7, 20, 20), "🏰");
                GUI.Label(new Rect(progX + progW * prog - 6, progY - 14, 20, 20), "🏃");
            }

            // Top-right Pause button (Glass plate with 2 crisp solid white bars)
            Rect pauseRect = new Rect(Screen.width - 62, 22, 46, 44);

            // Dark glass plate
            GUI.color = new Color(0.08f, 0.12f, 0.22f, 0.92f);
            GUI.DrawTexture(pauseRect, whiteBoxTex);

            // Glowing cyan border
            GUI.color = new Color(0.0f, 0.85f, 1.0f, 0.85f);
            GUI.DrawTexture(new Rect(pauseRect.x, pauseRect.y, pauseRect.width, 2), whiteBoxTex);
            GUI.DrawTexture(new Rect(pauseRect.x, pauseRect.y + pauseRect.height - 2, pauseRect.width, 2), whiteBoxTex);
            GUI.DrawTexture(new Rect(pauseRect.x, pauseRect.y, 2, pauseRect.height), whiteBoxTex);
            GUI.DrawTexture(new Rect(pauseRect.x + pauseRect.width - 2, pauseRect.y, 2, pauseRect.height), whiteBoxTex);

            // Two solid crisp white pause bars (||)
            GUI.color = Color.white;
            GUI.DrawTexture(new Rect(pauseRect.x + 15, pauseRect.y + 11, 5, 22), whiteBoxTex);
            GUI.DrawTexture(new Rect(pauseRect.x + 26, pauseRect.y + 11, 5, 22), whiteBoxTex);

            // Transparent click hit area
            GUI.color = Color.clear;
            if (GUI.Button(pauseRect, ""))
            {
                isPaused = true;
                Time.timeScale = 0f;
                currentTab = 0;
                menuScrollPos = Vector2.zero;
            }
            GUI.color = Color.white;
        }

        private void RenderGameOverGUI(bool isVi)
        {
            float w = Mathf.Min(480, Screen.width - 40);
            float h = 320;
            Rect rect = new Rect((Screen.width - w) * 0.5f, (Screen.height - h) * 0.5f, w, h);

            GUI.color = new Color(0.12f, 0.05f, 0.08f, 0.98f);
            GUI.DrawTexture(rect, whiteBoxTex);

            GUI.color = Color.red;
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width, 4), whiteBoxTex);
            GUI.DrawTexture(new Rect(rect.x, rect.y + rect.height - 4, rect.width, 4), whiteBoxTex);
            GUI.color = Color.white;

            GUILayout.BeginArea(new Rect(rect.x + 25, rect.y + 20, rect.width - 50, rect.height - 40));

            GUI.skin.label.fontSize = 28;
            GUILayout.Label("<color=#FF3344><b>☠ TRÒ CHƠI KẾT THÚC ☠</b></color>", GetCenterLabelStyle());
            GUI.skin.label.fontSize = 16;
            GUILayout.Label(isVi ? "Bạn đã hết mạng! Hãy thử lại hoặc về Menu." : "You ran out of lives! Try again or return to Menu.", GetCenterLabelStyle());
            GUILayout.Space(25);

            if (GUILayout.Button(isVi ? "🔄 HỒI SINH & THỬ LẠI MÀN NÀY" : "🔄 RETRY CURRENT LEVEL", GUILayout.Height(50)))
            {
                GameManager.Instance?.RetryCurrentLevel();
            }

            GUILayout.Space(10);
            if (GUILayout.Button(isVi ? "🏠 VỀ MENU CHÍNH" : "🏠 RETURN TO MAIN MENU", GUILayout.Height(44)))
            {
                GameManager.Instance?.RetryCurrentLevel();
                SceneManager.LoadScene("MainMenu");
            }

            GUILayout.EndArea();
        }

        private void RenderStageClearGUI(bool isVi)
        {
            float w = Mathf.Min(480, Screen.width - 40);
            float h = 330;
            Rect rect = new Rect((Screen.width - w) * 0.5f, (Screen.height - h) * 0.5f, w, h);

            GUI.color = new Color(0.06f, 0.12f, 0.22f, 0.98f);
            GUI.DrawTexture(rect, whiteBoxTex);

            GUI.color = new Color(0.0f, 0.85f, 1.0f);
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width, 4), whiteBoxTex);
            GUI.DrawTexture(new Rect(rect.x, rect.y + rect.height - 4, rect.width, 4), whiteBoxTex);
            GUI.color = Color.white;

            GUILayout.BeginArea(new Rect(rect.x + 25, rect.y + 20, rect.width - 50, rect.height - 40));

            GUI.skin.label.fontSize = 24;
            GUILayout.Label("<color=#FFD700><b>⭐ ⭐ ⭐</b></color>", GetCenterLabelStyle());
            GUILayout.Label(isVi ? $"<color=#00FFFF><b>VƯỢT THẾ GIỚI {clearWorld} THÀNH CÔNG!</b></color>" : $"<color=#00FFFF><b>WORLD {clearWorld} CLEARED!</b></color>", GetCenterLabelStyle());
            GUILayout.Space(12);

            GUI.skin.label.fontSize = 16;
            GUILayout.Label($"<b>{ (isVi ? "Thưởng Vượt Màn:" : "Stage Rewards:") }</b>", GetCenterLabelStyle());
            GUILayout.Label($"🪙 <b>+{clearCoins} Xu</b>   |   💎 <b>+{clearGems} Kim Cương</b>", GetCenterLabelStyle());

            if (clearTimeSpent > 0.1f)
            {
                string recordBadge = clearIsNewRecord ? "  <color=#FFD700><b>[🏆 KỶ LỤC MỚI!]</b></color>" : "";
                GUILayout.Label($"⏱️ <b>{ (isVi ? "Thời Gian Hoàn Thành:" : "Clear Time:") }</b> <color=#00FFFF><b>{clearTimeSpent:F1}s</b></color>{recordBadge}", GetCenterLabelStyle());
            }
            GUILayout.Space(20);

            if (GUILayout.Button(isVi ? "TIẾP TỤC QUA MÀN TIẾP THEO ➔" : "CONTINUE TO NEXT WORLD ➔", GUILayout.Height(50)))
            {
                isStageClear = false;
                if (GameManager.Instance != null)
                {
                    GameManager.Instance.LoadLevel(clearNextWorld, 1);
                }
                else
                {
                    SceneManager.LoadScene($"{clearNextWorld}-1");
                }
            }

            GUILayout.Space(8);
            if (GUILayout.Button(isVi ? "🏠 Về Menu Chính" : "🏠 Return to Menu", GUILayout.Height(36)))
            {
                isStageClear = false;
                SceneManager.LoadScene("MainMenu");
            }

            GUILayout.EndArea();
        }

        private void RenderVictoryGUI(bool isVi)
        {
            float w = Mathf.Min(520, Screen.width - 40);
            float h = 340;
            Rect rect = new Rect((Screen.width - w) * 0.5f, (Screen.height - h) * 0.5f, w, h);

            GUI.color = new Color(0.04f, 0.10f, 0.08f, 0.98f);
            GUI.DrawTexture(rect, whiteBoxTex);

            GUI.color = new Color(1f, 0.85f, 0.2f);
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width, 4), whiteBoxTex);
            GUI.DrawTexture(new Rect(rect.x, rect.y + rect.height - 4, rect.width, 4), whiteBoxTex);
            GUI.color = Color.white;

            GUILayout.BeginArea(new Rect(rect.x + 25, rect.y + 20, rect.width - 50, rect.height - 40));

            GUI.skin.label.fontSize = 26;
            GUILayout.Label("<color=#FFD700><b>🏆 CHIẾN THẮNG HUY HOÀNG 🏆</b></color>", GetCenterLabelStyle());
            GUI.skin.label.fontSize = 15;
            GUILayout.Label(isVi ? "Chúc mừng bạn đã chinh phục toàn bộ 4 Thế Giới và đánh bại Rồng Lửa!" : "Congratulations! You completed all 4 Worlds and vanquished the Dragon!", GetCenterLabelStyle());
            GUILayout.Space(12);

            GUILayout.Label("<color=#00FFFF><b>Phần thưởng hoàn thành: +2,000 Xu & +100 Kim Cương!</b></color>", GetCenterLabelStyle());
            GUILayout.Space(25);

            if (GUILayout.Button(isVi ? "🔄 CHƠI LẠI TỪ MÀN 1" : "🔄 REPLAY WORLD 1", GUILayout.Height(46)))
            {
                isVictory = false;
                GameManager.Instance?.LoadLevel(1, 1);
            }

            GUILayout.Space(10);
            if (GUILayout.Button(isVi ? "🏠 VỀ MENU CHÍNH" : "🏠 RETURN TO MAIN MENU", GUILayout.Height(42)))
            {
                isVictory = false;
                SceneManager.LoadScene("MainMenu");
            }

            GUILayout.EndArea();
        }

        private void RenderMenuGUI(bool isMainMenuScene, bool isVi)
        {
            float w = Mathf.Min(620, Screen.width - 40);
            float h = Mathf.Min(660, Screen.height - 40);
            Rect rect = new Rect((Screen.width - w) * 0.5f, (Screen.height - h) * 0.5f, w, h);

            // Dark futuristic background box
            GUI.color = new Color(0.06f, 0.08f, 0.14f, 0.97f);
            GUI.DrawTexture(rect, whiteBoxTex);

            // Glowing border
            GUI.color = new Color(0.0f, 0.85f, 1.0f, 0.85f);
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width, 3), whiteBoxTex);
            GUI.DrawTexture(new Rect(rect.x, rect.y + rect.height - 3, rect.width, 3), whiteBoxTex);
            GUI.DrawTexture(new Rect(rect.x, rect.y, 3, rect.height), whiteBoxTex);
            GUI.DrawTexture(new Rect(rect.x + rect.width - 3, rect.y, 3, rect.height), whiteBoxTex);
            GUI.color = Color.white;

            GUILayout.BeginArea(new Rect(rect.x + 25, rect.y + 15, rect.width - 50, rect.height - 30));

            // Header Title
            GUI.skin.label.fontSize = 28;
            GUILayout.Label("<color=#FFD700><size=32><b>REALM RAIDERS</b></size></color>", GetCenterLabelStyle());
            GUI.skin.label.fontSize = 14;
            GUILayout.Label("<color=#00E5FF><i>-- Elemental Odyssey: 4 Worlds Adventure --</i></color>", GetCenterLabelStyle());
            GUILayout.Space(12);

            // Navigation Tabs
            GUILayout.BeginHorizontal();
            if (GUILayout.Button(isVi ? "Menu" : "Main", GUILayout.Height(32))) { currentTab = 0; menuScrollPos = Vector2.zero; }
            if (GUILayout.Button(isVi ? "Thế Giới" : "Worlds", GUILayout.Height(32))) { currentTab = 1; menuScrollPos = Vector2.zero; }
            if (GUILayout.Button(isVi ? "Shop" : "Shop", GUILayout.Height(32))) { currentTab = 2; menuScrollPos = Vector2.zero; }
            if (GUILayout.Button(isVi ? "⚙️ Cài Đặt" : "⚙️ Settings", GUILayout.Height(32))) { currentTab = 3; menuScrollPos = Vector2.zero; }
            if (GUILayout.Button(isVi ? "Độ Khó" : "Difficulty", GUILayout.Height(32))) { currentTab = 4; menuScrollPos = Vector2.zero; }
            if (GUILayout.Button(isVi ? "Nhiệm Vụ" : "Quests", GUILayout.Height(32))) { currentTab = 5; menuScrollPos = Vector2.zero; }
            if (GUILayout.Button(isVi ? "Kỷ Lục" : "Trophy", GUILayout.Height(32))) { currentTab = 6; menuScrollPos = Vector2.zero; }
            GUILayout.EndHorizontal();

            GUILayout.Space(14);

            // Scrollable view for all tabs so shop, skills, costumes never get cut off
            menuScrollPos = GUILayout.BeginScrollView(menuScrollPos, false, false);

            switch (currentTab)
            {
                case 0:
                    RenderMainTab(isMainMenuScene, isVi);
                    break;
                case 1:
                    RenderWorldSelectTab(isVi);
                    break;
                case 2:
                    RenderShopAndSkillsTab(isVi);
                    break;
                case 3:
                    RenderSettingsTab(isVi);
                    break;
                case 4:
                    RenderDifficultyTab(isVi);
                    break;
                case 5:
                    RenderQuestsTab(isVi);
                    break;
                case 6:
                    RenderAchievementsTab(isVi);
                    break;
            }

            GUILayout.EndScrollView();

            GUILayout.EndArea();
        }

        private void RenderMainTab(bool isMainMenuScene, bool isVi)
        {
            var data = SaveSystem.LoadData();

            string diffLabel = data.difficulty switch
            {
                0 => isVi ? "<color=green>DỄ (5 Mạng)</color>" : "<color=green>EASY (5 Lives)</color>",
                2 => isVi ? "<color=red>KHÓ (1 Mạng)</color>" : "<color=red>HARD (1 Life)</color>",
                _ => isVi ? "<color=yellow>TRUNG BÌNH (3 Mạng)</color>" : "<color=yellow>NORMAL (3 Lives)</color>"
            };
            GUILayout.Label($"<b>{ (isVi ? "Chế độ hiện tại:" : "Current Difficulty:") }</b> {diffLabel}", GetCenterLabelStyle());
            GUILayout.Space(8);

            if (GUILayout.Button(isMainMenuScene ? (isVi ? "▶ BẮT ĐẦU CHƠI (RESET XU)" : "▶ START GAME (RESET COINS)") : (isVi ? "▶ TIẾP TỤC" : "▶ RESUME"), GUILayout.Height(46)))
            {
                isPaused = false;
                Time.timeScale = 1f;
                if (isMainMenuScene)
                {
                    SaveSystem.ResetCoins();
                    GameManager.Instance?.NewGame();
                }
            }

            if (GUILayout.Button(isVi ? "🔄 ĐẶT LẠI SỐ XU VỀ 0" : "🔄 RESET COIN COUNT TO 0", GUILayout.Height(36)))
            {
                SaveSystem.ResetCoins();
                AudioManager.Instance?.PlayCoin();
            }

            if (GUILayout.Button(isVi ? "🗺 CHỌN THẾ GIỚI (4 WORLDS)" : "🗺 WORLD SELECT (4 WORLDS)", GUILayout.Height(40)))
            {
                currentTab = 1;
            }

            if (GUILayout.Button(isVi ? "🛒 CỬA HÀNG: MUA SKILL & ĐỔI MÀU" : "🛒 SHOP: BUY SKILLS & SKINS", GUILayout.Height(40)))
            {
                currentTab = 2;
                menuScrollPos = Vector2.zero;
            }

            if (GUILayout.Button(isVi ? "⚙️ CÀI ĐẶT: ÂM THANH & NGÔN NGỮ" : "⚙️ SETTINGS: AUDIO & LANGUAGE", GUILayout.Height(40)))
            {
                currentTab = 3;
                menuScrollPos = Vector2.zero;
            }

            if (GUILayout.Button(isVi ? "⚡ CHỌN ĐỘ KHÓ (DỄ / TRUNG BÌNH / KHÓ)" : "⚡ SELECT DIFFICULTY", GUILayout.Height(40)))
            {
                currentTab = 4;
                menuScrollPos = Vector2.zero;
            }

            GUILayout.Space(6);

            if (!isMainMenuScene)
            {
                if (GUILayout.Button(isVi ? "🏠 VỀ MENU CHÍNH" : "🏠 RETURN TO MAIN MENU", GUILayout.Height(36)))
                {
                    isPaused = true;
                    SceneManager.LoadScene("MainMenu");
                }
            }

            if (GUILayout.Button(isVi ? "✖ THOÁT GAME (QUIT)" : "✖ QUIT GAME", GUILayout.Height(36)))
            {
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#else
                Application.Quit();
#endif
            }
        }

        private void RenderWorldSelectTab(bool isVi)
        {
            var data = SaveSystem.LoadData();

            GUILayout.Label(isVi ? "<b>CHỌN THẾ GIỚI PHIÊU LƯU:</b>" : "<b>SELECT WORLD:</b>", GetCenterLabelStyle());
            GUILayout.Space(8);

            RenderWorldButton(1, "1-1", isVi ? "☀️ THẾ GIỚI 1: VƯƠNG QUỐC MẶT TRỜI" : "☀️ WORLD 1: SUN KINGDOM", data.unlockedWorld >= 1);
            RenderWorldButton(2, "2-1", isVi ? "🏜️ THẾ GIỚI 2: SA MẠC CÁT CHÁY" : "🏜️ WORLD 2: SCORCHING DESERT", data.unlockedWorld >= 2);
            RenderWorldButton(3, "3-1", isVi ? "❄️ THẾ GIỚI 3: ĐỈNH NÚI BĂNG TUYẾT" : "❄️ WORLD 3: FROZEN PEAKS", data.unlockedWorld >= 3);
            RenderWorldButton(4, "4-1", isVi ? "⚡ THẾ GIỚI 4: VỰC THẲM BÃO TÁP" : "⚡ WORLD 4: TEMPEST ABYSS", data.unlockedWorld >= 4);

            GUILayout.Space(12);
            if (GUILayout.Button(isVi ? "◄ Quay Lại" : "◄ Back", GUILayout.Height(32))) currentTab = 0;
        }

        private void RenderWorldButton(int worldIndex, string sceneName, string title, bool isUnlocked)
        {
            GUI.enabled = isUnlocked;
            string prefix = isUnlocked ? "★ " : "🔒 ";
            if (GUILayout.Button($"{prefix}{title}", GUILayout.Height(40)))
            {
                isPaused = false;
                Time.timeScale = 1f;
                SceneManager.LoadScene(sceneName);
            }
            GUI.enabled = true;
        }

        private void RenderShopAndSkillsTab(bool isVi)
        {
            var data = SaveSystem.LoadData();
            GUILayout.Label($"<b>{ (isVi ? "Số Dư Hiện Tại:" : "Current Balance:") }</b> 🪙 {data.coins} Xu  |  💎 {data.gems} Kim Cương", GetCenterLabelStyle());
            GUILayout.Space(8);

            // 1. Skill Purchase Section (MUA SKILL TỪ 20, 50, 100, 200 XU)
            GUILayout.Label(isVi ? "<b>⚡ MUA & MỞ KHÓA KỸ NĂNG:</b>" : "<b>⚡ BUY & UNLOCK SKILLS:</b>");

            RenderSkillBuyRow("dash", isVi ? "⚡ Lướt Tốc Biến (Dash)" : "⚡ Assassin Dash", 20, isVi);
            RenderSkillBuyRow("freeze", isVi ? "❄ Băng Đông Cứng (Freeze)" : "❄ Freezing Burst", 50, isVi);
            RenderSkillBuyRow("lightning", isVi ? "⚡ Sấm Sét Thiên Lôi (Lightning)" : "⚡ Lightning Bolt", 100, isVi);
            RenderSkillBuyRow("hurricane", isVi ? "🌪 Lốc Xoáy Cuồng Phong (Hurricane)" : "🌪 Hurricane Gust", 200, isVi);

            // Double Jump Upgrade
            GUILayout.BeginHorizontal();
            GUILayout.Label(isVi ? "✨ Nhảy Đôi (Double Jump): " + (data.hasDoubleJump ? "<color=green>[ĐÃ MỞ]</color>" : "<color=yellow>80 Xu</color>") : "✨ Double Jump: " + (data.hasDoubleJump ? "<color=green>[UNLOCKED]</color>" : "<color=yellow>80 Coins</color>"));
            if (!data.hasDoubleJump)
            {
                if (GUILayout.Button(isVi ? "Mua (80 Xu)" : "Buy (80 C)", GUILayout.Width(110), GUILayout.Height(28)))
                {
                    if (ShopManager.Instance.PurchaseDoubleJump(80))
                    {
                        AudioManager.Instance?.PlayCoin();
                    }
                }
            }
            else
            {
                GUILayout.Label("<color=#00E5FF>Sẵn sàng dùng</color>", GUILayout.Width(110));
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(10);

            // 2. Skin Dyes Section
            GUILayout.Label(isVi ? "<b>🎨 ĐỔI MÀU TRANG PHỤC:</b>" : "<b>🎨 CHARACTER SKIN DYES:</b>");
            GUILayout.BeginHorizontal();
            if (GUILayout.Button(isVi ? "🔴 Đỏ Cổ Điển" : "Classic Red", GUILayout.Height(30))) SetSkin(0);
            if (GUILayout.Button(isVi ? "🟡 Vàng Nắng" : "Sun Gold", GUILayout.Height(30))) SetSkin(1);
            if (GUILayout.Button(isVi ? "🟤 Đồng Sa Mạc" : "Desert Bronze", GUILayout.Height(30))) SetSkin(2);
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button(isVi ? "❄ Xanh Băng" : "Ice Cyan", GUILayout.Height(30))) SetSkin(3);
            if (GUILayout.Button(isVi ? "🟣 Tím Bão" : "Storm Violet", GUILayout.Height(30))) SetSkin(4);
            if (GUILayout.Button(isVi ? "🟢 Lục Bảo" : "Emerald", GUILayout.Height(30))) SetSkin(5);
            GUILayout.EndHorizontal();

            GUILayout.Space(10);
            if (GUILayout.Button(isVi ? "◄ Quay Lại" : "◄ Back", GUILayout.Height(32))) currentTab = 0;
        }

        private void RenderSkillBuyRow(string skillId, string displayName, int cost, bool isVi)
        {
            var data = SaveSystem.LoadData();
            var s = data.skills.Find(x => x.skillId == skillId);
            bool isUnlocked = s != null && s.isUnlocked;

            GUILayout.BeginHorizontal();
            GUILayout.Label($"{displayName}: {(isUnlocked ? "<color=green>[ĐÃ MỞ]</color>" : $"<color=yellow>{cost} Xu</color>")}");

            if (!isUnlocked)
            {
                if (GUILayout.Button(isVi ? $"Mua ({cost} Xu)" : $"Buy ({cost} C)", GUILayout.Width(110), GUILayout.Height(28)))
                {
                    if (ShopManager.Instance.PurchaseSkill(skillId, cost))
                    {
                        AudioManager.Instance?.PlayCoin();
                    }
                }
            }
            else
            {
                GUILayout.Label("<color=#00E5FF>Sẵn sàng dùng</color>", GUILayout.Width(110));
            }
            GUILayout.EndHorizontal();
        }

        private void SetSkin(int skinIndex)
        {
            var data = SaveSystem.LoadData();
            data.characterSkinColor = skinIndex;
            SaveSystem.SaveData(data);

            var player = FindObjectOfType<Player>();
            if (player != null) player.ApplySkinColor();

            AudioManager.Instance?.PlayCoin();
        }

        private void RenderSettingsTab(bool isVi)
        {
            GUI.skin.label.fontSize = 22;
            GUILayout.Label(isVi ? "<color=#00FFFF><b>⚙️ CÀI ĐẶT HỆ THỐNG</b></color>" : "<color=#00FFFF><b>⚙️ SYSTEM SETTINGS</b></color>", GetCenterLabelStyle());
            GUILayout.Space(14);

            var data = SaveSystem.Current;
            var audio = RealmRaiders.Audio.AudioManager.Instance;
            var loc = RealmRaiders.Localization.LocalizationManager.Instance;

            // ================= 1. NGÔN NGỮ (LANGUAGE) =================
            GUI.skin.label.fontSize = 17;
            GUILayout.Label(isVi ? "<b>🌐 1. NGÔN NGỮ HIỂN THỊ (LANGUAGE):</b>" : "<b>🌐 1. DISPLAY LANGUAGE:</b>");
            GUILayout.Space(6);

            GUILayout.BeginHorizontal();
            bool isCurrentVi = loc?.CurrentLanguage == RealmRaiders.Localization.Language.Vietnamese;
            bool isCurrentEn = loc?.CurrentLanguage == RealmRaiders.Localization.Language.English;

            GUI.color = isCurrentVi ? new Color(0.2f, 1f, 0.45f) : Color.white;
            if (GUILayout.Button(isCurrentVi ? "✔ 🇻🇳 TIẾNG VIỆT (ĐANG CHỌN)" : "🇻🇳 TIẾNG VIỆT", GUILayout.Height(44)))
            {
                loc?.SetLanguage(RealmRaiders.Localization.Language.Vietnamese);
                audio?.PlayCoin();
            }

            GUI.color = isCurrentEn ? new Color(0.2f, 1f, 0.45f) : Color.white;
            if (GUILayout.Button(isCurrentEn ? "✔ 🇬🇧 ENGLISH (ACTIVE)" : "🇬🇧 ENGLISH", GUILayout.Height(44)))
            {
                loc?.SetLanguage(RealmRaiders.Localization.Language.English);
                audio?.PlayCoin();
            }
            GUI.color = Color.white;
            GUILayout.EndHorizontal();

            GUI.skin.label.fontSize = 13;
            GUILayout.Label(isVi ? "<i>* Chuyển đổi toàn bộ ngôn ngữ menu, cốt truyện, nhiệm vụ và hướng dẫn.</i>" : "<i>* Instantly applies language to all UI menus, stories, and quests.</i>");
            GUILayout.Space(18);

            // ================= 2. NHẠC NỀN (BGM) =================
            float currentMusic = audio != null ? audio.MusicVolume : (data != null ? data.musicVolume : 0.8f);
            int musicPercent = Mathf.RoundToInt(currentMusic * 100f);
            string musicBadge = musicPercent == 0 
                ? (isVi ? "<color=#FF4444><b>[ĐANG TẮT]</b></color>" : "<color=#FF4444><b>[MUTED]</b></color>") 
                : $"<color=#FFD700><b>[{musicPercent}%]</b></color>";

            GUI.skin.label.fontSize = 17;
            GUILayout.Label(isVi ? $"<b>🎵 2. ÂM LƯỢNG NHẠC NỀN (MUSIC BGM):</b> {musicBadge}" : $"<b>🎵 2. BACKGROUND MUSIC (BGM):</b> {musicBadge}");
            GUI.skin.label.fontSize = 13;
            GUILayout.Label(isVi ? "<i>(Nhạc nền các World 1-4, màn chơi và Menu chính)</i>" : "<i>(World 1-4 stage tracks and menu music)</i>");
            GUILayout.Space(6);

            float newMusic = GUILayout.HorizontalSlider(currentMusic, 0f, 1f, GUILayout.Height(24));
            if (Mathf.Abs(newMusic - currentMusic) > 0.01f)
            {
                audio?.SetMusicVolume(newMusic, false);
            }

            GUILayout.BeginHorizontal();
            if (GUILayout.Button(isVi ? "🔇 Tắt Nhạc" : "🔇 Mute", GUILayout.Height(32)))
            {
                audio?.SetMusicVolume(0f, true);
            }
            if (GUILayout.Button("🔉 30%", GUILayout.Height(32)))
            {
                audio?.SetMusicVolume(0.3f, true);
            }
            if (GUILayout.Button("🔉 60%", GUILayout.Height(32)))
            {
                audio?.SetMusicVolume(0.6f, true);
            }
            if (GUILayout.Button("🔊 100%", GUILayout.Height(32)))
            {
                audio?.SetMusicVolume(1.0f, true);
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(18);

            // ================= 3. ÂM THANH HIỆU ỨNG (SFX) =================
            float currentSfx = audio != null ? audio.SFXVolume : (data != null ? data.sfxVolume : 1.0f);
            int sfxPercent = Mathf.RoundToInt(currentSfx * 100f);
            string sfxBadge = sfxPercent == 0 
                ? (isVi ? "<color=#FF4444><b>[ĐANG TẮT]</b></color>" : "<color=#FF4444><b>[MUTED]</b></color>") 
                : $"<color=#00FFFF><b>[{sfxPercent}%]</b></color>";

            GUI.skin.label.fontSize = 17;
            GUILayout.Label(isVi ? $"<b>🔊 3. HIỆU ỨNG ÂM THANH (SFX):</b> {sfxBadge}" : $"<b>🔊 3. SOUND EFFECTS (SFX):</b> {sfxBadge}");
            GUI.skin.label.fontSize = 13;
            GUILayout.Label(isVi ? "<i>(Tiếng Mario nhảy, nhặt xu vàng, chém kiếm, dính đòn, tiếng nổ, chiêu thức...)</i>" : "<i>(Jump, coin collect, sword slash, hurt, explosions, skills...)</i>");
            GUILayout.Space(6);

            float newSfx = GUILayout.HorizontalSlider(currentSfx, 0f, 1f, GUILayout.Height(24));
            if (Mathf.Abs(newSfx - currentSfx) > 0.01f)
            {
                audio?.SetSFXVolume(newSfx, false);
            }

            GUILayout.BeginHorizontal();
            if (GUILayout.Button(isVi ? "🔇 Tắt SFX" : "🔇 Mute", GUILayout.Height(32)))
            {
                audio?.SetSFXVolume(0f, true);
            }
            if (GUILayout.Button("🔉 50%", GUILayout.Height(32)))
            {
                audio?.SetSFXVolume(0.5f, true);
                audio?.PlayCoin();
            }
            if (GUILayout.Button("🔊 100%", GUILayout.Height(32)))
            {
                audio?.SetSFXVolume(1.0f, true);
                audio?.PlayCoin();
            }
            if (GUILayout.Button(isVi ? "🔔 Thử Âm (Test)" : "🔔 Test Sound", GUILayout.Height(32)))
            {
                audio?.PlayCoin();
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(22);

            if (GUILayout.Button(isVi ? "◄ QUAY LẠI MENU CHÍNH" : "◄ BACK TO MAIN MENU", GUILayout.Height(40)))
            {
                SaveSystem.SaveData();
                currentTab = 0;
            }
        }

        private void RenderDifficultyTab(bool isVi)
        {
            var data = SaveSystem.LoadData();
            GUILayout.Label(isVi ? "<b>CHỌN ĐỘ KHÓ TRÒ CHƠI:</b>" : "<b>SELECT DIFFICULTY:</b>", GetCenterLabelStyle());
            GUILayout.Space(10);

            if (GUILayout.Button(isVi ? "🟢 DỄ: 5 MẠNG (Quái đi chậm 70%)" : "🟢 EASY: 5 LIVES (Enemies 70% Speed)", GUILayout.Height(44)))
            {
                SetDifficulty(0, 5);
            }

            if (GUILayout.Button(isVi ? "🟡 TRUNG BÌNH: 3 MẠNG (Tiêu Chuẩn 100%)" : "🟡 NORMAL: 3 LIVES (Standard 100%)", GUILayout.Height(44)))
            {
                SetDifficulty(1, 3);
            }

            if (GUILayout.Button(isVi ? "🔴 KHÓ: 1 MẠNG (Quái nhanh 130%)" : "🔴 HARD: 1 LIFE (Enemies 130% Speed)", GUILayout.Height(44)))
            {
                SetDifficulty(2, 1);
            }

            GUILayout.Space(12);
            if (GUILayout.Button(isVi ? "◄ Quay Lại" : "◄ Back", GUILayout.Height(32))) currentTab = 0;
        }

        private void SetDifficulty(int diff, int livesCount)
        {
            var data = SaveSystem.LoadData();
            data.difficulty = diff;
            SaveSystem.SaveData(data);

            if (GameManager.Instance != null)
            {
                GameManager.Instance.SetLives(livesCount);
            }

            AudioManager.Instance?.PlayCoin();
            currentTab = 0;
        }

        private void RenderQuestsTab(bool isVi)
        {
            var data = SaveSystem.LoadData();
            GUILayout.Label(isVi ? "<b>NHIỆM VỤ HÀNG NGÀY & CỐT TRUYỆN:</b>" : "<b>DAILY & STORY QUESTS:</b>", GetCenterLabelStyle());
            GUILayout.Space(8);

            foreach (var q in data.dailyQuests)
            {
                string status = q.isClaimed ? (isVi ? "<color=green>[ĐÃ NHẬN]</color>" : "<color=green>[CLAIMED]</color>") : $"{q.currentAmount}/{q.targetAmount}";
                GUILayout.BeginHorizontal();
                GUILayout.Label($"• {q.questId.ToUpper()}: {status}");
                if (!q.isClaimed && q.currentAmount >= q.targetAmount)
                {
                    if (GUILayout.Button(isVi ? "Nhận Thưởng" : "Claim", GUILayout.Width(100)))
                    {
                        QuestManager.Instance?.ClaimReward(q.questId);
                    }
                }
                GUILayout.EndHorizontal();
            }

            GUILayout.Space(12);
            if (GUILayout.Button(isVi ? "◄ Quay Lại" : "◄ Back", GUILayout.Height(32))) currentTab = 0;
        }

        private void RenderAchievementsTab(bool isVi)
        {
            var data = SaveSystem.LoadData();

            // 1. KỶ LỤC TỐC ĐỘ QUA MÀN NHANH NHẤT (SPEEDRUN)
            GUI.skin.label.fontSize = 16;
            GUILayout.Label(isVi ? "<b>⏱️ THỜI GIAN QUA MÀN NHANH NHẤT (SPEEDRUN):</b>" : "<b>⏱️ FASTEST CLEAR TIMES (SPEEDRUN):</b>", GetCenterLabelStyle());
            GUILayout.Space(8);

            RenderSpeedrunRow(1, isVi ? "🌱 Thế Giới 1: Thảo Nguyên Xanh" : "🌱 World 1: Green Plains", data.bestTimeWorld1, isVi);
            RenderSpeedrunRow(2, isVi ? "🏜️ Thế Giới 2: Sa Mạc Cát Lún" : "🏜️ World 2: Shifting Sands", data.bestTimeWorld2, isVi);
            RenderSpeedrunRow(3, isVi ? "❄️ Thế Giới 3: Đỉnh Núi Băng Tuyết" : "❄️ World 3: Frozen Peaks", data.bestTimeWorld3, isVi);
            RenderSpeedrunRow(4, isVi ? "⚡ Thế Giới 4: Vực Thẳm Bão Táp" : "⚡ World 4: Tempest Abyss", data.bestTimeWorld4, isVi);

            GUILayout.Space(16);

            // 2. DANH HIỆU & THÀNH TÍCH ANH HÙNG
            GUI.skin.label.fontSize = 16;
            GUILayout.Label(isVi ? "<b>🏆 DANH HIỆU & THÀNH TÍCH ANH HÙNG:</b>" : "<b>🏆 HERO TROPHIES & ACHIEVEMENTS:</b>", GetCenterLabelStyle());
            GUILayout.Space(8);

            var achievements = new (string id, string nameVi, string nameEn, string descVi, string descEn)[]
            {
                ("first_blood", "Chiến Binh Khởi Đầu", "First Blood", "Tiêu diệt kẻ địch đầu tiên", "Defeat your first enemy"),
                ("breakthrough", "Vượt Qua Giới Hạn", "Breakthrough", "Vượt màn chơi thành công", "Clear a stage successfully"),
                ("rich_miner", "Thợ Mỏ Phú Hào", "Rich Miner", "Tích lũy 100 xu vàng", "Collect 100 gold coins"),
                ("sword_master", "Kiếm Sư Tinh Anh", "Sword Master", "Dùng kiếm chém trúng quái", "Land a sword melee slash"),
                ("boss_slayer", "Kẻ Diệt Rồng", "Dragon Slayer", "Đánh bại Rồng Lửa Thế Giới 4", "Defeat the World 4 Dragon Boss"),
                ("immortal", "Bất Tử Bất Diệt", "Immortal Champion", "Kích hoạt Khiên Năng Lượng", "Activate Energy Shield")
            };

            foreach (var a in achievements)
            {
                bool unlocked = data.unlockedAchievements.Contains(a.id);
                string mark = unlocked ? "<color=#00FF88>★ ĐÃ ĐẠT</color>" : "<color=#888888>Chưa mở khóa</color>";
                string title = isVi ? a.nameVi : a.nameEn;
                string desc = isVi ? a.descVi : a.descEn;
                GUILayout.Label($"• <b>{title}</b>: {mark}\n   <size=12><color=#AAAAAA>{desc}</color></size>");
                GUILayout.Space(4);
            }

            GUILayout.Space(12);
            if (GUILayout.Button(isVi ? "◄ Quay Lại" : "◄ Back", GUILayout.Height(32))) currentTab = 0;
        }

        private void RenderSpeedrunRow(int worldNum, string worldTitle, float bestSeconds, bool isVi)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(worldTitle);
            string timeStr = bestSeconds > 0.05f 
                ? $"<color=#00FFFF><b>{bestSeconds:F1}s</b></color> 🏆" 
                : (isVi ? "<color=#888888>Chưa có kỷ lục</color>" : "<color=#888888>No record yet</color>");
            GUILayout.Label(timeStr, GUILayout.Width(130));
            GUILayout.EndHorizontal();
        }

        private GUIStyle GetCenterLabelStyle()
        {
            var style = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter
            };
            return style;
        }
    }
}
