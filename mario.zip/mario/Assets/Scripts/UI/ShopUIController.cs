using UnityEngine;
using UnityEngine.UI;
using RealmRaiders.Shop;
using RealmRaiders.Data;
using RealmRaiders.Audio;

namespace RealmRaiders.UI
{
    public class ShopUIController : MonoBehaviour
    {
        [Header("Currency Texts")]
        [SerializeField] private Text coinsText;
        [SerializeField] private Text gemsText;

        [Header("Upgrade Levels")]
        [SerializeField] private Text hpLevelText;
        [SerializeField] private Text speedLevelText;

        [Header("Upgrade Costs")]
        [SerializeField] private int baseHpCost = 100;
        [SerializeField] private int baseSpeedCost = 150;
        [SerializeField] private int chestCostGems = 10;

        private void OnEnable()
        {
            ShopManager.OnShopUpdated += RefreshUI;
            RefreshUI();
        }

        private void OnDisable()
        {
            ShopManager.OnShopUpdated -= RefreshUI;
        }

        public void RefreshUI()
        {
            var data = SaveSystem.LoadData();
            if (coinsText != null) coinsText.text = data.coins.ToString();
            if (gemsText != null) gemsText.text = data.gems.ToString();
            if (hpLevelText != null) hpLevelText.text = $"Lv. {data.healthLevel}";
            if (speedLevelText != null) speedLevelText.text = $"Lv. {data.speedLevel}";
        }

        public void BuyHealthUpgrade()
        {
            var data = SaveSystem.LoadData();
            int cost = baseHpCost * data.healthLevel;
            if (ShopManager.Instance.PurchaseUpgradeHealth(cost))
            {
                AudioManager.Instance?.PlayCoin();
            }
        }

        public void BuySpeedUpgrade()
        {
            var data = SaveSystem.LoadData();
            int cost = baseSpeedCost * data.speedLevel;
            if (ShopManager.Instance.PurchaseUpgradeSpeed(cost))
            {
                AudioManager.Instance?.PlayCoin();
            }
        }

        public void BuyChest()
        {
            if (ShopManager.Instance.PurchaseChest(chestCostGems, out int coinsWon, out int gemsWon))
            {
                AudioManager.Instance?.PlaySkill();
                Debug.Log($"[Shop] Chest opened! Won {coinsWon} Coins and {gemsWon} Gems!");
            }
        }
    }
}
