using System;
using System.Collections.Generic;
using UnityEngine;
using RealmRaiders.Data;

namespace RealmRaiders.Quests
{
    [Serializable]
    public class QuestDefinition
    {
        public string id;
        public string titleKey;
        public int targetAmount;
        public int rewardCoins;
        public int rewardGems;
        public bool isDaily;
    }

    public class QuestManager : MonoBehaviour
    {
        public static QuestManager Instance { get; private set; }

        public static event Action OnQuestsUpdated;

        [SerializeField] private List<QuestDefinition> questDefinitions = new()
        {
            new QuestDefinition { id = "daily_coin", titleKey = "quest_collect_coins", targetAmount = 50, rewardCoins = 150, rewardGems = 5, isDaily = true },
            new QuestDefinition { id = "daily_kill", titleKey = "quest_kill_enemies", targetAmount = 10, rewardCoins = 200, rewardGems = 10, isDaily = true },
            new QuestDefinition { id = "story_world1", titleKey = "quest_finish_stage", targetAmount = 1, rewardCoins = 500, rewardGems = 25, isDaily = false }
        };

        private GameData gameData => SaveSystem.Current;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            CheckDailyReset();
        }

        private void CheckDailyReset()
        {
            string today = DateTime.UtcNow.ToString("yyyy-MM-dd");
            if (gameData.lastDailyResetDate != today)
            {
                gameData.lastDailyResetDate = today;
                gameData.dailyQuests.Clear();
                foreach (var q in questDefinitions)
                {
                    if (q.isDaily)
                    {
                        gameData.dailyQuests.Add(new QuestProgress
                        {
                            questId = q.id,
                            currentAmount = 0,
                            targetAmount = q.targetAmount,
                            isClaimed = false
                        });
                    }
                }
                SaveSystem.SaveData(gameData);
                OnQuestsUpdated?.Invoke();
            }
        }

        public void AddProgress(string questId, int amount)
        {
            var quest = gameData.dailyQuests.Find(q => q.questId == questId) ??
                        gameData.storyQuests.Find(q => q.questId == questId);

            if (quest != null && !quest.isClaimed)
            {
                quest.currentAmount = Mathf.Clamp(quest.currentAmount + amount, 0, quest.targetAmount);
                SaveSystem.SaveData(gameData);
                OnQuestsUpdated?.Invoke();
            }
        }

        public bool ClaimReward(string questId)
        {
            var quest = gameData.dailyQuests.Find(q => q.questId == questId) ??
                        gameData.storyQuests.Find(q => q.questId == questId);

            var def = questDefinitions.Find(d => d.id == questId);

            if (quest != null && def != null && quest.currentAmount >= quest.targetAmount && !quest.isClaimed)
            {
                quest.isClaimed = true;
                gameData.coins += def.rewardCoins;
                gameData.gems += def.rewardGems;
                SaveSystem.SaveData(gameData);
                OnQuestsUpdated?.Invoke();
                return true;
            }
            return false;
        }
    }
}
