using UnityEngine;
using RealmRaiders.Localization;
using RealmRaiders.Audio;
using RealmRaiders.Shop;
using RealmRaiders.Quests;
using RealmRaiders.Achievements;
using RealmRaiders.Data;

namespace RealmRaiders.Core
{
    public static class GameBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void InitializeGameCore()
        {
            GameObject coreObj = GameObject.Find("[RealmRaiders_Core]");
            if (coreObj == null)
            {
                coreObj = new GameObject("[RealmRaiders_Core]");
                Object.DontDestroyOnLoad(coreObj);

                // Add all essential singletons
                if (coreObj.GetComponent<LocalizationManager>() == null)
                    coreObj.AddComponent<LocalizationManager>();

                if (coreObj.GetComponent<AudioManager>() == null)
                    coreObj.AddComponent<AudioManager>();

                if (coreObj.GetComponent<ShopManager>() == null)
                    coreObj.AddComponent<ShopManager>();

                if (coreObj.GetComponent<QuestManager>() == null)
                    coreObj.AddComponent<QuestManager>();

                if (coreObj.GetComponent<AchievementManager>() == null)
                    coreObj.AddComponent<AchievementManager>();

                if (coreObj.GetComponent<RealmRaiders.Environment.WorldThemeManager>() == null)
                    coreObj.AddComponent<RealmRaiders.Environment.WorldThemeManager>();

                if (coreObj.GetComponent<RealmRaiders.Environment.WeatherSystem>() == null)
                    coreObj.AddComponent<RealmRaiders.Environment.WeatherSystem>();

                if (coreObj.GetComponent<RealmRaiders.Environment.LevelCoinSpawner>() == null)
                    coreObj.AddComponent<RealmRaiders.Environment.LevelCoinSpawner>();

                if (coreObj.GetComponent<RealmRaiders.Environment.WorldLayoutBuilder>() == null)
                    coreObj.AddComponent<RealmRaiders.Environment.WorldLayoutBuilder>();

                if (coreObj.GetComponent<RealmRaiders.UI.MasterMenuOverlay>() == null)
                    coreObj.AddComponent<RealmRaiders.UI.MasterMenuOverlay>();

                if (coreObj.GetComponent<RealmRaiders.UI.CombatFeedbackManager>() == null)
                    coreObj.AddComponent<RealmRaiders.UI.CombatFeedbackManager>();

                // Add Dev/Test Console for fast in-game validation
                if (coreObj.GetComponent<DevConsole>() == null)
                    coreObj.AddComponent<DevConsole>();

                // Ensure GameManager is active
                if (GameManager.Instance == null)
                {
                    var gmObj = GameObject.Find("GameManager") ?? new GameObject("GameManager");
                    if (gmObj.GetComponent<GameManager>() == null)
                        gmObj.AddComponent<GameManager>();
                }

                Debug.Log("<color=green>[Realm Raiders]</color> Core systems bootstrapped successfully across all scenes!");
            }
        }
    }
}
