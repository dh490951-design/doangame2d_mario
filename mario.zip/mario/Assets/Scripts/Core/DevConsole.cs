using UnityEngine;
using RealmRaiders.Data;
using RealmRaiders.Localization;
using RealmRaiders.Skills;

namespace RealmRaiders.Core
{
    public class DevConsole : MonoBehaviour
    {
        private bool showMenu = false;
        private Rect windowRect = new(20, 20, 320, 420);

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.F1) || Input.GetKeyDown(KeyCode.BackQuote))
            {
                showMenu = !showMenu;
            }
        }

        private void OnGUI()
        {
            if (!showMenu) return;

            GUI.backgroundColor = new Color(0.1f, 0.1f, 0.15f, 0.95f);
            windowRect = GUI.Window(9999, windowRect, RenderConsoleWindow, "REALM RAIDERS - CHEAT & TEST");
        }

        private void RenderConsoleWindow(int windowID)
        {
            GUILayout.Space(10);
            var data = SaveSystem.LoadData();

            GUILayout.Label($"Xu: <b>{data.coins}</b> | Kim Cương: <b>{data.gems}</b> | World: <b>{data.unlockedWorld}</b>");
            GUILayout.Space(8);

            if (GUILayout.Button("+ 1,000 Xu (Coins)"))
            {
                data.coins += 1000;
                SaveSystem.SaveData(data);
            }

            if (GUILayout.Button("+ 100 Kim Cương (Gems)"))
            {
                data.gems += 100;
                SaveSystem.SaveData(data);
            }

            if (GUILayout.Button("Mở Khóa Tất Cả 4 Thế Giới"))
            {
                data.unlockedWorld = 4;
                data.unlockedLevel = 4;
                SaveSystem.SaveData(data);
                Debug.Log("[DevConsole] All 4 worlds unlocked!");
            }

            if (GUILayout.Button("Chuyển Đổi Ngôn Ngữ (VI/EN)"))
            {
                LocalizationManager.Instance?.ToggleLanguage();
            }

            if (GUILayout.Button("Bật Sao Bất Tử (Starpower)"))
            {
                var player = FindObjectOfType<Player>();
                if (player != null) player.Starpower();
            }

            if (GUILayout.Button("Test Kỹ Năng: Lướt (Dash)"))
            {
                SkillSystem.Instance?.TryCastSkill(SkillType.Dash);
            }

            if (GUILayout.Button("Test Kỹ Năng: Đóng Băng (Freeze)"))
            {
                SkillSystem.Instance?.TryCastSkill(SkillType.Freezing);
            }

            if (GUILayout.Button("Test Kỹ Năng: Sét Đánh (Lightning)"))
            {
                SkillSystem.Instance?.TryCastSkill(SkillType.Lightning);
            }

            if (GUILayout.Button("Test Kỹ Năng: Cuồng Phong (Hurricane)"))
            {
                SkillSystem.Instance?.TryCastSkill(SkillType.Hurricane);
            }

            GUILayout.Space(10);
            GUI.color = Color.red;
            if (GUILayout.Button("Reset Toàn Bộ Tiến Trình (Clear Save)"))
            {
                SaveSystem.ClearSave();
                Debug.Log("[DevConsole] Save data cleared!");
            }

            GUI.DragWindow(new Rect(0, 0, 10000, 30));
        }
    }
}
