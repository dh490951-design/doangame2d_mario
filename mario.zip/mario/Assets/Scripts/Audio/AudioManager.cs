using System.Collections.Generic;
using UnityEngine;
using RealmRaiders.Data;

namespace RealmRaiders.Audio
{
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance { get; private set; }

        [Header("Audio Sources")]
        [SerializeField] private AudioSource musicSource;
        [SerializeField] private AudioSource sfxSource;

        [Header("BGM Clips")]
        [SerializeField] private AudioClip mainMenuBGM;
        [SerializeField] private AudioClip world1SunBGM;
        [SerializeField] private AudioClip world2DesertBGM;
        [SerializeField] private AudioClip world3SnowBGM;
        [SerializeField] private AudioClip world4StormBGM;
        [SerializeField] private AudioClip bossBGM;

        [Header("Common SFX Clips")]
        [SerializeField] private AudioClip jumpSFX;
        [SerializeField] private AudioClip coinSFX;
        [SerializeField] private AudioClip dashSFX;
        [SerializeField] private AudioClip skillSFX;
        [SerializeField] private AudioClip hitSFX;
        [SerializeField] private AudioClip explosionSFX;

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);

                if (musicSource == null) musicSource = gameObject.AddComponent<AudioSource>();
                if (sfxSource == null) sfxSource = gameObject.AddComponent<AudioSource>();

                EnsureClips();
                ApplySavedVolumes();
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void EnsureClips()
        {
            if (coinSFX == null) coinSFX = ProceduralAudioSynth.CreateCoinSound();
            if (jumpSFX == null) jumpSFX = ProceduralAudioSynth.CreateJumpSound();
            if (dashSFX == null) dashSFX = ProceduralAudioSynth.CreateDashSound();
            if (explosionSFX == null) explosionSFX = ProceduralAudioSynth.CreateExplosionSound();
            if (hitSFX == null) hitSFX = ProceduralAudioSynth.CreateHitSound();

            if (world1SunBGM == null) world1SunBGM = ProceduralAudioSynth.CreateWorldBGM(1);
            if (world2DesertBGM == null) world2DesertBGM = ProceduralAudioSynth.CreateWorldBGM(2);
            if (world3SnowBGM == null) world3SnowBGM = ProceduralAudioSynth.CreateWorldBGM(3);
            if (world4StormBGM == null) world4StormBGM = ProceduralAudioSynth.CreateWorldBGM(4);
            if (mainMenuBGM == null) mainMenuBGM = world1SunBGM;
            if (bossBGM == null) bossBGM = world4StormBGM;
        }

        private void ApplySavedVolumes()
        {
            var data = SaveSystem.LoadData();
            SetMusicVolume(data.musicVolume);
            SetSFXVolume(data.sfxVolume);
        }

        public void PlayBGM(AudioClip clip, bool loop = true)
        {
            if (musicSource == null || clip == null) return;
            if (musicSource.clip == clip && musicSource.isPlaying) return;

            musicSource.clip = clip;
            musicSource.loop = loop;
            musicSource.Play();
        }

        public void PlayWorldBGM(int worldIndex)
        {
            AudioClip clip = worldIndex switch
            {
                1 => world1SunBGM,
                2 => world2DesertBGM,
                3 => world3SnowBGM,
                4 => world4StormBGM,
                _ => world1SunBGM
            };
            PlayBGM(clip, true);
        }

        public void PlaySFX(AudioClip clip)
        {
            if (sfxSource == null || clip == null) return;
            sfxSource.PlayOneShot(clip);
        }

        public void PlaySlash() => PlaySFX(dashSFX ?? (dashSFX = ProceduralAudioSynth.CreateSlashSound()));
        public void PlayJump() => PlaySFX(jumpSFX ?? (jumpSFX = ProceduralAudioSynth.CreateJumpSound()));
        public void PlayCoin() => PlaySFX(coinSFX ?? (coinSFX = ProceduralAudioSynth.CreateCoinSound()));
        public void PlayDash() => PlaySFX(dashSFX ?? (dashSFX = ProceduralAudioSynth.CreateDashSound()));
        public void PlaySkill() => PlaySFX(skillSFX ?? (skillSFX = ProceduralAudioSynth.CreateDashSound()));
        public void PlayHit() => PlaySFX(hitSFX ?? (hitSFX = ProceduralAudioSynth.CreateHitSound()));
        public void PlayExplosion() => PlaySFX(explosionSFX ?? (explosionSFX = ProceduralAudioSynth.CreateExplosionSound()));

        public float MusicVolume => musicSource != null ? musicSource.volume : (SaveSystem.Current != null ? SaveSystem.Current.musicVolume : 0.8f);
        public float SFXVolume => sfxSource != null ? sfxSource.volume : (SaveSystem.Current != null ? SaveSystem.Current.sfxVolume : 1.0f);

        public void SetMusicVolume(float volume, bool saveToDisk = true)
        {
            if (musicSource != null) musicSource.volume = volume;
            var data = SaveSystem.LoadData();
            data.musicVolume = volume;
            if (saveToDisk) SaveSystem.SaveData(data);
        }

        public void SetSFXVolume(float volume, bool saveToDisk = true)
        {
            if (sfxSource != null) sfxSource.volume = volume;
            var data = SaveSystem.LoadData();
            data.sfxVolume = volume;
            if (saveToDisk) SaveSystem.SaveData(data);
        }
    }
}
