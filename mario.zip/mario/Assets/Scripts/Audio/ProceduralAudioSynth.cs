using UnityEngine;

namespace RealmRaiders.Audio
{
    public static class ProceduralAudioSynth
    {
        private const int SAMPLE_RATE = 44100;

        public static AudioClip CreateCoinSound()
        {
            int samples = (int)(SAMPLE_RATE * 0.35f);
            float[] data = new float[samples];
            for (int i = 0; i < samples; i++)
            {
                float t = (float)i / SAMPLE_RATE;
                float freq = t < 0.1f ? 987.77f : 1318.51f; // B5 to E6
                data[i] = Mathf.Sin(2 * Mathf.PI * freq * t) * (1f - (float)i / samples) * 0.45f;
            }
            var clip = AudioClip.Create("Synth_Coin", samples, 1, SAMPLE_RATE, false);
            clip.SetData(data, 0);
            return clip;
        }

        public static AudioClip CreateJumpSound()
        {
            int samples = (int)(SAMPLE_RATE * 0.25f);
            float[] data = new float[samples];
            for (int i = 0; i < samples; i++)
            {
                float t = (float)i / SAMPLE_RATE;
                float freq = Mathf.Lerp(160f, 650f, t / 0.25f);
                data[i] = Mathf.Sin(2 * Mathf.PI * freq * t) * (1f - (float)i / samples) * 0.4f;
            }
            var clip = AudioClip.Create("Synth_Jump", samples, 1, SAMPLE_RATE, false);
            clip.SetData(data, 0);
            return clip;
        }

        public static AudioClip CreateSlashSound()
        {
            int samples = (int)(SAMPLE_RATE * 0.2f);
            float[] data = new float[samples];
            for (int i = 0; i < samples; i++)
            {
                float t = (float)i / SAMPLE_RATE;
                float freq = Mathf.Lerp(800f, 150f, (float)i / samples);
                float noise = (Random.value * 2f - 1f) * 0.4f;
                float wave = Mathf.Sin(2 * Mathf.PI * freq * t) * 0.6f;
                data[i] = (wave + noise) * (1f - (float)i / samples) * 0.5f;
            }
            var clip = AudioClip.Create("Synth_Slash", samples, 1, SAMPLE_RATE, false);
            clip.SetData(data, 0);
            return clip;
        }

        public static AudioClip CreateDashSound()
        {
            int samples = (int)(SAMPLE_RATE * 0.25f);
            float[] data = new float[samples];
            for (int i = 0; i < samples; i++)
            {
                float t = (float)i / samples;
                float noise = (Random.value * 2f - 1f);
                float envelope = Mathf.Sin(t * Mathf.PI);
                data[i] = noise * envelope * 0.35f;
            }
            var clip = AudioClip.Create("Synth_Dash", samples, 1, SAMPLE_RATE, false);
            clip.SetData(data, 0);
            return clip;
        }

        public static AudioClip CreateExplosionSound()
        {
            int samples = (int)(SAMPLE_RATE * 0.5f);
            float[] data = new float[samples];
            for (int i = 0; i < samples; i++)
            {
                float t = (float)i / samples;
                float noise = (Random.value * 2f - 1f);
                float decay = Mathf.Exp(-t * 6f);
                data[i] = noise * decay * 0.5f;
            }
            var clip = AudioClip.Create("Synth_Explosion", samples, 1, SAMPLE_RATE, false);
            clip.SetData(data, 0);
            return clip;
        }

        public static AudioClip CreateHitSound()
        {
            int samples = (int)(SAMPLE_RATE * 0.15f);
            float[] data = new float[samples];
            for (int i = 0; i < samples; i++)
            {
                float t = (float)i / SAMPLE_RATE;
                float freq = Mathf.Lerp(300f, 80f, (float)i / samples);
                float wave = Mathf.Sin(2 * Mathf.PI * freq * t) > 0 ? 0.35f : -0.35f;
                data[i] = wave * (1f - (float)i / samples);
            }
            var clip = AudioClip.Create("Synth_Hit", samples, 1, SAMPLE_RATE, false);
            clip.SetData(data, 0);
            return clip;
        }

        public static AudioClip CreateWorldBGM(int worldIndex)
        {
            // Generates an 8-second seamless musical loop with harmonic arpeggios
            float duration = 8.0f;
            int samples = (int)(SAMPLE_RATE * duration);
            float[] data = new float[samples];

            // Scales per world
            float[] notes = worldIndex switch
            {
                // World 1 (Sun Kingdom): Warm joyful Major Pentatonic (C4, D4, E4, G4, A4, C5, E5)
                1 => new[] { 261.63f, 293.66f, 329.63f, 392.00f, 440.00f, 523.25f, 659.25f, 523.25f },
                // World 2 (Scorching Desert): Exotic Phrygian dominant (E3, F3, G#3, A3, B3, C4, E4, B3)
                2 => new[] { 164.81f, 174.61f, 207.65f, 220.00f, 246.94f, 261.63f, 329.63f, 246.94f },
                // World 3 (Frozen Peaks): Crystal chime high arpeggio (A4, C5, E5, G5, A5, G5, E5, C5)
                3 => new[] { 440.00f, 523.25f, 659.25f, 783.99f, 880.00f, 783.99f, 659.25f, 523.25f },
                // World 4 (Tempest Abyss): Dramatic dark tension (D3, F3, Ab3, A3, C4, D4, C4, Ab3)
                4 => new[] { 146.83f, 174.61f, 207.65f, 220.00f, 261.63f, 293.66f, 261.63f, 207.65f },
                _ => new[] { 261.63f, 329.63f, 392.00f, 523.25f }
            };

            int stepCount = 32;
            int stepSamples = samples / stepCount;

            for (int step = 0; step < stepCount; step++)
            {
                float baseFreq = notes[step % notes.Length];
                int startSample = step * stepSamples;

                for (int s = 0; s < stepSamples; s++)
                {
                    int idx = startSample + s;
                    if (idx >= samples) break;

                    float t = (float)idx / SAMPLE_RATE;
                    float env = Mathf.Sin((float)s / stepSamples * Mathf.PI);

                    // Bass drone + arpeggio + soft harmonic overtone
                    float bass = Mathf.Sin(2 * Mathf.PI * (baseFreq * 0.5f) * t) * 0.14f;
                    float melody = Mathf.Sin(2 * Mathf.PI * baseFreq * t) * 0.12f;
                    float chime = Mathf.Sin(2 * Mathf.PI * (baseFreq * 2f) * t) * 0.04f;

                    data[idx] = (bass + melody + chime) * env;
                }
            }

            var clip = AudioClip.Create($"Synth_BGM_World_{worldIndex}", samples, 1, SAMPLE_RATE, false);
            clip.SetData(data, 0);
            return clip;
        }
    }
}
