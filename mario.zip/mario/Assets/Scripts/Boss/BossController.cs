using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace RealmRaiders.Boss
{
    public class BossController : MonoBehaviour
    {
        public static BossController Instance { get; private set; }

        [Header("Boss Stats")]
        [SerializeField] private string bossName = "Infernal Fire Dragon";
        [SerializeField] private int maxHealth = 150;
        private int currentHealth;

        public int CurrentHealth => currentHealth;
        public int MaxHealth => maxHealth;
        public string BossName => bossName;

        [Header("Combat Phases")]
        [SerializeField] private int phase = 1;
        [SerializeField] private float attackInterval = 2.6f;

        public static event Action<BossController> OnBossDefeated;

        private SpriteRenderer spriteRenderer;
        private Color baseColor = new Color(0.95f, 0.2f, 0.25f);
        private bool isFlashing = false;

        private void Awake()
        {
            Instance = this;
            spriteRenderer = GetComponent<SpriteRenderer>();
        }

        private void Start()
        {
            currentHealth = maxHealth;
            StartCoroutine(BossBehaviorRoutine());
            StartCoroutine(FloatingBobRoutine());
        }

        private IEnumerator FloatingBobRoutine()
        {
            Vector3 origin = transform.position;
            while (currentHealth > 0)
            {
                float dy = Mathf.Sin(Time.time * 2.5f) * 0.45f;
                transform.position = new Vector3(origin.x, origin.y + dy, origin.z);
                yield return null;
            }
        }

        public void TakeDamage(int damage)
        {
            if (currentHealth <= 0) return;

            currentHealth -= damage;
            Audio.AudioManager.Instance?.PlayHit();
            SideScrollingCamera.TriggerShake(0.12f, 0.16f);
            UI.CombatFeedbackManager.Instance?.ShowPopup(transform.position + Vector3.up * 0.5f, $"-{damage} HP", Color.red);

            if (!isFlashing)
            {
                StartCoroutine(DamageFlashRoutine());
            }

            // Phase 2 Enrage at 50% HP
            if (currentHealth <= maxHealth * 0.5f && phase == 1)
            {
                phase = 2;
                attackInterval = 1.6f;
                baseColor = new Color(1f, 0.1f, 0.1f);
                if (spriteRenderer != null) spriteRenderer.color = baseColor;
                Debug.Log($"<color=red>[Boss]</color> {bossName} entered Enrage Phase 2!");
            }

            if (currentHealth <= 0)
            {
                Die();
            }
        }

        private IEnumerator DamageFlashRoutine()
        {
            isFlashing = true;
            if (spriteRenderer != null) spriteRenderer.color = Color.white;
            yield return new WaitForSeconds(0.12f);
            if (spriteRenderer != null) spriteRenderer.color = baseColor;
            isFlashing = false;
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if (currentHealth <= 0) return;

            if (collision.gameObject.CompareTag("Player") && collision.gameObject.TryGetComponent(out Player player))
            {
                // If player lands on top of boss, bounce and deal stomp damage
                if (collision.transform.DotTest(transform, Vector2.down))
                {
                    player.GetComponent<Rigidbody2D>().velocity = Vector2.up * 11f;
                    TakeDamage(35);
                }
                else
                {
                    player.Hit();
                }
            }
        }

        private IEnumerator BossBehaviorRoutine()
        {
            while (currentHealth > 0)
            {
                yield return new WaitForSeconds(attackInterval);
                PerformAttack();
            }
        }

        private void PerformAttack()
        {
            if (currentHealth <= 0) return;

            if (phase == 1)
            {
                ShootFireball(Vector2.left);
            }
            else
            {
                ShootFireball(Vector2.left);
                ShootFireball(new Vector2(-1f, 0.35f).normalized);
                ShootFireball(new Vector2(-1f, -0.35f).normalized);
            }
        }

        private void ShootFireball(Vector2 dir)
        {
            GameObject fb = new GameObject("Boss_Fireball");
            fb.transform.position = transform.position + (Vector3)(dir * 1.2f);
            fb.transform.localScale = Vector3.one * 0.85f;

            var sr = fb.AddComponent<SpriteRenderer>();
            sr.sprite = Resources.Load<Sprite>("Coin");
            sr.color = new Color(1f, 0.35f, 0.05f, 0.95f);
            sr.sortingOrder = 12;

            var col = fb.AddComponent<CircleCollider2D>();
            col.isTrigger = true;
            col.radius = 0.4f;

            var script = fb.AddComponent<BossFireball>();
            script.velocity = dir * 6.5f;
        }

        private void Die()
        {
            StopAllCoroutines();
            Debug.Log($"<color=gold>[Boss]</color> {bossName} has been vanquished!");

            Audio.AudioManager.Instance?.PlayExplosion();
            SideScrollingCamera.TriggerShake(0.35f, 0.38f);
            UI.CombatFeedbackManager.Instance?.ShowPopup(transform.position, "👑 TRÙM BỊ ĐÁNH BẠI! +500 XU", new Color(1f, 0.85f, 0.2f), 2.5f);
            GameManager.Instance?.AddCoin(500);

            // Spawn fountain of reward coins
            for (int i = 0; i < 10; i++)
            {
                float angle = i * (Mathf.PI * 2f / 10f);
                Vector3 pos = transform.position + new Vector3(Mathf.Cos(angle) * 1.5f, Mathf.Sin(angle) * 1.5f, 0f);
                var coin = new GameObject("Boss_Drop_Coin");
                coin.transform.position = pos;
                var sr = coin.AddComponent<SpriteRenderer>();
                sr.sprite = Resources.Load<Sprite>("Coin");
                sr.sortingOrder = 7;
                var col = coin.AddComponent<CircleCollider2D>();
                col.isTrigger = true;
                col.radius = 0.5f;
                coin.AddComponent<RealmRaiders.Environment.CoinItem>();
            }

            OnBossDefeated?.Invoke(this);
            Destroy(gameObject, 0.8f);
        }
    }

    public class BossFireball : MonoBehaviour
    {
        public Vector2 velocity;
        private float lifeTime = 5f;

        private void Update()
        {
            transform.position += (Vector3)(velocity * Time.deltaTime);
            lifeTime -= Time.deltaTime;
            if (lifeTime <= 0f) Destroy(gameObject);
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Player") || other.GetComponentInParent<Player>() != null)
            {
                var player = other.GetComponent<Player>() ?? other.GetComponentInParent<Player>();
                if (player != null)
                {
                    player.Hit();
                }
                Destroy(gameObject);
            }
        }
    }
}
