using UnityEngine;
using RealmRaiders.UI;
using RealmRaiders.Audio;

namespace RealmRaiders.Boss
{
    [RequireComponent(typeof(Collider2D))]
    public class BossArena : MonoBehaviour
    {
        [Header("Arena Bounds")]
        public float arenaMinX = 175f;
        public float arenaMaxX = 205f;

        [Header("Boss Object")]
        public BossController bossInstance;
        public GameObject exitBarrierOrPortal;

        [Header("Audio")]
        public AudioClip bossMusic;

        private bool arenaTriggered = false;

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (arenaTriggered) return;

            if (other.CompareTag("Player") || other.GetComponentInParent<Player>() != null)
            {
                arenaTriggered = true;
                ActivateArena();
            }
        }

        private void ActivateArena()
        {
            // Lock camera in arena
            var cam = Camera.main?.GetComponent<SideScrollingCamera>();
            if (cam != null)
            {
                cam.LockCamera(arenaMinX, arenaMaxX);
            }

            // Find boss if not directly assigned
            if (bossInstance == null)
            {
                bossInstance = FindObjectOfType<BossController>(true);
            }

            // Activate Boss
            if (bossInstance != null)
            {
                bossInstance.gameObject.SetActive(true);
            }

            BossController.OnBossDefeated += HandleBossDefeated;
            Debug.Log("<color=red>[BossArena]</color> Arena locked! Infernal Dragon fight commenced!");
        }

        private void HandleBossDefeated(BossController boss)
        {
            BossController.OnBossDefeated -= HandleBossDefeated;

            var cam = Camera.main?.GetComponent<SideScrollingCamera>();
            if (cam != null)
            {
                cam.UnlockCamera();
            }

            if (exitBarrierOrPortal != null)
            {
                exitBarrierOrPortal.SetActive(true);
            }

            AudioManager.Instance?.PlayExplosion();
            Debug.Log("<color=gold>[BossArena]</color> Arena unlocked! Proceed to Victory Flag!");
        }
    }
}
