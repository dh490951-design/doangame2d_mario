using System.Collections;
using UnityEngine;

namespace RealmRaiders.PowerUps
{
    public enum SpecialPowerUpType
    {
        Magnet,
        Shield
    }

    public class SpecialPowerUpItem : MonoBehaviour
    {
        public SpecialPowerUpType type = SpecialPowerUpType.Magnet;
        private Vector3 restingPos;
        private bool emerged = false;

        private void Start()
        {
            var sr = GetComponent<SpriteRenderer>();
            if (sr != null && sr.sprite == null)
            {
                string spriteName = type == SpecialPowerUpType.Magnet ? "Magnet" : "Shield";
                var loaded = Resources.Load<Sprite>(spriteName);
                if (loaded != null)
                {
                    sr.sprite = loaded;
                    sr.color = Color.white;
                }
            }
            StartCoroutine(EmergeRoutine());
        }

        private IEnumerator EmergeRoutine()
        {
            Vector3 startPos = transform.position;
            Vector3 endPos = startPos + Vector3.up * 1.2f;

            float elapsed = 0f;
            float duration = 0.4f;

            while (elapsed < duration)
            {
                transform.position = Vector3.Lerp(startPos, endPos, elapsed / duration);
                elapsed += Time.deltaTime;
                yield return null;
            }
            transform.position = endPos;
            restingPos = endPos;
            emerged = true;
        }

        private void Update()
        {
            if (emerged)
            {
                transform.position = restingPos + Vector3.up * Mathf.Sin(Time.time * 4f) * 0.08f;
            }

            var player = FindObjectOfType<Player>();
            if (player != null && Vector2.Distance(transform.position, player.transform.position) < 1.1f)
            {
                Collect(player);
            }
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Player") && other.TryGetComponent(out Player player))
            {
                Collect(player);
            }
        }

        private void Collect(Player player)
        {
            if (type == SpecialPowerUpType.Magnet)
            {
                player.ActivateMagnet(15f);
                UI.CombatFeedbackManager.Instance?.ShowPopup(transform.position, "🧲 NAM CHÂM HÚT XU 15s!", Color.yellow, 1.2f);
            }
            else
            {
                player.ActivateShield();
                UI.CombatFeedbackManager.Instance?.ShowPopup(transform.position, "🛡️ KHIÊN NĂNG LƯỢNG!", Color.cyan, 1.2f);
            }

            Audio.AudioManager.Instance?.PlaySkill();
            Destroy(gameObject);
        }
    }
}
