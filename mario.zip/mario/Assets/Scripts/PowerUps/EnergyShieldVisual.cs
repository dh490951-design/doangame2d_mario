using System.Collections;
using UnityEngine;

namespace RealmRaiders.PowerUps
{
    public class EnergyShieldVisual : MonoBehaviour
    {
        private Player player;
        private GameObject bubbleObj;
        private SpriteRenderer bubbleRenderer;
        private bool wasShieldActive = false;

        private static Sprite cachedBubbleSprite;

        private void Awake()
        {
            player = GetComponent<Player>();
            CreateBubbleObject();
        }

        private void CreateBubbleObject()
        {
            if (bubbleObj != null) return;

            bubbleObj = new GameObject("ShieldBubbleAura");
            bubbleObj.transform.SetParent(transform, false);
            bubbleObj.transform.localPosition = new Vector3(0f, 0.5f, 0f);

            bubbleRenderer = bubbleObj.AddComponent<SpriteRenderer>();
            bubbleRenderer.sortingOrder = 12; // Above Mario (sortingOrder 10)
            bubbleRenderer.material = new Material(Shader.Find("Sprites/Default"));

            if (cachedBubbleSprite == null)
            {
                cachedBubbleSprite = Resources.Load<Sprite>("ShieldBubble");
                if (cachedBubbleSprite == null)
                {
                    cachedBubbleSprite = CreateProceduralBubbleSprite();
                }
            }

            bubbleRenderer.sprite = cachedBubbleSprite;
            bubbleRenderer.color = new Color(0.3f, 0.9f, 1f, 0.75f);
            bubbleObj.SetActive(false);
        }

        private Sprite CreateProceduralBubbleSprite()
        {
            int size = 32;
            Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            float center = (size - 1) * 0.5f;
            float maxR = center;

            Color[] colors = new Color[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dist = Vector2.Distance(new Vector2(x, y), new Vector2(center, center));
                    int idx = y * size + x;

                    if (dist > maxR)
                    {
                        colors[idx] = Color.clear;
                    }
                    else if (dist >= maxR - 2.5f)
                    {
                        // Glowing outer rim
                        colors[idx] = new Color(0.4f, 1f, 1f, 0.9f);
                    }
                    else if (dist >= maxR - 5f)
                    {
                        // Inner ring accent
                        colors[idx] = new Color(0.2f, 0.7f, 1f, 0.55f);
                    }
                    else
                    {
                        // Translucent energy core
                        colors[idx] = new Color(0.1f, 0.5f, 1f, 0.25f);
                    }
                }
            }
            tex.SetPixels(colors);
            tex.Apply();

            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 16f);
        }

        private void Update()
        {
            if (player == null) return;

            bool isActive = Player.hasShieldActive && !player.dead;

            // Detect shield break
            if (wasShieldActive && !isActive)
            {
                StartCoroutine(ShieldBreakBurst());
            }

            wasShieldActive = isActive;

            if (!isActive)
            {
                if (bubbleObj != null && !isBursting)
                {
                    bubbleObj.SetActive(false);
                }
                return;
            }

            if (bubbleObj != null)
            {
                if (!bubbleObj.activeSelf)
                {
                    bubbleObj.SetActive(true);
                }

                // Adjust center based on Mario size
                float targetY = player.big ? 0.9f : 0.5f;
                bubbleObj.transform.localPosition = new Vector3(0f, targetY, 0f);

                // Gentle energy rotation
                bubbleObj.transform.Rotate(0f, 0f, 65f * Time.deltaTime);

                // Breathing pulse effect
                float pulse = 1f + 0.08f * Mathf.Sin(Time.time * 6f);
                float baseScale = player.big ? 1.35f : 1.15f;
                float finalScale = baseScale * pulse;
                bubbleObj.transform.localScale = new Vector3(finalScale, finalScale, 1f);

                // Subtle alpha shimmer
                float alpha = 0.70f + 0.18f * Mathf.Sin(Time.time * 8f);
                bubbleRenderer.color = new Color(0.3f, 0.95f, 1f, alpha);
            }
        }

        private bool isBursting = false;
        private IEnumerator ShieldBreakBurst()
        {
            if (bubbleObj == null) yield break;

            isBursting = true;
            bubbleObj.SetActive(true);

            Vector3 startScale = bubbleObj.transform.localScale;
            Vector3 endScale = startScale * 1.8f;
            Color startCol = new Color(1f, 1f, 1f, 1f);
            Color endCol = new Color(0.2f, 0.8f, 1f, 0f);

            float duration = 0.25f;
            float elapsed = 0f;

            while (elapsed < duration)
            {
                float t = elapsed / duration;
                if (bubbleObj != null)
                {
                    bubbleObj.transform.localScale = Vector3.Lerp(startScale, endScale, t);
                    bubbleRenderer.color = Color.Lerp(startCol, endCol, t);
                }
                elapsed += Time.deltaTime;
                yield return null;
            }

            if (bubbleObj != null)
            {
                bubbleObj.SetActive(false);
            }
            isBursting = false;
        }

        private void OnDestroy()
        {
            if (bubbleObj != null)
            {
                Destroy(bubbleObj);
            }
        }
    }
}
