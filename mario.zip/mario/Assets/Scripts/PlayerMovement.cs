using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerMovement : MonoBehaviour
{
    private Camera mainCamera;
    private Rigidbody2D rb;
    private Collider2D capsuleCollider;

    private Vector2 velocity;
    private float inputAxis;

    public float moveSpeed = 8f;
    public float maxJumpHeight = 6.2f;
    public float maxJumpTime = 1.05f;
    public float jumpForce => (2f * maxJumpHeight) / (maxJumpTime / 2f);
    public float gravity => (-2f * maxJumpHeight) / Mathf.Pow(maxJumpTime / 2f, 2f);

    public bool grounded { get; private set; }
    public bool jumping { get; private set; }
    public bool running => Mathf.Abs(velocity.x) > 0.25f || Mathf.Abs(inputAxis) > 0.25f;
    public bool sliding => (inputAxis > 0f && velocity.x < 0f) || (inputAxis < 0f && velocity.x > 0f);
    public bool falling => velocity.y < 0f && !grounded;

    public void ResetVelocity()
    {
        velocity = Vector2.zero;
        jumping = false;
    }

    private bool canDoubleJump = false;

    private void Awake()
    {
        mainCamera = Camera.main;
        rb = GetComponent<Rigidbody2D>();
        capsuleCollider = GetComponent<Collider2D>();

        // Enhanced Mario Jump Height (Nhảy cao và bay bổng hơn)
        maxJumpHeight = 6.8f;
        maxJumpTime = 1.05f;

        // Apply speed upgrades if save exists
        var data = RealmRaiders.Data.SaveSystem.LoadData();
        if (data != null && data.speedLevel > 1)
        {
            moveSpeed += (data.speedLevel - 1) * 0.75f;
        }
    }

    private void OnEnable()
    {
        rb.isKinematic = false;
        capsuleCollider.enabled = true;
        velocity = Vector2.zero;
        jumping = false;
    }

    private void OnDisable()
    {
        rb.isKinematic = true;
        capsuleCollider.enabled = false;
        velocity = Vector2.zero;
        inputAxis = 0f;
        jumping = false;
    }

    private void Update()
    {
        HorizontalMovement();

        grounded = rb.Raycast(Vector2.down);

        if (grounded) {
            canDoubleJump = RealmRaiders.Data.SaveSystem.Current.hasDoubleJump;
            GroundedMovement();
        } else {
            AirMovement();
        }

        ApplyGravity();
    }

    private void AirMovement()
    {
        bool jumpPressed = Input.GetKeyDown(KeyCode.Space) ||
                           Input.GetKeyDown(KeyCode.W) ||
                           Input.GetKeyDown(KeyCode.UpArrow) ||
                           Input.GetButtonDown("Jump") ||
                           virtualJumpPressed;

        if (jumpPressed && canDoubleJump)
        {
            canDoubleJump = false;
            virtualJumpPressed = false;
            velocity.y = jumpForce * 0.92f;
            jumping = true;
            RealmRaiders.Audio.AudioManager.Instance?.PlayJump();
            RealmRaiders.UI.CombatFeedbackManager.Instance?.ShowPopup(transform.position, "✨ NHẢY ĐÔI!", Color.cyan, 0.7f);
        }
    }

    private void FixedUpdate()
    {
        // Move mario based on his velocity
        Vector2 position = rb.position;
        position += velocity * Time.fixedDeltaTime;

        // Free exploration: Prevent player from walking behind start of level (x = 0), or lock during boss arena
        if (SideScrollingCamera.Instance != null && SideScrollingCamera.Instance.isLocked && SideScrollingCamera.Instance.lockedMaxX > SideScrollingCamera.Instance.lockedMinX)
        {
            position.x = Mathf.Clamp(position.x, SideScrollingCamera.Instance.lockedMinX + 0.5f, SideScrollingCamera.Instance.lockedMaxX - 0.5f);
        }
        else
        {
            if (position.x < 0f) position.x = 0f;
        }

        rb.MovePosition(position);
    }

    public static float virtualAxisX = 0f;
    public static bool virtualJumpPressed = false;

    private void HorizontalMovement()
    {
        // Full WASD and Arrow Keys support
        float keyX = 0f;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) keyX -= 1f;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) keyX += 1f;

        float axis = Input.GetAxisRaw("Horizontal");
        if (Mathf.Abs(axis) > 0.1f) keyX = axis;

        inputAxis = Mathf.Clamp(keyX + virtualAxisX, -1f, 1f);
        velocity.x = Mathf.MoveTowards(velocity.x, inputAxis * moveSpeed, moveSpeed * Time.deltaTime);

        // Check if running into a solid wall only when actively moving
        if (Mathf.Abs(velocity.x) > 0.05f)
        {
            Vector2 checkDir = velocity.x > 0f ? Vector2.right : Vector2.left;
            if (rb.Raycast(checkDir))
            {
                velocity.x = 0f;
            }
        }

        // Flip sprite to face direction
        if (velocity.x > 0f) {
            transform.eulerAngles = Vector3.zero;
        } else if (velocity.x < 0f) {
            transform.eulerAngles = new Vector3(0f, 180f, 0f);
        }
    }

    private void GroundedMovement()
    {
        // Prevent gravity from infinitly building up
        velocity.y = Mathf.Max(velocity.y, 0f);
        jumping = velocity.y > 0f;

        // Perform jump: Space, W, Up Arrow or on-screen button
        bool jumpPressed = Input.GetKeyDown(KeyCode.Space) ||
                           Input.GetKeyDown(KeyCode.W) ||
                           Input.GetKeyDown(KeyCode.UpArrow) ||
                           Input.GetButtonDown("Jump") ||
                           virtualJumpPressed;

        if (jumpPressed)
        {
            velocity.y = jumpForce;
            jumping = true;
            virtualJumpPressed = false;
            RealmRaiders.Audio.AudioManager.Instance?.PlayJump();
        }
    }

    private void ApplyGravity()
    {
        bool jumpHeld = Input.GetKey(KeyCode.Space) ||
                        Input.GetKey(KeyCode.W) ||
                        Input.GetKey(KeyCode.UpArrow) ||
                        Input.GetButton("Jump");

        // Check if falling
        bool falling = velocity.y < 0f || !jumpHeld;
        float multiplier = falling ? 2f : 1f;

        // Apply gravity and terminal velocity
        velocity.y += gravity * multiplier * Time.deltaTime;
        velocity.y = Mathf.Max(velocity.y, gravity / 2f);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Enemy"))
        {
            // Bounce off enemy head
            if (transform.DotTest(collision.transform, Vector2.down))
            {
                velocity.y = jumpForce / 2f;
                jumping = true;
            }
        }
        else if (collision.gameObject.layer != LayerMask.NameToLayer("PowerUp"))
        {
            // Stop vertical movement if mario bonks his head
            if (transform.DotTest(collision.transform, Vector2.up)) {
                velocity.y = 0f;
            }
        }
    }

}
