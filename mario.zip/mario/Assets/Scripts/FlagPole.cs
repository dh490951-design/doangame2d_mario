using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class FlagPole : MonoBehaviour
{
    public Transform flag;
    public Transform poleBottom;
    public Transform castle;
    public float speed = 6f;
    public int nextWorld = 1;
    public int nextStage = 1;

    private bool triggered = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (triggered) return;

        if (other.CompareTag("Player") || other.GetComponentInParent<Player>() != null)
        {
            var player = other.GetComponent<Player>() ?? other.GetComponentInParent<Player>();
            if (player != null)
            {
                triggered = true;
                if (flag != null && poleBottom != null)
                {
                    StartCoroutine(MoveTo(flag, poleBottom.position));
                }
                StartCoroutine(LevelCompleteSequence(player));
            }
        }
    }

    private IEnumerator LevelCompleteSequence(Player player)
    {
        if (player.movement != null) player.movement.enabled = false;
        if (player.capsuleCollider != null) player.capsuleCollider.enabled = false;
        if (player.TryGetComponent(out Rigidbody2D rb))
        {
            rb.isKinematic = true;
            rb.velocity = Vector2.zero;
        }

        if (poleBottom != null)
        {
            yield return MoveTo(player.transform, poleBottom.position, 2.5f);
        }
        yield return MoveTo(player.transform, player.transform.position + Vector3.right, 0.8f);
        yield return MoveTo(player.transform, player.transform.position + Vector3.right + Vector3.down, 0.8f);
        
        if (castle != null)
        {
            Vector3 targetDoor = new Vector3(castle.position.x, player.transform.position.y, player.transform.position.z);
            yield return MoveTo(player.transform, targetDoor, 2.5f);
        }

        player.gameObject.SetActive(false);

        // Determine current world from scene name or GameManager
        int currentW = 1;
        string sceneName = SceneManager.GetActiveScene().name;
        if (sceneName.StartsWith("2-")) currentW = 2;
        else if (sceneName.StartsWith("3-")) currentW = 3;
        else if (sceneName.StartsWith("4-")) currentW = 4;
        else if (GameManager.Instance != null) currentW = GameManager.Instance.world;

        int bonusCoins = currentW switch
        {
            1 => 150,
            2 => 300,
            3 => 600,
            4 => 1500,
            _ => 150
        };
        int bonusGems = currentW switch
        {
            1 => 10,
            2 => 20,
            3 => 40,
            4 => 100,
            _ => 10
        };

        var data = RealmRaiders.Data.SaveSystem.Current;
        data.coins += bonusCoins;
        data.gems += bonusGems;

        RealmRaiders.Audio.AudioManager.Instance?.PlayCoin();
        RealmRaiders.Quests.QuestManager.Instance?.AddProgress("story_world1", 1);
        RealmRaiders.Achievements.AchievementManager.Instance?.ReportProgress("breakthrough", 500);

        // Track completion time & speedrun record
        float timeSpent = GameManager.Instance != null ? GameManager.Instance.stagePlayTimer : 0f;
        float currentBest = data.GetBestTime(currentW);
        bool isNewRecord = (currentBest <= 0.05f || timeSpent < currentBest) && timeSpent > 0.5f;
        if (isNewRecord)
        {
            data.SetBestTime(currentW, timeSpent);
        }

        Debug.Log($"<color=green>[Level Complete]</color> World {currentW} Cleared in {timeSpent:F1}s! (New Record: {isNewRecord}) Bonus: +{bonusCoins} Coins, +{bonusGems} Gems!");

        // If World 4 cleared: VICTORY!
        if (currentW >= 4)
        {
            data.unlockedWorld = 4;
            data.coins += 2000;
            data.gems += 100;
            RealmRaiders.Data.SaveSystem.SaveData();

            RealmRaiders.UI.MasterMenuOverlay.Instance?.ShowVictoryPopup();
            yield break;
        }

        // Advance to next world (1-1 -> 2-1 -> 3-1 -> 4-1)
        int targetWorld = currentW + 1;
        if (targetWorld > data.unlockedWorld)
        {
            data.unlockedWorld = targetWorld;
        }
        RealmRaiders.Data.SaveSystem.SaveData();

        // Display celebratory Stage Clear Card
        RealmRaiders.UI.MasterMenuOverlay.Instance?.ShowStageClear(currentW, bonusCoins, bonusGems, targetWorld, timeSpent, isNewRecord);
    }

    private IEnumerator MoveTo(Transform subject, Vector3 position, float timeout = 3.0f)
    {
        float timer = 0f;
        while (subject != null && Vector3.Distance(subject.position, position) > 0.125f && timer < timeout)
        {
            subject.position = Vector3.MoveTowards(subject.position, position, speed * Time.deltaTime);
            timer += Time.deltaTime;
            yield return null;
        }
        if (subject != null)
        {
            subject.position = position;
        }
    }
}
